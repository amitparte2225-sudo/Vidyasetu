import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const configured = Boolean(url && key);
// Only the public anon key is ever used here. All writes are checked by Row Level Security in the database.
export const supabase = createClient(url ?? 'http://localhost:54321', key ?? 'not-configured');

export const LANGS = [{ code: 'mr', label: 'Marathi (मराठी)' }]; // add more languages here
