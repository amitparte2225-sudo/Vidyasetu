// Client-side upload checks. The database bucket ALSO enforces size and MIME type; this just gives early feedback.
export const ALLOWED = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];

export async function sniff(file: File): Promise<string | null> {
  const b = new Uint8Array(await file.slice(0, 12).arrayBuffer());
  const s = (i: number, n: number) => String.fromCharCode(...b.slice(i, i + n));
  if (s(0, 4) === '%PDF') return 'application/pdf';
  if (b[0] === 0x89 && s(1, 3) === 'PNG') return 'image/png';
  if (b[0] === 0xff && b[1] === 0xd8) return 'image/jpeg';
  if (s(0, 4) === 'RIFF' && s(8, 4) === 'WEBP') return 'image/webp';
  return null;
}

export async function validateFile(file: File, maxMb: number): Promise<string | null> {
  if (file.size === 0) return 'The file is empty.';
  if (file.size > maxMb * 1024 * 1024) return `The file is larger than ${maxMb} MB.`;
  const real = await sniff(file);
  if (!real || !ALLOWED.includes(real)) return 'Only PDF, PNG, JPEG and WebP files are allowed.';
  if (file.type && file.type !== real) return 'The file content does not match its type.';
  return null;
}

export const safeName = (n: string) => n.replace(/[^A-Za-z0-9._-]/g, '_').slice(-80);
