'use client';
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { supabase, configured } from './supabase';

type Admin = { userId: string; email: string; role: string; perms: Set<string> };
const Ctx = createContext<Admin | null>(null);
export const useAdmin = () => useContext(Ctx)!;

export function Guard({ children, perm }: { children: ReactNode; perm?: string }) {
  const router = useRouter();
  const [state, setState] = useState<'loading' | 'denied' | 'ok'>('loading');
  const [admin, setAdmin] = useState<Admin | null>(null);

  useEffect(() => {
    if (!configured) { setState('denied'); return; }
    let cancelled = false;
    async function load() {
      const { data } = await supabase.auth.getSession();
      const user = data.session?.user;
      if (!user) { router.replace('/login'); return; }
      const { data: ur } = await supabase.from('user_roles').select('role').eq('user_id', user.id).maybeSingle();
      const role = ur?.role ?? 'student';
      const { data: rp } = await supabase.from('role_permissions').select('permission').eq('role', role);
      const perms = new Set<string>((rp ?? []).map((r: any) => r.permission));
      if (cancelled) return;
      if (!perms.has('content.write')) { setState('denied'); return; }
      setAdmin({ userId: user.id, email: user.email ?? '', role, perms });
      setState('ok');
    }
    load();
    const { data: sub } = supabase.auth.onAuthStateChange((evt) => { if (evt === 'SIGNED_OUT') router.replace('/login'); });
    return () => { cancelled = true; sub.subscription.unsubscribe(); };
  }, [router]);

  if (state === 'loading') return <p className="center">Loading…</p>;
  if (state === 'denied') {
    return (
      <div className="center card">
        <h2>No access</h2>
        <p>{configured ? 'This account is not an administrator or editor.' : 'The dashboard is not configured: set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.'}</p>
        <button onClick={async () => { await supabase.auth.signOut(); router.replace('/login'); }}>Sign out</button>
      </div>
    );
  }
  if (perm && !admin!.perms.has(perm)) {
    return <Shell admin={admin!}><div className="card"><h2>Not allowed</h2><p>Your role does not include the “{perm}” permission.</p></div></Shell>;
  }
  return <Shell admin={admin!}>{children}</Shell>;
}

const NAV: [string, string][] = [
  ['/', 'Dashboard'], ['/institutions', 'Boards & universities'], ['/levels', 'Classes / degrees / semesters'],
  ['/subjects', 'Subjects'], ['/chapters', 'Chapters'], ['/topics', 'Topics'], ['/resources', 'Notes, PDFs & images'],
  ['/questions', 'Questions & solutions'], ['/quizzes', 'Quizzes'], ['/reports', 'Reports'],
  ['/users', 'Users'], ['/ai-limits', 'AI limits'],
];

function Shell({ admin, children }: { admin: Admin; children: ReactNode }) {
  const router = useRouter();
  return (
    <Ctx.Provider value={admin}>
      <div className="layout">
        <nav>
          <h1>Vidyasetu admin</h1>
          {NAV.map(([href, label]) => <a key={href} href={href}>{label}</a>)}
          <div className="who">{admin.email}<br /><small>{admin.role}</small></div>
          <button onClick={async () => { await supabase.auth.signOut(); router.replace('/login'); }}>Sign out</button>
        </nav>
        <main>{children}</main>
      </div>
    </Ctx.Provider>
  );
}
