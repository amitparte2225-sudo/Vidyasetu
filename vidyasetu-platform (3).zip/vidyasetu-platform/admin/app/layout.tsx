import './globals.css';
import 'katex/dist/katex.min.css';
import type { ReactNode } from 'react';

export const metadata = { title: 'Vidyasetu admin', robots: { index: false, follow: false } };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (<html lang="en"><body>{children}</body></html>);
}
