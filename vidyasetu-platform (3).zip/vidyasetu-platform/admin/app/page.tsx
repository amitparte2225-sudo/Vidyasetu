'use client';
import { useEffect, useState } from 'react';
import { Guard } from '@/lib/Guard';
import { supabase } from '@/lib/supabase';

const LABELS: Record<string, string> = {
  users: 'Registered users', published_chapters: 'Published chapters', draft_chapters: 'Draft chapters',
  published_quizzes: 'Published quizzes', quiz_attempts_7d: 'Quiz attempts (7 days)',
  solver_requests_7d: 'AI solver requests (7 days)', solver_errors_7d: 'AI solver errors (7 days)', open_reports: 'Open reports',
};

function Stats() {
  const [stats, setStats] = useState<Record<string, number> | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    supabase.rpc('admin_stats').then(({ data, error }) => { if (error) setError(error.message); else setStats(data); });
  }, []);
  return (
    <>
      <h2>Dashboard</h2>
      {error && <p className="err">{error}</p>}
      <div className="stats">
        {stats && Object.entries(LABELS).map(([k, label]) => (
          <div className="card stat" key={k}><b>{stats[k] ?? 0}</b>{label}</div>))}
      </div>
      <p className="help">Content you publish appears in the student app immediately, with no rebuild.</p>
    </>
  );
}

export default function Home() { return <Guard><Stats /></Guard>; }
