'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (
    <Guard perm="ai.configure">
      <CrudTable title="AI usage limits" table="usage_limits" reorder={false} orderBy="updated_at"
        intro="The row with an empty user id is the default for everybody. Add a row with a user id to give one student a different limit."
        fields={[
          { key: "user_id", label: "User id (empty = default)", type: "text" },
          { key: "daily_solver_requests", label: "Per day", type: "number", required: true },
          { key: "monthly_solver_requests", label: "Per month", type: "number", required: true },
          { key: "max_upload_mb", label: "Max upload MB", type: "number", required: true },
          { key: "max_pdf_pages", label: "Max PDF pages", type: "number", required: true },
          { key: "max_question_chars", label: "Max question characters", type: "number", required: true },
        ]} />
    </Guard>
  );
}
