'use client';
import { useCallback, useEffect, useState } from 'react';
import { Guard, useAdmin } from '@/lib/Guard';
import { supabase } from '@/lib/supabase';

function Users() {
  const me = useAdmin();
  const [rows, setRows] = useState<any[]>([]);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const load = useCallback(async () => {
    const { data, error } = await supabase.rpc('admin_list_users');
    if (error) setError(error.message); else setRows(data ?? []);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function setRole(id: string, role: string) {
    if (id === me.userId && role !== 'admin' && !confirm('You are removing your own admin role. Continue?')) return;
    const r = await supabase.from('user_roles').upsert({ user_id: id, role }, { onConflict: 'user_id' });
    if (r.error) setError(r.error.message); else { setInfo('Role updated.'); load(); }
  }
  async function ban(id: string, banned: boolean) {
    const r = await supabase.from('profiles').update({ is_banned: banned }).eq('id', id);
    if (r.error) setError(r.error.message); else { setInfo(banned ? 'User suspended.' : 'User restored.'); load(); }
  }
  return (<>
    <h2>Users</h2>
    {error && <p className="err">{error}</p>}{info && <p className="okmsg">{info}</p>}
    <table><thead><tr><th>E-mail</th><th>Name</th><th>Role</th><th>Suspended</th><th>Joined</th></tr></thead><tbody>
      {rows.map(u => <tr key={u.id}><td>{u.email}</td><td>{u.display_name}</td>
        <td><select value={u.role} onChange={e => setRole(u.id, e.target.value)}><option>student</option><option>editor</option><option>admin</option></select></td>
        <td><input type="checkbox" style={{ width: 'auto' }} checked={u.is_banned} disabled={u.id === me.userId} onChange={e => ban(u.id, e.target.checked)} /></td>
        <td>{new Date(u.created_at).toLocaleDateString()}</td></tr>)}
    </tbody></table>
    <p className="help">Suspended users are refused by the AI and quiz services. The database re-checks every change you make here.</p>
  </>);
}
export default function Page() { return <Guard perm="users.manage"><Users /></Guard>; }
