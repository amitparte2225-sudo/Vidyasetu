'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase, configured } from '@/lib/supabase';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) setError('Sign-in failed. Check your e-mail and password.');
    else router.replace('/');
  }
  return (
    <div className="center card">
      <h2>Vidyasetu admin</h2>
      {!configured && <p className="err">Not configured: set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in admin/.env.local</p>}
      <form onSubmit={submit}>
        <label>E-mail</label><input type="email" required value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" />
        <label>Password</label><input type="password" required value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" />
        {error && <p className="err">{error}</p>}
        <p><button disabled={busy || !configured}>{busy ? 'Signing in…' : 'Sign in'}</button></p>
      </form>
      <p className="help">Only accounts with the editor or admin role can use this dashboard. Students are refused after sign-in, and the database rejects their writes anyway.</p>
    </div>
  );
}
