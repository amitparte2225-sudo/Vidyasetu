'use client';
import { useCallback, useEffect, useState } from 'react';
import { Guard, useAdmin } from '@/lib/Guard';
import { supabase } from '@/lib/supabase';

type Opt = { id: string; text: string };
const TYPES = [['mcq_single', 'Single-answer MCQ'], ['mcq_multi', 'Multiple-select'], ['true_false', 'True / False'],
  ['numeric', 'Numerical answer'], ['short_answer', 'Short answer']];
const LETTERS = 'abcdefgh';
const blank = () => ({ id: '', chapter_id: '', type: 'mcq_single', usage: 'practice', prompt: '', prompt_mr: '', marks: '1',
  difficulty: 'medium', status: 'draft', options: [{ id: 'a', text: '' }, { id: 'b', text: '' }] as Opt[],
  correct: [] as string[], tf: 'true', numeric: '', tolerance: '0', accepted: '', explanation: '', solution: '' });

function Editor() {
  const admin = useAdmin();
  const canPublish = admin.perms.has('content.publish');
  const [chapters, setChapters] = useState<any[]>([]);
  const [chapterId, setChapterId] = useState('');
  const [rows, setRows] = useState<any[]>([]);
  const [f, setF] = useState<any | null>(null);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { supabase.from('chapters').select('id,title,number').order('title').then(({ data }) => setChapters(data ?? [])); }, []);
  const load = useCallback(async () => {
    if (!chapterId) { setRows([]); return; }
    const { data, error } = await supabase.from('questions').select('*').eq('chapter_id', chapterId).order('display_order');
    if (error) setError(error.message); else setRows(data ?? []);
  }, [chapterId]);
  useEffect(() => { load(); }, [load]);

  async function edit(q: any | null) {
    setError(''); setInfo('');
    if (!q) { setF({ ...blank(), chapter_id: chapterId }); return; }
    const [{ data: a }, { data: s }] = await Promise.all([
      supabase.from('question_answers').select('*').eq('question_id', q.id).maybeSingle(),
      supabase.from('solutions').select('*').eq('question_id', q.id).limit(1)]);
    const correct: any[] = a?.correct ?? [];
    setF({ id: q.id, chapter_id: q.chapter_id, type: q.type, usage: q.usage, prompt: q.prompt, prompt_mr: q.prompt_i18n?.mr ?? '',
      marks: String(q.marks), difficulty: q.difficulty, status: q.status, options: q.options?.length ? q.options : blank().options,
      correct: q.type === 'mcq_single' || q.type === 'mcq_multi' ? correct.map(String) : [],
      tf: String(correct[0] ?? 'true'), numeric: q.type === 'numeric' ? String(correct[0] ?? '') : '',
      tolerance: String(a?.numeric_tolerance ?? 0), accepted: q.type === 'short_answer' ? correct.join('\n') : '',
      explanation: a?.explanation ?? '', solution: s?.[0]?.body_md ?? '', solutionId: s?.[0]?.id });
  }

  const set = (k: string, v: any) => setF({ ...f, [k]: v });
  const isMcq = f && (f.type === 'mcq_single' || f.type === 'mcq_multi');

  function buildCorrect(): any[] {
    if (isMcq) {
      const ids = f.options.map((o: Opt) => o.id);
      const c = f.correct.filter((x: string) => ids.includes(x));
      if (c.length === 0) throw new Error('Mark at least one correct option.');
      if (f.type === 'mcq_single' && c.length !== 1) throw new Error('A single-answer MCQ needs exactly one correct option.');
      return c;
    }
    if (f.type === 'true_false') return [f.tf === 'true'];
    if (f.type === 'numeric') { const n = Number(f.numeric); if (f.numeric === '' || !Number.isFinite(n)) throw new Error('Enter the numeric answer.'); return [n]; }
    const list = f.accepted.split('\n').map((s: string) => s.trim()).filter(Boolean);
    if (!list.length) throw new Error('Enter at least one accepted answer.');
    return list;
  }

  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      if (!f.chapter_id) throw new Error('Choose a chapter first.');
      if (!f.prompt.trim()) throw new Error('The question text is required.');
      const marks = Number(f.marks); if (!(marks > 0)) throw new Error('Marks must be greater than 0.');
      if (isMcq && f.options.some((o: Opt) => !o.text.trim())) throw new Error('Fill in every option or remove the empty ones.');
      const correct = buildCorrect();
      const payload: any = { chapter_id: f.chapter_id, type: f.type, usage: f.usage, prompt: f.prompt.trim(),
        prompt_i18n: f.prompt_mr.trim() ? { mr: f.prompt_mr.trim() } : {}, options: isMcq ? f.options : [],
        marks, difficulty: f.difficulty };
      let id = f.id;
      if (id) { const r = await supabase.from('questions').update(payload).eq('id', id); if (r.error) throw r.error; }
      else { const r = await supabase.from('questions').insert(payload).select('id').single(); if (r.error) throw r.error; id = r.data.id; }
      const ans = await supabase.from('question_answers').upsert({ question_id: id, correct, explanation: f.explanation.trim() || null,
        numeric_tolerance: f.type === 'numeric' ? Math.max(0, Number(f.tolerance) || 0) : 0 }, { onConflict: 'question_id' });
      if (ans.error) throw ans.error;
      if (f.usage === 'practice' && f.solution.trim()) {
        const sol = { question_id: id, body_md: f.solution.trim(), is_verified: true };
        const r = f.solutionId ? await supabase.from('solutions').update(sol).eq('id', f.solutionId)
                               : await supabase.from('solutions').insert(sol);
        if (r.error) throw r.error;
      }
      setF(null); setInfo('Saved. New questions are drafts: publish them from the list.'); load();
    } catch (err: any) { setError(err.message ?? String(err)); }
    setBusy(false);
  }

  async function status(q: any, s: string) {
    const r = await supabase.from('questions').update({ status: s }).eq('id', q.id);
    if (r.error) { setError(r.error.message); return; }
    // keep the worked solution's visibility in step with the question
    await supabase.from('solutions').update({ status: s }).eq('question_id', q.id);
    load();
  }
  async function del(q: any) {
    if (!confirm('Delete this question, its answer and solutions?')) return;
    const r = await supabase.from('questions').delete().eq('id', q.id);
    if (r.error) setError(r.error.message); else load();
  }

  return (<>
    <h2>Questions, answers & worked solutions</h2>
    <p className="help">Correct answers are stored separately and are never readable by students. “Quiz” questions are served only through quizzes; “Practice” questions are shown with the verified solution.</p>
    <div className="row" style={{ marginBottom: 12 }}>
      <select style={{ width: 340 }} value={chapterId} onChange={e => setChapterId(e.target.value)}>
        <option value="">— choose a chapter —</option>
        {chapters.map(c => <option key={c.id} value={c.id}>{c.number}. {c.title}</option>)}
      </select>
      <button disabled={!chapterId} onClick={() => edit(null)}>+ New question</button>
    </div>
    {error && <p className="err">{error}</p>}{info && <p className="okmsg">{info}</p>}

    {f && <form className="card" onSubmit={save}>
      <div className="grid2">
        <div><label>Type</label><select value={f.type} onChange={e => { const t = e.target.value; setF({ ...f, type: t, correct: [] }); }}>{TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
        <div><label>Used in</label><select value={f.usage} onChange={e => set('usage', e.target.value)}><option value="practice">Practice (with solution)</option><option value="quiz">Quiz only</option></select></div>
        <div style={{ gridColumn: '1/-1' }}><label>Question (English) — Markdown + LaTeX</label><textarea value={f.prompt} onChange={e => set('prompt', e.target.value)} /></div>
        <div style={{ gridColumn: '1/-1' }}><label>Question (Marathi) <span className="help">optional</span></label><textarea value={f.prompt_mr} onChange={e => set('prompt_mr', e.target.value)} /></div>
        <div><label>Marks</label><input type="number" step="0.5" value={f.marks} onChange={e => set('marks', e.target.value)} /></div>
        <div><label>Difficulty</label><select value={f.difficulty} onChange={e => set('difficulty', e.target.value)}><option>easy</option><option>medium</option><option>hard</option></select></div>
      </div>
      {isMcq && <>
        <label>Options (tick the correct {f.type === 'mcq_multi' ? 'ones' : 'one'})</label>
        {f.options.map((o: Opt, i: number) => (
          <div className="row" key={o.id} style={{ marginBottom: 4 }}>
            <input style={{ width: 'auto' }} type={f.type === 'mcq_multi' ? 'checkbox' : 'radio'} name="correct"
              checked={f.correct.includes(o.id)}
              onChange={e => set('correct', f.type === 'mcq_multi' ? (e.target.checked ? [...f.correct, o.id] : f.correct.filter((x: string) => x !== o.id)) : [o.id])} />
            <b>{o.id.toUpperCase()}</b>
            <input style={{ flex: 1 }} value={o.text} onChange={e => set('options', f.options.map((x: Opt, j: number) => j === i ? { ...x, text: e.target.value } : x))} />
            <button type="button" className="secondary" disabled={f.options.length <= 2}
              onClick={() => { const left = f.options.filter((_: Opt, j: number) => j !== i).map((x: Opt, j: number) => ({ ...x, id: LETTERS[j] })); setF({ ...f, options: left, correct: [] }); }}>✕</button>
          </div>))}
        <button type="button" className="secondary" disabled={f.options.length >= 8}
          onClick={() => set('options', [...f.options, { id: LETTERS[f.options.length], text: '' }])}>+ option</button>
      </>}
      {f.type === 'true_false' && <><label>Correct answer</label><select value={f.tf} onChange={e => set('tf', e.target.value)}><option value="true">True</option><option value="false">False</option></select></>}
      {f.type === 'numeric' && <div className="grid2"><div><label>Correct number</label><input value={f.numeric} onChange={e => set('numeric', e.target.value)} /></div>
        <div><label>Allowed error (±)</label><input value={f.tolerance} onChange={e => set('tolerance', e.target.value)} /></div></div>}
      {f.type === 'short_answer' && <><label>Accepted answers <span className="help">one per line; case and spacing are ignored</span></label><textarea value={f.accepted} onChange={e => set('accepted', e.target.value)} /></>}
      <label>Explanation shown after a quiz is submitted</label><textarea value={f.explanation} onChange={e => set('explanation', e.target.value)} />
      {f.usage === 'practice' && <><label>Worked solution (verified) — Markdown + LaTeX</label><textarea style={{ minHeight: 140 }} value={f.solution} onChange={e => set('solution', e.target.value)} /></>}
      <div className="row" style={{ marginTop: 12 }}><button disabled={busy}>{busy ? 'Saving…' : 'Save question'}</button><button type="button" className="secondary" onClick={() => setF(null)}>Cancel</button></div>
    </form>}

    <table><thead><tr><th>Question</th><th>Type</th><th>Used in</th><th>Marks</th><th>Status</th><th>Actions</th></tr></thead><tbody>
      {rows.map(q => <tr key={q.id}><td>{q.prompt.slice(0, 110)}</td><td>{q.type}</td><td>{q.usage}</td><td>{q.marks}</td>
        <td><span className={`badge ${q.status}`}>{q.status}</span></td>
        <td className="row"><button className="secondary" onClick={() => edit(q)}>Edit</button>
          {canPublish && (q.status === 'published' ? <button className="secondary" onClick={() => status(q, 'draft')}>Unpublish</button> : <button onClick={() => status(q, 'published')}>Publish</button>)}
          {canPublish && q.status !== 'archived' && <button className="secondary" onClick={() => status(q, 'archived')}>Archive</button>}
          <button className="danger" onClick={() => del(q)}>Delete</button></td></tr>)}
      {!rows.length && <tr><td colSpan={6}>{chapterId ? 'No questions in this chapter yet.' : 'Choose a chapter.'}</td></tr>}
    </tbody></table>
  </>);
}
export default function Page() { return <Guard><Editor /></Guard>; }
