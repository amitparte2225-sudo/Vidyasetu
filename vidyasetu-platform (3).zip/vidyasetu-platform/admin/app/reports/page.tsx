'use client';
import { useCallback, useEffect, useState } from 'react';
import { Guard, useAdmin } from '@/lib/Guard';
import { supabase } from '@/lib/supabase';

function Reports() {
  const me = useAdmin();
  const [rows, setRows] = useState<any[]>([]);
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    const { data, error } = await supabase.from('content_reports').select('*').order('created_at', { ascending: false }).limit(200);
    if (error) setError(error.message); else setRows(data ?? []);
  }, []);
  useEffect(() => { load(); }, [load]);
  async function mark(id: string, status: string) {
    const r = await supabase.from('content_reports').update({ status, resolved_by: me.userId }).eq('id', id);
    if (r.error) setError(r.error.message); else load();
  }
  return (<>
    <h2>Reported content</h2>
    {error && <p className="err">{error}</p>}
    <table><thead><tr><th>When</th><th>Target</th><th>Reason</th><th>Status</th><th></th></tr></thead><tbody>
      {rows.map(r => <tr key={r.id}><td>{new Date(r.created_at).toLocaleString()}</td>
        <td>{r.target_kind}<br /><small>{r.target_id}</small></td><td>{r.reason}</td><td>{r.status}</td>
        <td className="row">{r.status === 'open' && <><button onClick={() => mark(r.id, 'resolved')}>Resolve</button><button className="secondary" onClick={() => mark(r.id, 'dismissed')}>Dismiss</button></>}</td></tr>)}
      {!rows.length && <tr><td colSpan={5}>No reports.</td></tr>}
    </tbody></table>
    <p className="help">To act on reported content, open it under Chapters, Resources or Questions and unpublish or edit it.</p>
  </>);
}
export default function Page() { return <Guard perm="reports.manage"><Reports /></Guard>; }
