'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (<Guard>
    <CrudTable title="Boards & universities" table="institutions" hasStatus fields={[
      { key: "kind", label: "Kind", type: "select", required: true, options: [{ value: "board", label: "Board" }, { value: "university", label: "University" }] },
      { key: "name", label: "Name (English)", type: "text", required: true },
      { key: "name_i18n", label: "Name (other languages)", type: "i18n" },
    ]} />
  </Guard>);
}
