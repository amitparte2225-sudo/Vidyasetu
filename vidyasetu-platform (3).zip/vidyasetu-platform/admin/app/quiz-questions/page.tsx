'use client';
import { Suspense, useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { Guard } from '@/lib/Guard';
import { supabase } from '@/lib/supabase';

function Inner() {
  const quizId = useSearchParams().get('quiz') ?? '';
  const [quiz, setQuiz] = useState<any>(null);
  const [linked, setLinked] = useState<any[]>([]);   // quiz_questions + question
  const [bank, setBank] = useState<any[]>([]);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    const { data: q, error: e1 } = await supabase.from('quizzes').select('*').eq('id', quizId).maybeSingle();
    if (e1 || !q) { setError(e1?.message ?? 'Quiz not found.'); return; }
    setQuiz(q);
    const { data: links } = await supabase.from('quiz_questions').select('*').eq('quiz_id', quizId).order('display_order');
    const { data: qs } = await supabase.from('questions').select('id,prompt,type,marks,status').eq('chapter_id', q.chapter_id).eq('usage', 'quiz');
    const map = new Map((qs ?? []).map((x: any) => [x.id, x]));
    setLinked((links ?? []).map((l: any) => ({ ...l, q: map.get(l.question_id) })));
    setBank((qs ?? []).filter((x: any) => !(links ?? []).some((l: any) => l.question_id === x.id)));
  }, [quizId]);
  useEffect(() => { load(); }, [load]);

  async function add(qid: string) {
    const r = await supabase.from('quiz_questions').insert({ quiz_id: quizId, question_id: qid, display_order: linked.length + 1 });
    if (r.error) setError(r.error.message); else load();
  }
  async function remove(qid: string) {
    const r = await supabase.from('quiz_questions').delete().eq('quiz_id', quizId).eq('question_id', qid);
    if (r.error) setError(r.error.message); else load();
  }
  async function move(i: number, d: -1 | 1) {
    const j = i + d; if (j < 0 || j >= linked.length) return;
    const order = [...linked]; [order[i], order[j]] = [order[j], order[i]];
    const rs = await Promise.all(order.map((l, k) => supabase.from('quiz_questions').update({ display_order: k + 1 }).eq('quiz_id', quizId).eq('question_id', l.question_id)));
    const bad = rs.find(r => r.error); if (bad?.error) setError(bad.error.message); load();
  }
  async function marks(qid: string, v: string) {
    const n = v === '' ? null : Number(v);
    const r = await supabase.from('quiz_questions').update({ marks_override: n }).eq('quiz_id', quizId).eq('question_id', qid);
    if (r.error) setError(r.error.message); else load();
  }

  return (<>
    <h2>Quiz questions{quiz ? `: ${quiz.title}` : ''}</h2>
    <p><a href="/quizzes">← Back to quizzes</a></p>
    <p className="help">Only questions of this chapter with “Used in: Quiz only” are offered. Unpublished questions are skipped when students take the quiz.</p>
    {error && <p className="err">{error}</p>}
    <h3>In this quiz</h3>
    <table><thead><tr><th>Order</th><th>Question</th><th>Type</th><th>Status</th><th>Marks (override)</th><th></th></tr></thead><tbody>
      {linked.map((l, i) => <tr key={l.question_id}>
        <td><button className="secondary" onClick={() => move(i, -1)}>↑</button> <button className="secondary" onClick={() => move(i, 1)}>↓</button></td>
        <td>{l.q?.prompt?.slice(0, 100)}</td><td>{l.q?.type}</td><td>{l.q?.status}</td>
        <td><input style={{ width: 90 }} type="number" step="0.5" defaultValue={l.marks_override ?? ''} placeholder={String(l.q?.marks ?? '')} onBlur={e => marks(l.question_id, e.target.value)} /></td>
        <td><button className="danger" onClick={() => remove(l.question_id)}>Remove</button></td></tr>)}
      {!linked.length && <tr><td colSpan={6}>No questions yet.</td></tr>}
    </tbody></table>
    <h3>Available in the question bank</h3>
    <table><tbody>
      {bank.map(q => <tr key={q.id}><td>{q.prompt.slice(0, 120)}</td><td>{q.type}</td><td>{q.status}</td><td><button onClick={() => add(q.id)}>Add</button></td></tr>)}
      {!bank.length && <tr><td>No more quiz questions in this chapter. Create some under “Questions & solutions”.</td></tr>}
    </tbody></table>
  </>);
}
export default function Page() { return <Guard><Suspense fallback={<p>Loading…</p>}><Inner /></Suspense></Guard>; }
