'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (<Guard>
    <CrudTable title="Chapters" table="chapters" hasStatus
      filter={{ key: "subject_id", label: "subject", ref: { table: "subjects", label: "name" } }}
      extraActions={(r) => <a className="btn secondary" style={{ background: "#fff", color: "#3f51b5", border: "1px solid #3f51b5" }} href={`/preview?chapter=${r.id}`}>Preview</a>}
      fields={[
        { key: "subject_id", label: "Subject", type: "ref", required: true, ref: { table: "subjects", label: "name" } },
        { key: "number", label: "Chapter number", type: "number", required: true },
        { key: "title", label: "Title (English)", type: "text", required: true },
        { key: "title_i18n", label: "Title (other languages)", type: "i18n" },
        { key: "description", label: "Description", type: "textarea" },
        { key: "objectives", label: "Learning objectives", type: "lines", inTable: false },
      ]} />
  </Guard>);
}
