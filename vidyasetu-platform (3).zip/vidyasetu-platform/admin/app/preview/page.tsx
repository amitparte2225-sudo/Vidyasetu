'use client';
import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { Guard } from '@/lib/Guard';
import { supabase } from '@/lib/supabase';

function Inner() {
  const id = useSearchParams().get('chapter') ?? '';
  const [chapter, setChapter] = useState<any>(null);
  const [resources, setResources] = useState<any[]>([]);
  const [questions, setQuestions] = useState<any[]>([]);
  const [urls, setUrls] = useState<Record<string, string>>({});
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => {
      const { data: c, error } = await supabase.from('chapters').select('*').eq('id', id).maybeSingle();
      if (error || !c) { setError(error?.message ?? 'Chapter not found'); return; }
      setChapter(c);
      const { data: r } = await supabase.from('resources').select('*').eq('chapter_id', id).order('display_order');
      setResources(r ?? []);
      const { data: q } = await supabase.from('questions').select('*, solutions(body_md,status)').eq('chapter_id', id).eq('usage', 'practice').order('display_order');
      setQuestions(q ?? []);
      const map: Record<string, string> = {};
      for (const x of r ?? []) if (x.file_path) {
        const s = await supabase.storage.from('content').createSignedUrl(x.file_path, 600);
        if (s.data) map[x.id] = s.data.signedUrl;
      }
      setUrls(map);
    })();
  }, [id]);

  const Md = ({ text }: { text: string }) => <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{text}</ReactMarkdown>;
  if (error) return <p className="err">{error}</p>;
  if (!chapter) return <p>Loading…</p>;
  return (<div className="preview">
    <p><a href="/chapters">← Chapters</a></p>
    <p className="help">Preview shows drafts too. Students only see published content.</p>
    <h2>{chapter.number}. {chapter.title} <span className={`badge ${chapter.status}`}>{chapter.status}</span></h2>
    <p>{chapter.description}</p>
    {resources.map(r => <div className="card" key={r.id}>
      <h3>{r.title} <span className={`badge ${r.status}`}>{r.status}</span> <small>({r.kind})</small></h3>
      {r.body_md && <Md text={r.body_md} />}
      {r.file_path && (urls[r.id]
        ? (r.mime_type?.startsWith('image/') ? <img src={urls[r.id]} alt={r.title} style={{ maxWidth: '100%' }} /> : <a className="btn" href={urls[r.id]} target="_blank" rel="noreferrer">Open file</a>)
        : <p className="help">Loading file…</p>)}
    </div>)}
    <h3>Practice questions</h3>
    {questions.map(q => <div className="card" key={q.id}><Md text={q.prompt} />
      {(q.solutions ?? []).map((s: any, i: number) => <div key={i}><b>Solution (verified)</b><Md text={s.body_md} /></div>)}</div>)}
  </div>);
}
export default function Page() { return <Guard><Suspense fallback={<p>Loading…</p>}><Inner /></Suspense></Guard>; }
