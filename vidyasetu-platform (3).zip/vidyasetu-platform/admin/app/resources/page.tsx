'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (<Guard>
    <CrudTable title="Notes, formulas, PDFs, images & diagrams" table="resources" hasStatus
      filter={{ key: "chapter_id", label: "chapter", ref: { table: "chapters", label: "title" } }}
      intro="Notes and formulas are Markdown; write mathematics in LaTeX between dollar signs, e.g. $x^2$ or $$\frac{a}{b}$$. Files: PDF, PNG, JPEG or WebP, up to 25 MB."
      fields={[
        { key: "chapter_id", label: "Chapter", type: "ref", required: true, ref: { table: "chapters", label: "title" } },
        { key: "topic_id", label: "Topic", type: "ref", ref: { table: "topics", label: "title" }, help: "optional" },
        { key: "kind", label: "Kind", type: "select", required: true, options: ["note", "formula", "solved_example", "pdf", "image", "diagram"].map(v => ({ value: v, label: v })) },
        { key: "title", label: "Title (English)", type: "text", required: true },
        { key: "title_i18n", label: "Title (other languages)", type: "i18n" },
        { key: "body_md", label: "Text (Markdown + LaTeX)", type: "textarea", showWhen: v => ["note", "formula", "solved_example"].includes(v.kind) },
        { key: "file", label: "File", type: "file", maxMb: 25, showWhen: v => ["pdf", "image", "diagram"].includes(v.kind) },
      ]} />
  </Guard>);
}
