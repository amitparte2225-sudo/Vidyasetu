'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (<Guard>
    <CrudTable title="Topics (optional, inside a chapter)" table="topics" hasStatus
      filter={{ key: "chapter_id", label: "chapter", ref: { table: "chapters", label: "title" } }}
      fields={[
        { key: "chapter_id", label: "Chapter", type: "ref", required: true, ref: { table: "chapters", label: "title" } },
        { key: "title", label: "Title (English)", type: "text", required: true },
        { key: "title_i18n", label: "Title (other languages)", type: "i18n" },
      ]} />
  </Guard>);
}
