'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (<Guard>
    <CrudTable title="Quizzes" table="quizzes" hasStatus
      filter={{ key: "chapter_id", label: "chapter", ref: { table: "chapters", label: "title" } }}
      extraActions={(r) => <a className="btn secondary" style={{ background: "#fff", color: "#3f51b5", border: "1px solid #3f51b5" }} href={`/quiz-questions?quiz=${r.id}`}>Questions</a>}
      intro="Create the quiz here, then press “Questions” to choose which question-bank questions it contains."
      fields={[
        { key: "chapter_id", label: "Chapter", type: "ref", required: true, ref: { table: "chapters", label: "title" } },
        { key: "title", label: "Title (English)", type: "text", required: true },
        { key: "title_i18n", label: "Title (other languages)", type: "i18n" },
        { key: "description", label: "Description", type: "textarea" },
        { key: "time_limit_seconds", label: "Time limit (seconds)", type: "number", help: "empty = untimed" },
        { key: "negative_marking", label: "Negative marking (0-1)", type: "number", required: true, help: "0.25 = lose a quarter of the marks per wrong answer" },
        { key: "pass_percentage", label: "Pass percentage", type: "number", required: true },
        { key: "shuffle_questions", label: "Shuffle questions", type: "bool" },
      ]} defaults={{ negative_marking: 0, pass_percentage: 40, shuffle_questions: true }} />
  </Guard>);
}
