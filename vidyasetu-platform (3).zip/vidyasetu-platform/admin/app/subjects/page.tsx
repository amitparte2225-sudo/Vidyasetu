'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (<Guard>
    <CrudTable title="Subjects" table="subjects" hasStatus
      filter={{ key: "level_id", label: "class / degree / semester", ref: { table: "levels", label: "name" } }}
      fields={[
        { key: "level_id", label: "Class / degree / semester", type: "ref", required: true, ref: { table: "levels", label: "name" } },
        { key: "name", label: "Name (English)", type: "text", required: true },
        { key: "name_i18n", label: "Name (other languages)", type: "i18n" },
        { key: "description", label: "Description", type: "textarea" },
      ]} />
  </Guard>);
}
