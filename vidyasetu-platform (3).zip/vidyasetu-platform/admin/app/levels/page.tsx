'use client';
import { Guard } from '@/lib/Guard';
import CrudTable from '@/components/CrudTable';

export default function Page() {
  return (<Guard>
    <CrudTable title="Classes, degrees & semesters" table="levels" hasStatus
      intro="Top-level entries (no parent) appear on the app home screen. Give a degree child semesters by choosing it as the parent."
      fields={[
        { key: "institution_id", label: "Board / university", type: "ref", required: true, ref: { table: "institutions", label: "name" } },
        { key: "parent_id", label: "Parent (for semesters)", type: "ref", ref: { table: "levels", label: "name" }, help: "optional" },
        { key: "kind", label: "Kind", type: "select", required: true, options: ["class", "degree", "year", "semester"].map(v => ({ value: v, label: v })) },
        { key: "name", label: "Name (English)", type: "text", required: true },
        { key: "name_i18n", label: "Name (other languages)", type: "i18n" },
        { key: "description", label: "Description", type: "textarea" },
      ]} />
  </Guard>);
}
