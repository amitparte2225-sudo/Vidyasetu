'use client';
import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { supabase, LANGS } from '@/lib/supabase';
import { useAdmin } from '@/lib/Guard';
import { safeName, validateFile } from '@/lib/files';

export type Field = {
  key: string; label: string;
  type: 'text' | 'textarea' | 'number' | 'select' | 'ref' | 'i18n' | 'lines' | 'file' | 'bool';
  required?: boolean; help?: string;
  options?: { value: string; label: string }[];
  ref?: { table: string; label: string };
  showWhen?: (v: Record<string, any>) => boolean;
  maxMb?: number; inTable?: boolean;
};
export type RefOpts = Record<string, { value: string; label: string }[]>;

type Props = {
  title: string; table: string; fields: Field[];
  orderBy?: string; hasStatus?: boolean; reorder?: boolean;
  filter?: { key: string; label: string; ref: { table: string; label: string } };
  extraActions?: (row: any) => ReactNode;
  defaults?: Record<string, any>; intro?: string;
};

export default function CrudTable(p: Props) {
  const admin = useAdmin();
  const canPublish = admin.perms.has('content.publish');
  const orderBy = p.orderBy ?? 'display_order';
  const [rows, setRows] = useState<any[]>([]);
  const [refs, setRefs] = useState<RefOpts>({});
  const [filterVal, setFilterVal] = useState('');
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<any | null>(null); // null = closed, {} = new
  const [form, setForm] = useState<Record<string, any>>({});
  const [files, setFiles] = useState<Record<string, File | null>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const refFields = useMemo(() => {
    const list = p.fields.filter(f => f.type === 'ref' && f.ref).map(f => ({ key: f.key, ...f.ref! }));
    if (p.filter) list.push({ key: p.filter.key, ...p.filter.ref });
    return list;
  }, [p.fields, p.filter]);

  useEffect(() => {
    (async () => {
      const out: RefOpts = {};
      for (const r of refFields) {
        const { data } = await supabase.from(r.table).select(`id, ${r.label}`).order(r.label).limit(1000);
        out[r.key] = (data ?? []).map((d: any) => ({ value: d.id, label: String(d[r.label]) }));
      }
      setRefs(out);
    })();
  }, [refFields]);

  const load = useCallback(async () => {
    let q = supabase.from(p.table).select('*').order(orderBy, { ascending: true }).limit(500);
    if (p.filter && filterVal) q = q.eq(p.filter.key, filterVal);
    const { data, error } = await q;
    if (error) setError(error.message); else { setRows(data ?? []); setError(''); }
  }, [p.table, p.filter, filterVal, orderBy]);
  useEffect(() => { load(); }, [load]);

  const labelOf = (key: string, id: string) => refs[key]?.find(o => o.value === id)?.label ?? id?.slice?.(0, 8) ?? '';

  function openEditor(row: any | null) {
    setError(''); setInfo(''); setFiles({});
    const base: Record<string, any> = { ...(p.defaults ?? {}) };
    if (p.filter && filterVal) base[p.filter.key] = filterVal;
    if (row) {
      for (const f of p.fields) {
        if (f.type === 'i18n') base[f.key] = row[f.key] ?? {};
        else if (f.type === 'lines') base[f.key] = (row[f.key] ?? []).join('\n');
        else base[f.key] = row[f.key] ?? '';
      }
      base.id = row.id;
    } else {
      for (const f of p.fields) if (base[f.key] === undefined) base[f.key] = f.type === 'i18n' ? {} : f.type === 'bool' ? false : '';
    }
    setForm(base); setEditing(row ?? {});
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError('');
    try {
      const payload: Record<string, any> = {};
      for (const f of p.fields) {
        if (f.showWhen && !f.showWhen(form)) continue;
        let v = form[f.key];
        if (f.type === 'file') continue;
        if (f.type === 'number') v = v === '' || v == null ? null : Number(v);
        else if (f.type === 'lines') v = String(v || '').split('\n').map(s => s.trim()).filter(Boolean);
        else if (f.type === 'i18n') v = Object.fromEntries(Object.entries(v || {}).filter(([, t]) => String(t).trim()));
        else if (f.type === 'bool') v = !!v;
        else if (typeof v === 'string') v = v.trim() === '' ? null : v;
        if (f.required && (v === null || v === '' || (typeof v === 'number' && Number.isNaN(v)))) throw new Error(`“${f.label}” is required.`);
        payload[f.key] = v;
      }
      for (const f of p.fields.filter(x => x.type === 'file' && (!x.showWhen || x.showWhen(form)))) {
        const file = files[f.key];
        if (!file) { if (f.required && !form.file_path) throw new Error(`Choose a file for “${f.label}”.`); continue; }
        const bad = await validateFile(file, f.maxMb ?? 25);
        if (bad) throw new Error(bad);
        const folder = payload.chapter_id ?? form.chapter_id ?? 'misc';
        const path = `${folder}/${crypto.randomUUID()}-${safeName(file.name)}`;
        const up = await supabase.storage.from('content').upload(path, file, { contentType: file.type, upsert: false });
        if (up.error) throw new Error('Upload failed: ' + up.error.message);
        payload.file_path = path; payload.mime_type = file.type; payload.size_bytes = file.size;
      }
      const res = form.id
        ? await supabase.from(p.table).update(payload).eq('id', form.id)
        : await supabase.from(p.table).insert(payload);
      if (res.error) throw new Error(res.error.message);
      setEditing(null); setInfo('Saved.'); await load();
    } catch (err: any) { setError(err.message ?? String(err)); }
    setBusy(false);
  }

  async function setStatus(row: any, status: string) {
    const { error } = await supabase.from(p.table).update({ status }).eq('id', row.id);
    if (error) setError(error.message); else { setInfo(`Status changed to ${status}.`); load(); }
  }

  async function remove(row: any) {
    if (!confirm('Delete permanently? Consider Archive instead. Everything inside it is deleted too.')) return;
    const { error } = await supabase.from(p.table).delete().eq('id', row.id);
    if (error) setError(error.message); else { if (row.file_path) await supabase.storage.from('content').remove([row.file_path]); load(); }
  }

  async function move(index: number, dir: -1 | 1) {
    const j = index + dir;
    if (j < 0 || j >= visible.length) return;
    const order = [...visible]; [order[index], order[j]] = [order[j], order[index]];
    const updates = order.map((r, i) => ({ r, pos: i + 1 })).filter(x => x.r.display_order !== x.pos);
    const results = await Promise.all(updates.map(x => supabase.from(p.table).update({ display_order: x.pos }).eq('id', x.r.id)));
    const failed = results.find(r => r.error);
    if (failed?.error) setError(failed.error.message);
    load();
  }

  const visible = rows.filter(r => !search || JSON.stringify(r).toLowerCase().includes(search.toLowerCase()));
  const columns = p.fields.filter(f => f.inTable !== false && !['textarea', 'lines', 'i18n', 'file'].includes(f.type));

  const input = (f: Field) => {
    const v = form[f.key] ?? '';
    const set = (x: any) => setForm({ ...form, [f.key]: x });
    switch (f.type) {
      case 'textarea': return <textarea value={v} onChange={e => set(e.target.value)} />;
      case 'lines': return <textarea value={v} onChange={e => set(e.target.value)} placeholder="One item per line" />;
      case 'number': return <input type="number" step="any" value={v} onChange={e => set(e.target.value)} />;
      case 'bool': return <input type="checkbox" checked={!!form[f.key]} onChange={e => set(e.target.checked)} style={{ width: 'auto' }} />;
      case 'select': return <select value={v} onChange={e => set(e.target.value)}><option value="">—</option>{f.options!.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select>;
      case 'ref': return <select value={v} onChange={e => set(e.target.value)}><option value="">— choose —</option>{(refs[f.key] ?? []).map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select>;
      case 'i18n': return <>{LANGS.map(l => (
        <input key={l.code} placeholder={l.label} value={(form[f.key] ?? {})[l.code] ?? ''}
          onChange={e => set({ ...(form[f.key] ?? {}), [l.code]: e.target.value })} />))}</>;
      case 'file': return <>
        <input type="file" accept=".pdf,.png,.jpg,.jpeg,.webp" onChange={e => setFiles({ ...files, [f.key]: e.target.files?.[0] ?? null })} />
        {form.file_path && <span className="help">Current file: {form.file_path}</span>}</>;
      default: return <input value={v} onChange={e => set(e.target.value)} />;
    }
  };

  return (
    <>
      <h2>{p.title}</h2>
      {p.intro && <p className="help">{p.intro}</p>}
      <div className="row" style={{ marginBottom: 12 }}>
        {p.filter && (
          <select style={{ width: 260 }} value={filterVal} onChange={e => setFilterVal(e.target.value)}>
            <option value="">All ({p.filter.label})</option>
            {(refs[p.filter.key] ?? []).map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>)}
        <input style={{ width: 220 }} placeholder="Search…" value={search} onChange={e => setSearch(e.target.value)} />
        <button onClick={() => openEditor(null)}>+ New</button>
      </div>
      {error && <p className="err">{error}</p>}
      {info && <p className="okmsg">{info}</p>}

      {editing && (
        <form className="card" onSubmit={save}>
          <h3>{form.id ? 'Edit' : 'New'}</h3>
          <div className="grid2">
            {p.fields.filter(f => !f.showWhen || f.showWhen(form)).map(f => (
              <div key={f.key} style={f.type === 'textarea' || f.type === 'lines' ? { gridColumn: '1 / -1' } : undefined}>
                <label>{f.label}{f.required ? ' *' : ''} {f.help && <span className="help">— {f.help}</span>}</label>
                {input(f)}
              </div>))}
          </div>
          {p.hasStatus && <p className="help">New items start as drafts. Publish from the table when ready.{!canPublish && ' You do not have permission to publish.'}</p>}
          <div className="row"><button disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
            <button type="button" className="secondary" onClick={() => setEditing(null)}>Cancel</button></div>
        </form>)}

      <table>
        <thead><tr>{p.reorder !== false && <th>Order</th>}{columns.map(f => <th key={f.key}>{f.label}</th>)}{p.hasStatus && <th>Status</th>}<th>Actions</th></tr></thead>
        <tbody>
          {visible.map((r, i) => (
            <tr key={r.id}>
              {p.reorder !== false && <td><button className="secondary" onClick={() => move(i, -1)} disabled={!!search}>↑</button>{' '}<button className="secondary" onClick={() => move(i, 1)} disabled={!!search}>↓</button></td>}
              {columns.map(f => <td key={f.key}>{f.type === 'ref' ? labelOf(f.key, r[f.key]) : f.type === 'bool' ? (r[f.key] ? 'yes' : 'no') : String(r[f.key] ?? '')}</td>)}
              {p.hasStatus && <td><span className={`badge ${r.status}`}>{r.status}</span></td>}
              <td className="row">
                <button className="secondary" onClick={() => openEditor(r)}>Edit</button>
                {p.hasStatus && canPublish && <>
                  {r.status !== 'published' && <button onClick={() => setStatus(r, 'published')}>Publish</button>}
                  {r.status === 'published' && <button className="secondary" onClick={() => setStatus(r, 'draft')}>Unpublish</button>}
                  {r.status !== 'archived' && <button className="secondary" onClick={() => setStatus(r, 'archived')}>Archive</button>}
                </>}
                {p.extraActions?.(r)}
                <button className="danger" onClick={() => remove(r)}>Delete</button>
              </td>
            </tr>))}
          {visible.length === 0 && <tr><td colSpan={columns.length + 3}>Nothing here yet. Use “+ New”.</td></tr>}
        </tbody>
      </table>
    </>
  );
}
