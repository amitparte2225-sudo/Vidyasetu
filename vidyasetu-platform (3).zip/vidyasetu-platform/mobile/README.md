# Vidyasetu mobile app (Flutter)

See the root README. Code map: `lib/core` (theme, strings, settings), `lib/models`, `lib/data` (Supabase repositories),
`lib/services` (backend client), `lib/features/*` (screens), `lib/widgets`. Tests: `test/unit` (must pass in CI), `test/widget_test.dart`.
