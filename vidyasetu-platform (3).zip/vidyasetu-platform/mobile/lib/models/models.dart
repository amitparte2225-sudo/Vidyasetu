import '../core/localized_text.dart';

double _d(Object? v) => v is num ? v.toDouble() : double.tryParse('$v') ?? 0;
int _i(Object? v) => v is num ? v.toInt() : int.tryParse('$v') ?? 0;
Map<String, dynamic> _m(Object? v) => v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};

class Level {
  const Level({required this.id, required this.institutionId, required this.parentId, required this.kind,
      required this.name, required this.institutionName});
  final String id;
  final String institutionId;
  final String? parentId;
  final String kind; // class | degree | year | semester
  final LocalizedText name;
  final LocalizedText institutionName;

  factory Level.fromRow(Map<String, dynamic> r) {
    final inst = _m(r['institutions']);
    return Level(
      id: r['id'], institutionId: r['institution_id'], parentId: r['parent_id'], kind: r['kind'],
      name: LocalizedText.fromRow(r['name'], r['name_i18n']),
      institutionName: LocalizedText.fromRow(inst['name'] ?? '', inst['name_i18n']),
    );
  }
}

class Subject {
  const Subject({required this.id, required this.levelId, required this.name});
  final String id;
  final String levelId;
  final LocalizedText name;
  factory Subject.fromRow(Map<String, dynamic> r) =>
      Subject(id: r['id'], levelId: r['level_id'], name: LocalizedText.fromRow(r['name'], r['name_i18n']));
}

class Chapter {
  const Chapter({required this.id, required this.subjectId, required this.number, required this.title,
      required this.description, required this.objectives});
  final String id;
  final String subjectId;
  final int number;
  final LocalizedText title;
  final LocalizedText description;
  final List<String> objectives;
  factory Chapter.fromRow(Map<String, dynamic> r) => Chapter(
        id: r['id'], subjectId: r['subject_id'], number: _i(r['number']),
        title: LocalizedText.fromRow(r['title'], r['title_i18n']),
        description: LocalizedText.fromRow(r['description'] ?? '', r['description_i18n']),
        objectives: (r['objectives'] is List) ? (r['objectives'] as List).map((e) => '$e').toList() : const [],
      );
}

/// A chapter plus the names needed for the breadcrumb.
class ChapterContext {
  const ChapterContext(this.chapter, this.subjectName, this.levelName, this.levelId, this.subjectId);
  final Chapter chapter;
  final LocalizedText subjectName;
  final LocalizedText levelName;
  final String levelId;
  final String subjectId;
}

class Resource {
  const Resource({required this.id, required this.chapterId, required this.kind, required this.title,
      required this.body, required this.filePath, required this.mimeType});
  final String id;
  final String chapterId;
  final String kind; // note | formula | solved_example | pdf | image | diagram
  final LocalizedText title;
  final LocalizedText body;
  final String? filePath;
  final String? mimeType;
  bool get isText => kind == 'note' || kind == 'formula' || kind == 'solved_example';
  bool get isPdf => kind == 'pdf';
  bool get isImage => kind == 'image' || kind == 'diagram';
  factory Resource.fromRow(Map<String, dynamic> r) => Resource(
        id: r['id'], chapterId: r['chapter_id'], kind: r['kind'],
        title: LocalizedText.fromRow(r['title'], r['title_i18n']),
        body: LocalizedText.fromRow(r['body_md'] ?? '', r['body_i18n']),
        filePath: r['file_path'], mimeType: r['mime_type'],
      );
}

class QuestionOption {
  const QuestionOption(this.id, this.text);
  final String id;
  final String text;
}

class Question {
  const Question({required this.id, required this.type, required this.prompt, required this.options,
      required this.marks, this.solution, this.solutionVerified = true});
  final String id;
  final String type; // mcq_single | mcq_multi | true_false | numeric | short_answer
  final LocalizedText prompt;
  final List<QuestionOption> options;
  final double marks;
  final String? solution;
  final bool solutionVerified;

  static List<QuestionOption> parseOptions(Object? v) => (v is List)
      ? v.map((o) => QuestionOption('${_m(o)['id']}', '${_m(o)['text']}')).toList()
      : const [];

  factory Question.fromRow(Map<String, dynamic> r) {
    final sols = (r['solutions'] is List) ? (r['solutions'] as List) : const [];
    final sol = sols.isEmpty ? null : _m(sols.first);
    return Question(
      id: r['id'], type: r['type'], prompt: LocalizedText.fromRow(r['prompt'], r['prompt_i18n']),
      options: parseOptions(r['options']), marks: _d(r['marks']),
      solution: sol?['body_md'], solutionVerified: sol?['is_verified'] != false,
    );
  }
}

class Quiz {
  const Quiz({required this.id, required this.chapterId, required this.title, required this.description,
      required this.timeLimitSeconds, required this.negativeMarking, required this.passPercentage});
  final String id;
  final String chapterId;
  final LocalizedText title;
  final String? description;
  final int? timeLimitSeconds;
  final double negativeMarking;
  final double passPercentage;
  factory Quiz.fromRow(Map<String, dynamic> r) => Quiz(
        id: r['id'], chapterId: r['chapter_id'], title: LocalizedText.fromRow(r['title'], r['title_i18n']),
        description: r['description'], timeLimitSeconds: r['time_limit_seconds'] == null ? null : _i(r['time_limit_seconds']),
        negativeMarking: _d(r['negative_marking']), passPercentage: _d(r['pass_percentage']),
      );
}

class QuizQuestion {
  const QuizQuestion({required this.id, required this.type, required this.prompt, required this.options, required this.marks});
  final String id;
  final String type;
  final String prompt;
  final List<QuestionOption> options;
  final double marks;
  factory QuizQuestion.fromJson(Map<String, dynamic> j) => QuizQuestion(
      id: j['id'], type: j['type'], prompt: '${j['prompt']}', options: Question.parseOptions(j['options']), marks: _d(j['marks']));
}

class QuizSession {
  const QuizSession({required this.attemptId, required this.title, required this.timeLimitSeconds,
      required this.expiresAt, required this.negativeMarking, required this.questions});
  final String attemptId;
  final String title;
  final int? timeLimitSeconds;
  final DateTime? expiresAt;
  final double negativeMarking;
  final List<QuizQuestion> questions;
  factory QuizSession.fromJson(Map<String, dynamic> j) => QuizSession(
        attemptId: j['attempt_id'], title: '${j['title']}',
        timeLimitSeconds: j['time_limit_seconds'] == null ? null : _i(j['time_limit_seconds']),
        expiresAt: j['expires_at'] == null ? null : DateTime.parse(j['expires_at']),
        negativeMarking: _d(j['negative_marking']),
        questions: (j['questions'] as List).map((q) => QuizQuestion.fromJson(_m(q))).toList(),
      );
}

class ReviewItem {
  const ReviewItem({required this.type, required this.prompt, required this.options, required this.marks,
      required this.response, required this.isCorrect, required this.awarded, required this.correct, required this.explanation});
  final String type;
  final String prompt;
  final List<QuestionOption> options;
  final double marks;
  final dynamic response;
  final bool? isCorrect;
  final double awarded;
  final List<dynamic> correct;
  final String? explanation;
  factory ReviewItem.fromJson(Map<String, dynamic> j) => ReviewItem(
        type: j['type'], prompt: '${j['prompt']}', options: Question.parseOptions(j['options']), marks: _d(j['marks']),
        response: j['response'], isCorrect: j['is_correct'], awarded: _d(j['awarded']),
        correct: (j['correct'] as List?) ?? const [], explanation: j['explanation'],
      );
}

class QuizResult {
  const QuizResult({required this.attemptId, required this.score, required this.maxScore, required this.percentage,
      required this.passed, required this.correct, required this.wrong, required this.unanswered, required this.review});
  final String attemptId;
  final double score, maxScore, percentage;
  final bool? passed;
  final int correct, wrong, unanswered;
  final List<ReviewItem> review;
  factory QuizResult.fromJson(Map<String, dynamic> j) => QuizResult(
        attemptId: j['attempt_id'], score: _d(j['score']), maxScore: _d(j['max_score']), percentage: _d(j['percentage']),
        passed: j['passed'], correct: _i(j['correct_count']), wrong: _i(j['wrong_count']), unanswered: _i(j['unanswered_count']),
        review: (j['review'] as List).map((r) => ReviewItem.fromJson(_m(r))).toList(),
      );
}

class ChapterProgress {
  const ChapterProgress(this.attempts, this.bestPercentage);
  final int attempts;
  final double bestPercentage;
}

class SearchHit {
  const SearchHit({required this.kind, required this.id, required this.title, this.subtitle, this.levelId, this.subjectId, this.chapterId});
  final String kind; // level | subject | chapter | resource | question
  final String id;
  final String title;
  final String? subtitle;
  final String? levelId, subjectId, chapterId;
  factory SearchHit.fromRow(Map<String, dynamic> r) => SearchHit(
      kind: r['kind'], id: r['id'], title: '${r['title']}', subtitle: r['subtitle'],
      levelId: r['level_id'], subjectId: r['subject_id'], chapterId: r['chapter_id']);
}

class SolutionStep {
  const SolutionStep(this.title, this.explanation, this.calculation);
  final String title, explanation, calculation;
}

class AiSolution {
  const AiSolution({required this.readable, this.unreadableReason, required this.questionUnderstood,
      required this.concepts, required this.steps, required this.intermediate, required this.finalAnswer,
      this.units, required this.assumptions, required this.explanation, required this.verificationStatus,
      required this.verificationDetail});
  final bool readable;
  final String? unreadableReason;
  final String questionUnderstood;
  final List<String> concepts;
  final List<SolutionStep> steps;
  final List<String> intermediate;
  final String finalAnswer;
  final String? units;
  final List<String> assumptions;
  final String explanation;
  final String verificationStatus; // verified | mismatch | unavailable
  final String verificationDetail;

  factory AiSolution.fromJson(Map<String, dynamic> j) {
    List<String> strs(Object? v) => (v is List) ? v.map((e) => '$e').toList() : const [];
    final ver = _m(j['verification']);
    return AiSolution(
      readable: j['readable'] != false, unreadableReason: j['unreadable_reason'],
      questionUnderstood: '${j['question_understood'] ?? ''}', concepts: strs(j['concepts']),
      steps: (j['steps'] is List)
          ? (j['steps'] as List).map((s) => SolutionStep('${_m(s)['title'] ?? ''}', '${_m(s)['explanation'] ?? ''}', '${_m(s)['calculation'] ?? ''}')).toList()
          : const [],
      intermediate: strs(j['intermediate_results']), finalAnswer: '${j['final_answer'] ?? ''}', units: j['units'],
      assumptions: strs(j['assumptions']), explanation: '${j['explanation'] ?? ''}',
      verificationStatus: '${ver['status'] ?? 'unavailable'}', verificationDetail: '${ver['detail'] ?? ''}',
    );
  }
}

class SolverRecord {
  const SolverRecord({required this.id, required this.source, required this.questionText, required this.solution, required this.createdAt});
  final String id, source, questionText;
  final AiSolution? solution;
  final DateTime createdAt;
  factory SolverRecord.fromRow(Map<String, dynamic> r) => SolverRecord(
        id: r['id'], source: r['source'], questionText: '${r['question_text']}',
        solution: r['solution'] is Map ? AiSolution.fromJson(_m(r['solution'])) : null,
        createdAt: DateTime.parse(r['created_at']),
      );
}

class Profile {
  const Profile({required this.id, required this.displayName, required this.language, required this.levelId});
  final String id;
  final String displayName;
  final String language;
  final String? levelId;
  factory Profile.fromRow(Map<String, dynamic> r) => Profile(
      id: r['id'], displayName: '${r['display_name'] ?? ''}', language: '${r['preferred_language'] ?? 'en'}', levelId: r['level_id']);
}
