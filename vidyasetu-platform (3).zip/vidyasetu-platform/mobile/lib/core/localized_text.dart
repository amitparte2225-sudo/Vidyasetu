/// A piece of content in several languages. English is the base; other languages come from the
/// database *_i18n column, e.g. {"mr": "..."}. Falls back to English, so adding a language never
/// breaks existing content.
class LocalizedText {
  const LocalizedText(this.values);

  factory LocalizedText.fromRow(Object? base, Object? i18n) {
    final map = <String, String>{'en': '${base ?? ''}'};
    if (i18n is Map) {
      i18n.forEach((k, v) {
        if ('$v'.trim().isNotEmpty) map['$k'] = '$v';
      });
    }
    return LocalizedText(map);
  }

  final Map<String, String> values;

  String resolve(String languageCode) {
    final v = values[languageCode];
    return (v != null && v.isNotEmpty) ? v : (values['en'] ?? '');
  }
}
