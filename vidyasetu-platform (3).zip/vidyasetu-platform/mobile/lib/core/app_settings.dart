import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// App-wide settings (content language), remembered on the device.
class AppSettings extends ChangeNotifier {
  AppSettings([this._languageCode = 'en']);

  String _languageCode;
  String get languageCode => _languageCode;

  static Future<AppSettings> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return AppSettings(prefs.getString('language') ?? 'en');
    } catch (_) {
      return AppSettings();
    }
  }

  Future<void> setLanguage(String code) async {
    if (code == _languageCode) return;
    _languageCode = code;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('language', code);
    } catch (_) {/* not fatal */}
  }
}

class AppScope extends InheritedNotifier<AppSettings> {
  const AppScope({super.key, required AppSettings settings, required super.child}) : super(notifier: settings);

  /// Inside build(): rebuilds when settings change.
  static AppSettings of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'No AppScope found above this widget');
    return scope!.notifier!;
  }

  /// Inside callbacks: no subscription.
  static AppSettings read(BuildContext context) {
    final scope = context.getInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'No AppScope found above this widget');
    return scope!.notifier!;
  }
}
