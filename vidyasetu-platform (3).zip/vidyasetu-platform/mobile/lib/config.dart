/// Build-time configuration. Pass with --dart-define (see README). None of these are secrets:
/// the Supabase anon key is public by design (Row Level Security protects the data).
/// The service-role key and AI keys must NEVER appear in this app.
class AppConfig {
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');
  static const backendUrl = String.fromEnvironment('BACKEND_URL');

  static bool get supabaseConfigured =>
      supabaseUrl.startsWith('http') && supabaseAnonKey.isNotEmpty;
  static bool get backendConfigured => backendUrl.startsWith('http');
}
