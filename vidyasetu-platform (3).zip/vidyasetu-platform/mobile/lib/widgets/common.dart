import 'package:flutter/material.dart';

import '../core/strings.dart';
import '../data/user_repository.dart';

void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

String errorText(Object e) => e.toString().replaceFirst('Exception: ', '');

/// Report inappropriate or wrong content. Administrators review reports in the dashboard.
Future<void> showReportDialog(BuildContext context, String kind, String targetId) async {
  final controller = TextEditingController();
  final send = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(ctx.tr('report_title')),
      content: TextField(
        controller: controller, maxLines: 3, maxLength: 500,
        decoration: InputDecoration(hintText: ctx.tr('report_hint')),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('send'))),
      ],
    ),
  );
  if (send != true || controller.text.trim().length < 3) return;
  try {
    await userRepository.report(kind, targetId, controller.text);
    if (context.mounted) showMessage(context, context.tr('report_thanks'));
  } catch (e) {
    if (context.mounted) showMessage(context, errorText(e));
  }
}

/// Bookmark toggle button that reads/writes the student's bookmarks.
class BookmarkButton extends StatefulWidget {
  const BookmarkButton({super.key, required this.kind, required this.targetId});
  final String kind;
  final String targetId;

  @override
  State<BookmarkButton> createState() => _BookmarkButtonState();
}

class _BookmarkButtonState extends State<BookmarkButton> {
  bool? _on;

  @override
  void initState() {
    super.initState();
    userRepository.isBookmarked(widget.kind, widget.targetId).then((v) {
      if (mounted) setState(() => _on = v);
    }).catchError((_) {});
  }

  Future<void> _toggle() async {
    final next = !(_on ?? false);
    setState(() => _on = next);
    try {
      await userRepository.setBookmark(widget.kind, widget.targetId, next);
    } catch (e) {
      if (!mounted) return;
      setState(() => _on = !next);
      showMessage(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: context.tr('bookmark'),
        icon: Icon((_on ?? false) ? Icons.bookmark : Icons.bookmark_border),
        onPressed: _on == null ? null : _toggle,
      );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(0, 16, 0, 8),
        child: Text(text, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
      );
}
