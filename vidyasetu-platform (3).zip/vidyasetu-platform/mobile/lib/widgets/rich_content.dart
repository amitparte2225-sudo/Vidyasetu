import 'package:flutter/material.dart';
import 'package:flutter_math_fork/flutter_math.dart';

/// Renders text with LaTeX ($inline$ and $$display$$), **bold**, "# headings" and "- bullets".
/// Used for notes, formulas, questions, quizzes and AI solutions.
class RichContent extends StatelessWidget {
  const RichContent(this.text, {super.key, this.style});

  final String text;
  final TextStyle? style;

  static final _display = RegExp(r'\$\$(.+?)\$\$', dotAll: true);
  static final _inlineRe = RegExp(r'\*\*(.+?)\*\*|\$(.+?)\$');

  @override
  Widget build(BuildContext context) {
    final base = style ?? Theme.of(context).textTheme.bodyMedium ?? const TextStyle();
    final children = <Widget>[];
    var last = 0;
    for (final m in _display.allMatches(text)) {
      _addText(context, children, text.substring(last, m.start), base);
      final tex = m.group(1)!.trim();
      children.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Center(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Math.tex(tex,
                mathStyle: MathStyle.display,
                textStyle: base.copyWith(fontSize: (base.fontSize ?? 14) * 1.15),
                onErrorFallback: (_) => Text(tex, style: base)),
          ),
        ),
      ));
      last = m.end;
    }
    _addText(context, children, text.substring(last), base);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: children);
  }

  void _addText(BuildContext context, List<Widget> out, String chunk, TextStyle base) {
    final theme = Theme.of(context).textTheme;
    for (final raw in chunk.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      if (line.startsWith('## ')) {
        out.add(Padding(padding: const EdgeInsets.only(top: 8, bottom: 2),
            child: Text(line.substring(3), style: theme.titleMedium?.copyWith(fontWeight: FontWeight.bold))));
      } else if (line.startsWith('# ')) {
        out.add(Padding(padding: const EdgeInsets.only(top: 8, bottom: 4),
            child: Text(line.substring(2), style: theme.titleLarge?.copyWith(fontWeight: FontWeight.bold))));
      } else if (line.startsWith('- ') || line.startsWith('* ')) {
        out.add(Padding(
          padding: const EdgeInsets.only(left: 8, top: 2, bottom: 2),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('•  ', style: base),
            Expanded(child: Text.rich(_inline(line.substring(2), base))),
          ]),
        ));
      } else {
        out.add(Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Text.rich(_inline(line, base))));
      }
    }
  }

  TextSpan _inline(String s, TextStyle base) {
    final spans = <InlineSpan>[];
    var last = 0;
    for (final m in _inlineRe.allMatches(s)) {
      if (m.start > last) spans.add(TextSpan(text: s.substring(last, m.start)));
      if (m.group(1) != null) {
        spans.add(TextSpan(text: m.group(1), style: const TextStyle(fontWeight: FontWeight.bold)));
      } else {
        final tex = m.group(2)!;
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: Math.tex(tex, textStyle: base, onErrorFallback: (_) => Text('\$$tex\$', style: base)),
        ));
      }
      last = m.end;
    }
    if (last < s.length) spans.add(TextSpan(text: s.substring(last)));
    return TextSpan(style: base, children: spans);
  }
}

/// Wrap raw LaTeX (no dollar signs) so RichContent shows it as display maths.
String asDisplayMath(String s) => s.contains(r'$') ? s : '\$\$$s\$\$';
