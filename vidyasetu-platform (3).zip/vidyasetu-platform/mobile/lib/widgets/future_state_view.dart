import 'package:flutter/material.dart';

import '../core/strings.dart';

/// Runs [load] and shows a loading spinner, an error with a retry button,
/// an empty message, or the real content via [builder].
class FutureStateView<T> extends StatefulWidget {
  const FutureStateView({
    super.key,
    required this.load,
    required this.builder,
    required this.emptyMessage,
    this.isEmpty,
  });

  final Future<T> Function() load;
  final Widget Function(BuildContext context, T data) builder;
  final String emptyMessage;
  final bool Function(T data)? isEmpty;

  @override
  State<FutureStateView<T>> createState() => _FutureStateViewState<T>();
}

class _FutureStateViewState<T> extends State<FutureStateView<T>> {
  late Future<T> _future;

  @override
  void initState() {
    super.initState();
    _future = widget.load();
  }

  void _retry() {
    setState(() {
      _future = widget.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<T>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return _Message(
            icon: Icons.error_outline,
            text: context.tr('error_generic'),
            actionLabel: context.tr('retry'),
            onAction: _retry,
          );
        }
        final data = snapshot.data as T;
        final empty = widget.isEmpty;
        if (empty != null && empty(data)) {
          return _Message(icon: Icons.inbox_outlined, text: widget.emptyMessage);
        }
        return widget.builder(context, data);
      },
    );
  }
}

class _Message extends StatelessWidget {
  const _Message({
    required this.icon,
    required this.text,
    this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String text;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: scheme.outline),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 16),
              FilledButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}
