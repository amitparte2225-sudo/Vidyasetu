import 'package:flutter/material.dart';

/// "Home > Class 10 > Mathematics Part 1" style trail.
class Breadcrumb extends StatelessWidget {
  const Breadcrumb({super.key, required this.items});

  final List<String> items;

  @override
  Widget build(BuildContext context) {
    final style = Theme.of(context).textTheme.bodySmall;
    final color = Theme.of(context).colorScheme.onSurfaceVariant;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Wrap(
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          for (var i = 0; i < items.length; i++) ...[
            if (i > 0) Icon(Icons.chevron_right, size: 16, color: color),
            Text(items[i], style: style?.copyWith(color: color)),
          ],
        ],
      ),
    );
  }
}
