import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/app_settings.dart';
import '../core/strings.dart';
import '../data/user_repository.dart';

class LanguageMenu extends StatelessWidget {
  const LanguageMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.translate),
      tooltip: context.tr('language'),
      onSelected: (code) async {
        await AppScope.read(context).setLanguage(code);
        try {
          if (Supabase.instance.client.auth.currentUser != null) {
            await userRepository.updateProfile(language: code);
          }
        } catch (_) {/* the choice is also saved on the device */}
      },
      itemBuilder: (_) => const [
        PopupMenuItem(value: 'en', child: Text('English')),
        PopupMenuItem(value: 'mr', child: Text('मराठी')),
      ],
    );
  }
}
