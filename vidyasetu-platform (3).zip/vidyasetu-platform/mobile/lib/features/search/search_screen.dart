import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../data/content_repository.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import '../catalog/chapter_detail_screen.dart';
import '../catalog/chapter_list_screen.dart';
import '../catalog/level_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _controller = TextEditingController();
  Timer? _debounce;
  List<SearchHit>? _hits;
  bool _loading = false;
  String? _error;
  String _lastQuery = '';

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onChanged(String q) {
    _debounce?.cancel();
    if (q.trim().length < 2) {
      setState(() { _hits = null; _error = null; _loading = false; });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () => _run(q));
  }

  Future<void> _run(String q) async {
    _lastQuery = q;
    setState(() { _loading = true; _error = null; });
    try {
      final hits = await contentRepository.search(q);
      if (!mounted || q != _lastQuery) return;
      setState(() { _hits = hits; _loading = false; });
    } catch (e) {
      if (mounted && q == _lastQuery) setState(() { _error = context.tr('error_generic'); _loading = false; });
    }
  }

  IconData _icon(String kind) => switch (kind) {
        'level' => Icons.school,
        'subject' => Icons.menu_book,
        'chapter' => Icons.article,
        'resource' => Icons.functions,
        _ => Icons.help_outline,
      };

  Future<void> _open(SearchHit h) async {
    final nav = Navigator.of(context);
    switch (h.kind) {
      case 'level':
        final level = await contentRepository.level(h.id);
        if (level != null) nav.push(MaterialPageRoute<void>(builder: (_) => LevelScreen(level: level, trail: [context.tr('nav_home')])));
      case 'subject':
        nav.push(MaterialPageRoute<void>(builder: (_) => ChapterListScreen(subjectId: h.id, title: h.title, trail: const [])));
      case 'chapter':
        nav.push(MaterialPageRoute<void>(builder: (_) => ChapterDetailScreen(chapterId: h.id)));
      default:
        if (h.chapterId != null) {
          nav.push(MaterialPageRoute<void>(builder: (_) => ChapterDetailScreen(chapterId: h.chapterId!, initialTab: h.kind == 'question' ? 2 : 0)));
        }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          controller: _controller, onChanged: _onChanged, textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search), hintText: context.tr('search_hint'),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(28)),
            suffixIcon: _controller.text.isEmpty ? null : IconButton(icon: const Icon(Icons.clear), onPressed: () { _controller.clear(); _onChanged(''); }),
          ),
        ),
      ),
      Expanded(child: _body(context)),
    ]);
  }

  Widget _body(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return Center(child: Text(_error!));
    if (_hits == null) return Center(child: Padding(padding: const EdgeInsets.all(32), child: Text(context.tr('search_prompt'), textAlign: TextAlign.center)));
    if (_hits!.isEmpty) return Center(child: Text(context.tr('no_results')));
    return ListView.separated(
      itemCount: _hits!.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final h = _hits![i];
        return ListTile(
          leading: Icon(_icon(h.kind)),
          title: Text(h.title.replaceAll(RegExp(r'\$'), ''), maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text([context.tr('kind_${h.kind}'), if (h.subtitle != null && h.kind != 'question') h.subtitle!].join(' · ')),
          onTap: () => _open(h).catchError((e) { if (mounted) showMessage(context, errorText(e)); }),
        );
      },
    );
  }
}
