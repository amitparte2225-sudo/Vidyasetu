import 'package:flutter/material.dart';

import '../config.dart';

/// Shown instead of a fake demo when the build has no server settings.
class ConfigErrorApp extends StatelessWidget {
  const ConfigErrorApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        home: Scaffold(
          appBar: AppBar(title: const Text('Vidyasetu is not configured')),
          body: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'This build has no Supabase settings.\n\n'
              'SUPABASE_URL: ${AppConfig.supabaseUrl.isEmpty ? 'MISSING' : 'set'}\n'
              'SUPABASE_ANON_KEY: ${AppConfig.supabaseAnonKey.isEmpty ? 'MISSING' : 'set'}\n'
              'BACKEND_URL: ${AppConfig.backendUrl.isEmpty ? 'MISSING (quizzes and the AI solver need it)' : 'set'}\n\n'
              'Add them as GitHub Actions secrets and build again (see README), or pass --dart-define when running locally.',
            ),
          ),
        ),
      );
}
