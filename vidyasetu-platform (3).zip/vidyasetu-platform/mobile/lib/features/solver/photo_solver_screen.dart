import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/strings.dart';
import '../../services/backend_client.dart';
import '../../widgets/common.dart';
import '../quiz/quiz_screen.dart' show backend;
import 'confirm_question_screen.dart';
import 'image_edit_screen.dart';

/// Photo -> crop/rotate -> preview -> extract text (OCR) -> confirm/edit -> solve.
class PhotoSolverScreen extends StatefulWidget {
  const PhotoSolverScreen({super.key});
  @override
  State<PhotoSolverScreen> createState() => _PhotoSolverScreenState();
}

class _PhotoSolverScreenState extends State<PhotoSolverScreen> {
  final _picker = ImagePicker();
  Uint8List? _image;
  bool _busy = false;
  String? _error;

  Future<void> _pick(ImageSource source) async {
    try {
      final file = await _picker.pickImage(source: source, maxWidth: 3000, imageQuality: 92);
      if (file == null) return;
      final bytes = await file.readAsBytes();
      if (!mounted) return;
      final edited = await Navigator.of(context).push<Uint8List>(MaterialPageRoute(builder: (_) => ImageEditScreen(bytes: bytes)));
      if (edited != null && mounted) setState(() { _image = edited; _error = null; });
    } catch (e) {
      if (mounted) showMessage(context, context.tr('image_error'));
    }
  }

  Future<void> _extract({String engine = 'auto'}) async {
    setState(() { _busy = true; _error = null; });
    try {
      final json = await backend.postFile('/v1/ocr/image', _image!, 'question.jpg', {'engine': engine});
      if (!mounted) return;
      final warnings = (json['warnings'] as List?)?.cast<String>() ?? const [];
      await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ConfirmQuestionScreen(
          initialText: '${json['text']}', source: 'image', imageBytes: _image, notice: warnings.isEmpty ? null : warnings.join(' '))));
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = context.tr('error_generic'));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('photo_question'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(context.tr('photo_tips')),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: Text(context.tr('camera')))),
          const SizedBox(width: 12),
          Expanded(child: OutlinedButton.icon(onPressed: _busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: Text(context.tr('gallery')))),
        ]),
        if (_image != null) ...[
          const SizedBox(height: 16),
          ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.memory(_image!, fit: BoxFit.contain)),
          const SizedBox(height: 8),
          Text(context.tr('photo_privacy'), style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 12),
          if (_error != null) Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ),
          if (_busy) Column(children: [const LinearProgressIndicator(), const SizedBox(height: 8), Text(context.tr('reading_photo'))])
          else Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            FilledButton(onPressed: () => _extract(), child: Text(context.tr('extract_text'))),
            if (_error != null) TextButton(onPressed: () => _extract(engine: 'vision'), child: Text(context.tr('try_ai_reading'))),
          ]),
        ],
      ]),
    );
  }
}
