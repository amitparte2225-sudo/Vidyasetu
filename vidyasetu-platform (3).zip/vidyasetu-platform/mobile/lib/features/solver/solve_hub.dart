import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../data/user_repository.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import '../../widgets/future_state_view.dart';
import 'answer_screen.dart';
import 'confirm_question_screen.dart';
import 'pdf_solver_screen.dart';
import 'photo_solver_screen.dart';

class SolveHub extends StatefulWidget {
  const SolveHub({super.key});
  @override
  State<SolveHub> createState() => _SolveHubState();
}

class _SolveHubState extends State<SolveHub> {
  int _k = 0;

  Future<void> _open(Widget screen) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => screen));
    if (mounted) setState(() => _k++);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text(context.tr('solver_intro'), style: Theme.of(context).textTheme.bodyMedium),
      const SizedBox(height: 12),
      _Tile(icon: Icons.camera_alt, title: context.tr('photo_question'), subtitle: context.tr('photo_question_sub'), onTap: () => _open(const PhotoSolverScreen())),
      _Tile(icon: Icons.picture_as_pdf, title: context.tr('pdf_question'), subtitle: context.tr('pdf_question_sub'), onTap: () => _open(const PdfSolverScreen())),
      _Tile(icon: Icons.keyboard, title: context.tr('type_question'), subtitle: context.tr('type_question_sub'),
          onTap: () => _open(const ConfirmQuestionScreen(initialText: '', source: 'text'))),
      Card(
        color: Theme.of(context).colorScheme.tertiaryContainer,
        child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
          const Icon(Icons.info_outline), const SizedBox(width: 12), Expanded(child: Text(context.tr('ai_disclaimer_short'))),
        ])),
      ),
      SectionTitle(context.tr('recent_answers')),
      FutureStateView<List<SolverRecord>>(
        key: ValueKey(_k),
        load: userRepository.solverHistory,
        isEmpty: (l) => l.isEmpty,
        emptyMessage: context.tr('empty_history'),
        builder: (context, rows) => Column(children: [
          for (final r in rows)
            ListTile(
              leading: Icon(r.source == 'image' ? Icons.photo : (r.source == 'pdf' ? Icons.picture_as_pdf : Icons.keyboard)),
              title: Text(r.questionText.replaceAll(r'$', ''), maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: Text(r.createdAt.toLocal().toString().split('.').first),
              onTap: () => _open(AnswerScreen.record(r)),
            ),
        ]),
      ),
    ]);
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          contentPadding: const EdgeInsets.all(16),
          leading: Icon(icon, size: 36, color: Theme.of(context).colorScheme.primary),
          title: Text(title, style: Theme.of(context).textTheme.titleMedium),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      );
}
