import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import '../../widgets/rich_content.dart';
import '../quiz/quiz_screen.dart' show backend;

/// Shows an AI-generated solution. It is ALWAYS labelled as AI-generated and unverified.
class AnswerScreen extends StatefulWidget {
  const AnswerScreen.solve({super.key, required String this.question, required String this.level, this.subject,
      required String this.source, required String this.language, this.imageBytes}) : record = null;
  const AnswerScreen.record(SolverRecord this.record, {super.key})
      : question = null, level = null, subject = null, source = null, language = null, imageBytes = null;

  final String? question, level, subject, source, language;
  final Uint8List? imageBytes;
  final SolverRecord? record;

  @override
  State<AnswerScreen> createState() => _AnswerScreenState();
}

class _AnswerScreenState extends State<AnswerScreen> {
  AiSolution? _solution;
  String? _requestId;
  String? _error;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    final r = widget.record;
    if (r != null) {
      _solution = r.solution;
      _requestId = r.id;
    } else {
      _solve();
    }
  }

  Future<void> _solve() async {
    setState(() { _loading = true; _error = null; });
    try {
      final Map<String, dynamic> json;
      if (widget.imageBytes != null) {
        json = await backend.postFile('/v1/solve/image', widget.imageBytes!, 'question.jpg', {
          'question': widget.question!, 'level': widget.level!, 'language': widget.language!,
          if (widget.subject != null) 'subject': widget.subject!,
        });
      } else {
        json = await backend.post('/v1/solve', {
          'question': widget.question, 'level': widget.level, 'language': widget.language, 'source': widget.source,
          if (widget.subject != null) 'subject': widget.subject,
        });
      }
      if (!mounted) return;
      setState(() {
        _solution = AiSolution.fromJson(Map<String, dynamic>.from(json['solution'] as Map));
        _requestId = json['request_id'] as String?;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { _error = errorText(e); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(context.tr('ai_answer')),
        actions: [
          if (_requestId != null) BookmarkButton(kind: 'solver_request', targetId: _requestId!),
          if (_requestId != null) IconButton(icon: const Icon(Icons.flag_outlined), tooltip: context.tr('report'), onPressed: () => showReportDialog(context, 'solver_request', _requestId!)),
        ],
      ),
      body: _body(context),
    );
  }

  Widget _body(BuildContext context) {
    if (_loading) {
      return Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const CircularProgressIndicator(), const SizedBox(height: 16), Text(context.tr('solving'), textAlign: TextAlign.center),
      ])));
    }
    if (_error != null) {
      return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.error_outline, size: 48, color: Theme.of(context).colorScheme.error), const SizedBox(height: 12),
        Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 16),
        if (widget.record == null) FilledButton(onPressed: _solve, child: Text(context.tr('retry'))),
        TextButton(onPressed: () => Navigator.pop(context), child: Text(context.tr('edit_question'))),
      ])));
    }
    final s = _solution;
    if (s == null) return Center(child: Text(context.tr('no_solution_saved')));
    if (!s.readable) {
      return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.visibility_off, size: 48), const SizedBox(height: 12),
        Text(s.unreadableReason ?? context.tr('unreadable'), textAlign: TextAlign.center), const SizedBox(height: 16),
        FilledButton(onPressed: () => Navigator.pop(context), child: Text(context.tr('edit_question'))),
      ])));
    }
    final scheme = Theme.of(context).colorScheme;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: scheme.tertiaryContainer, borderRadius: BorderRadius.circular(8)),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.auto_awesome), const SizedBox(width: 10),
          Expanded(child: Text('${context.tr('ai_generated')}. ${context.tr('ai_disclaimer')}')),
        ]),
      ),
      _verification(context, s),
      if (s.questionUnderstood.isNotEmpty) ...[SectionTitle(context.tr('question_understood')), RichContent(s.questionUnderstood)],
      if (s.concepts.isNotEmpty) ...[SectionTitle(context.tr('concepts')), for (final c in s.concepts) RichContent(c)],
      if (s.steps.isNotEmpty) ...[
        SectionTitle(context.tr('steps')),
        for (var i = 0; i < s.steps.length; i++)
          Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${context.tr('step')} ${i + 1}${s.steps[i].title.isEmpty ? '' : ': ${s.steps[i].title}'}', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold)),
            if (s.steps[i].explanation.isNotEmpty) RichContent(s.steps[i].explanation),
            if (s.steps[i].calculation.isNotEmpty) RichContent(asDisplayMath(s.steps[i].calculation)),
          ]))),
      ],
      if (s.intermediate.isNotEmpty) ...[SectionTitle(context.tr('intermediate')), for (final r in s.intermediate) RichContent('- $r')],
      SectionTitle(context.tr('final_answer')),
      Card(
        color: scheme.primaryContainer,
        child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          RichContent(s.finalAnswer, style: Theme.of(context).textTheme.titleMedium),
          if (s.units != null) Text('${context.tr('units')}: ${s.units}'),
        ])),
      ),
      if (s.assumptions.isNotEmpty) ...[SectionTitle(context.tr('assumptions')), for (final a in s.assumptions) RichContent('- $a')],
      if (s.explanation.isNotEmpty) ...[SectionTitle(context.tr('explanation')), RichContent(s.explanation)],
      const SizedBox(height: 16),
      Text(context.tr('saved_in_history'), style: Theme.of(context).textTheme.bodySmall),
    ]);
  }

  Widget _verification(BuildContext context, AiSolution s) {
    final scheme = Theme.of(context).colorScheme;
    final (icon, color, key) = switch (s.verificationStatus) {
      'verified' => (Icons.check_circle, Colors.green, 'math_check_ok'),
      'mismatch' => (Icons.warning_amber, scheme.error, 'math_check_bad'),
      _ => (Icons.help_outline, scheme.outline, 'math_check_none'),
    };
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(children: [Icon(icon, color: color, size: 20), const SizedBox(width: 8), Expanded(child: Text(context.tr(key), style: Theme.of(context).textTheme.bodySmall))]),
    );
  }
}
