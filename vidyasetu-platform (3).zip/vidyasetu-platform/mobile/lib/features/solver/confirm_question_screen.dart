import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../../core/app_settings.dart';
import '../../core/strings.dart';
import '../../widgets/common.dart';
import '../../widgets/rich_content.dart';
import 'answer_screen.dart';

const _levels = ['school', 'higher_secondary', 'bsc', 'engineering'];
const _subjects = ['mathematics', 'physics', 'science', 'chemistry', 'biology', 'engineering_mathematics', 'other'];

/// The student always confirms or corrects the extracted question before anything is sent to the AI.
class ConfirmQuestionScreen extends StatefulWidget {
  const ConfirmQuestionScreen({super.key, required this.initialText, required this.source, this.imageBytes, this.notice});
  final String initialText;
  final String source; // text | image | pdf
  final Uint8List? imageBytes;
  final String? notice;

  @override
  State<ConfirmQuestionScreen> createState() => _ConfirmQuestionScreenState();
}

class _ConfirmQuestionScreenState extends State<ConfirmQuestionScreen> {
  late final TextEditingController _text = TextEditingController(text: widget.initialText);
  String _level = 'school';
  String _subject = 'mathematics';
  bool _withImage = false;
  bool _preview = false;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  void _solve() {
    final q = _text.text.trim();
    if (q.length < 3) {
      showMessage(context, context.tr('question_too_short'));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AnswerScreen.solve(
          question: q, level: _level, subject: _subject, source: widget.source,
          language: AppScope.read(context).languageCode,
          imageBytes: _withImage ? widget.imageBytes : null)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('confirm_question'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (widget.notice != null) Card(color: Theme.of(context).colorScheme.tertiaryContainer, child: Padding(padding: const EdgeInsets.all(12), child: Text(widget.notice!))),
        Text(context.tr('confirm_hint')),
        const SizedBox(height: 8),
        TextField(
          controller: _text, minLines: 4, maxLines: 10, maxLength: 3000,
          decoration: InputDecoration(border: const OutlineInputBorder(), hintText: context.tr('question_hint')),
          onChanged: (_) { if (_preview) setState(() {}); },
        ),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: _preview, onChanged: (v) => setState(() => _preview = v), title: Text(context.tr('preview_maths'))),
        if (_preview) Container(
          padding: const EdgeInsets.all(12), width: double.infinity,
          decoration: BoxDecoration(border: Border.all(color: Theme.of(context).colorScheme.outlineVariant), borderRadius: BorderRadius.circular(8)),
          child: RichContent(_text.text),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _level, decoration: InputDecoration(labelText: context.tr('my_level'), border: const OutlineInputBorder()),
          items: [for (final l in _levels) DropdownMenuItem(value: l, child: Text(context.tr('level_$l')))],
          onChanged: (v) => setState(() => _level = v!),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _subject, decoration: InputDecoration(labelText: context.tr('subject'), border: const OutlineInputBorder()),
          items: [for (final s in _subjects) DropdownMenuItem(value: s, child: Text(context.tr('subject_$s')))],
          onChanged: (v) => setState(() => _subject = v!),
        ),
        if (widget.imageBytes != null) CheckboxListTile(
          contentPadding: EdgeInsets.zero, value: _withImage, onChanged: (v) => setState(() => _withImage = v == true),
          title: Text(context.tr('include_picture')), subtitle: Text(context.tr('include_picture_sub')),
        ),
        const SizedBox(height: 8),
        Text(context.tr('ai_disclaimer_short'), style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: _solve, icon: const Icon(Icons.auto_awesome), label: Text(context.tr('solve_with_ai'))),
      ]),
    );
  }
}
