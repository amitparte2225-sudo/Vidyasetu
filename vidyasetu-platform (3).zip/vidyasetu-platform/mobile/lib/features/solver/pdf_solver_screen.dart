import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/strings.dart';
import '../../services/backend_client.dart';
import '../../widgets/common.dart';
import '../quiz/quiz_screen.dart' show backend;
import 'confirm_question_screen.dart';

const _maxBytes = 20 * 1024 * 1024;

/// Upload a PDF -> preview pages -> extract ONE page at a time (text layer, or OCR if scanned)
/// -> choose the question -> confirm -> solve. The whole book is never sent to the AI.
class PdfSolverScreen extends StatefulWidget {
  const PdfSolverScreen({super.key});
  @override
  State<PdfSolverScreen> createState() => _PdfSolverScreenState();
}

class _PdfSolverScreenState extends State<PdfSolverScreen> {
  PdfControllerPinch? _pdf;
  String? _path;
  int _pages = 0;
  bool _busy = false;
  String? _status;
  String? _error;
  List<String> _candidates = [];
  String _pageText = '';
  String _method = '';
  int _selected = 0;

  @override
  void dispose() {
    _pdf?.dispose();
    _cleanup();
    super.dispose();
  }

  /// Delete the uploaded PDF from storage (privacy: nothing is kept after you leave).
  void _cleanup() {
    final p = _path;
    if (p == null) return;
    _path = null;
    backend.post('/v1/pdf/delete', {'path': p}).catchError((_) => <String, dynamic>{});
  }

  Future<void> _pick() async {
    setState(() { _error = null; });
    FilePickerResult? res;
    try {
      res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const ['pdf'], withData: true);
    } catch (_) {
      setState(() => _error = context.tr('file_error'));
      return;
    }
    final file = res?.files.single;
    final Uint8List? bytes = file?.bytes;
    if (file == null || bytes == null) return;
    if (bytes.length > _maxBytes) { setState(() => _error = context.tr('pdf_too_large')); return; }
    if (bytes.length < 5 || String.fromCharCodes(bytes.sublist(0, 4)) != '%PDF') { setState(() => _error = context.tr('not_a_pdf')); return; }

    final uid = Supabase.instance.client.auth.currentUser!.id;
    final path = '$uid/${DateTime.now().microsecondsSinceEpoch}.pdf';
    setState(() { _busy = true; _status = context.tr('uploading'); });
    try {
      await Supabase.instance.client.storage.from('user-uploads').uploadBinary(
          path, bytes, fileOptions: const FileOptions(contentType: 'application/pdf', upsert: false));
      _cleanup(); // remove any previous upload
      _path = path;
      if (mounted) setState(() => _status = context.tr('checking_pdf'));
      final info = await backend.post('/v1/pdf/inspect', {'path': path});
      final controller = PdfControllerPinch(document: PdfDocument.openData(bytes));
      _pdf?.dispose();
      if (!mounted) return;
      setState(() { _pages = info['page_count'] as int; _pdf = controller; _candidates = []; _pageText = ''; });
    } on ApiException catch (e) {
      _cleanup();
      setState(() => _error = e.message);
    } catch (e) {
      _cleanup();
      setState(() => _error = context.tr('upload_failed'));
    }
    if (mounted) setState(() { _busy = false; _status = null; });
  }

  Future<void> _extract() async {
    final page = _pdf!.page; // 1-based
    setState(() { _busy = true; _error = null; _status = '${context.tr('processing_page')} $page / $_pages'; });
    try {
      final r = await backend.post('/v1/pdf/page', {'path': _path, 'page': page - 1, 'ocr': true});
      if (!mounted) return;
      setState(() {
        _pageText = '${r['text']}';
        _candidates = (r['questions'] as List).map((e) => '$e').toList();
        _method = '${r['method']}';
        _selected = 0;
      });
    } on ApiException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = context.tr('error_generic'));
    }
    if (mounted) setState(() { _busy = false; _status = null; });
  }

  void _confirm() {
    final text = _selected < _candidates.length ? _candidates[_selected] : _pageText;
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ConfirmQuestionScreen(
        initialText: text, source: 'pdf',
        notice: _method == 'ocr' ? context.tr('ocr_notice') : null)));
  }

  @override
  Widget build(BuildContext context) {
    final pdf = _pdf;
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('pdf_question')), actions: [
        if (_path != null) IconButton(
          tooltip: context.tr('remove_pdf'), icon: const Icon(Icons.delete_outline),
          onPressed: () { _cleanup(); setState(() { _pdf?.dispose(); _pdf = null; _candidates = []; }); showMessage(context, context.tr('deleted')); }),
      ]),
      body: pdf == null ? _start(context) : _viewer(context, pdf),
    );
  }

  Widget _start(BuildContext context) => Center(
        child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.picture_as_pdf, size: 64),
          const SizedBox(height: 12),
          Text(context.tr('pdf_intro'), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text(context.tr('pdf_privacy'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 16),
          if (_error != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          if (_busy) Column(children: [const LinearProgressIndicator(), const SizedBox(height: 8), Text(_status ?? '')])
          else FilledButton.icon(onPressed: _pick, icon: const Icon(Icons.upload_file), label: Text(context.tr('choose_pdf'))),
        ])),
      );

  Widget _viewer(BuildContext context, PdfControllerPinch pdf) {
    return Column(children: [
      Expanded(child: PdfViewPinch(controller: pdf)),
      if (_busy) Padding(padding: const EdgeInsets.all(8), child: Column(children: [const LinearProgressIndicator(), const SizedBox(height: 4), Text(_status ?? '')])),
      if (_error != null) Padding(padding: const EdgeInsets.all(8), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      if (_candidates.isNotEmpty) ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.38),
        child: Material(elevation: 4, child: ListView(padding: const EdgeInsets.all(12), shrinkWrap: true, children: [
          Text(context.tr('choose_question'), style: Theme.of(context).textTheme.titleSmall),
          for (var i = 0; i < _candidates.length; i++)
            RadioListTile<int>(
              dense: true, value: i, groupValue: _selected, onChanged: (v) => setState(() => _selected = v!),
              title: Text(_candidates[i].replaceAll(r'$', ''), maxLines: 3, overflow: TextOverflow.ellipsis),
            ),
          RadioListTile<int>(dense: true, value: _candidates.length, groupValue: _selected, onChanged: (v) => setState(() => _selected = v!), title: Text(context.tr('whole_page'))),
          FilledButton(onPressed: _confirm, child: Text(context.tr('continue_btn'))),
        ])),
      ),
      SafeArea(child: Padding(
        padding: const EdgeInsets.all(8),
        child: Row(children: [
          PdfPageNumber(controller: pdf, builder: (_, s, page, pages) => Text('${context.tr('page')} $page / ${pages ?? _pages}')),
          const Spacer(),
          FilledButton.icon(onPressed: _busy ? null : _extract, icon: const Icon(Icons.text_snippet), label: Text(context.tr('read_this_page'))),
        ]),
      )),
    ]);
  }
}
