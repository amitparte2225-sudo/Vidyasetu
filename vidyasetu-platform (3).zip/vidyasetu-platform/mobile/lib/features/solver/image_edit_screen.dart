import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

import '../../core/strings.dart';
import '../../widgets/common.dart';

Uint8List _rotate(Map<String, Object> a) {
  final decoded = img.decodeImage(a['bytes'] as Uint8List);
  if (decoded == null) throw Exception('unreadable image');
  final out = img.copyRotate(img.bakeOrientation(decoded), angle: a['angle'] as int);
  return Uint8List.fromList(img.encodeJpg(out, quality: 90));
}

Uint8List _crop(Map<String, Object> a) {
  final decoded = img.decodeImage(a['bytes'] as Uint8List);
  if (decoded == null) throw Exception('unreadable image');
  var im = img.bakeOrientation(decoded);
  final l = a['l'] as double, t = a['t'] as double, r = a['r'] as double, b = a['b'] as double;
  final x = (l * im.width).round(), y = (t * im.height).round();
  final w = ((r - l) * im.width).round().clamp(8, im.width - x);
  final h = ((b - t) * im.height).round().clamp(8, im.height - y);
  im = img.copyCrop(im, x: x, y: y, width: w, height: h);
  const maxSide = 2000;
  if (im.width > maxSide || im.height > maxSide) {
    im = im.width >= im.height ? img.copyResize(im, width: maxSide) : img.copyResize(im, height: maxSide);
  }
  return Uint8List.fromList(img.encodeJpg(im, quality: 88));
}

/// Rotate and crop a photo before it is sent anywhere. Pops the edited JPEG bytes.
class ImageEditScreen extends StatefulWidget {
  const ImageEditScreen({super.key, required this.bytes});
  final Uint8List bytes;
  @override
  State<ImageEditScreen> createState() => _ImageEditScreenState();
}

class _ImageEditScreenState extends State<ImageEditScreen> {
  late Uint8List _bytes = widget.bytes;
  double _aspect = 1;
  RangeValues _h = const RangeValues(0, 1);
  RangeValues _v = const RangeValues(0, 1);
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _measure();
  }

  Future<void> _measure() async {
    final codec = await ui.instantiateImageCodec(_bytes);
    final f = await codec.getNextFrame();
    if (mounted) setState(() => _aspect = f.image.width / f.image.height);
  }

  Future<void> _rotateBy(int angle) async {
    setState(() => _busy = true);
    try {
      _bytes = await compute(_rotate, {'bytes': _bytes, 'angle': angle});
      _h = const RangeValues(0, 1);
      _v = const RangeValues(0, 1);
      await _measure();
    } catch (e) {
      if (mounted) showMessage(context, context.tr('image_error'));
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _done() async {
    setState(() => _busy = true);
    try {
      final out = await compute(_crop, {'bytes': _bytes, 'l': _h.start, 't': _v.start, 'r': _h.end, 'b': _v.end});
      if (mounted) Navigator.pop(context, out);
    } catch (e) {
      if (mounted) { setState(() => _busy = false); showMessage(context, context.tr('image_error')); }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('crop_rotate')), actions: [
        TextButton(onPressed: _busy ? null : _done, child: Text(context.tr('use_image'))),
      ]),
      body: Column(children: [
        Expanded(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: AspectRatio(
                aspectRatio: _aspect,
                child: Stack(fit: StackFit.expand, children: [
                  Image.memory(_bytes, fit: BoxFit.fill, gaplessPlayback: true),
                  CustomPaint(painter: _CropPainter(_h, _v)),
                  if (_busy) const Center(child: CircularProgressIndicator()),
                ]),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(children: [
            Row(children: [const Icon(Icons.swap_horiz), Expanded(child: RangeSlider(values: _h, onChanged: _busy ? null : (v) => setState(() => _h = v)))]),
            Row(children: [const Icon(Icons.swap_vert), Expanded(child: RangeSlider(values: _v, onChanged: _busy ? null : (v) => setState(() => _v = v)))]),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(tooltip: context.tr('rotate_left'), onPressed: _busy ? null : () => _rotateBy(-90), icon: const Icon(Icons.rotate_left)),
              IconButton(tooltip: context.tr('rotate_right'), onPressed: _busy ? null : () => _rotateBy(90), icon: const Icon(Icons.rotate_right)),
            ]),
          ]),
        ),
        const SizedBox(height: 8),
      ]),
    );
  }
}

class _CropPainter extends CustomPainter {
  _CropPainter(this.h, this.v);
  final RangeValues h, v;

  @override
  void paint(Canvas canvas, Size size) {
    final crop = Rect.fromLTRB(h.start * size.width, v.start * size.height, h.end * size.width, v.end * size.height);
    final shade = Path()
      ..addRect(Offset.zero & size)
      ..addRect(crop)
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(shade, Paint()..color = const Color(0x99000000));
    canvas.drawRect(crop, Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 2);
  }

  @override
  bool shouldRepaint(_CropPainter old) => old.h != h || old.v != v;
}
