import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/strings.dart';
import '../../widgets/common.dart';
import '../../widgets/language_menu.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  bool _register = false;
  bool _busy = false;
  String? _error;
  String? _notice;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() { _busy = true; _error = null; _notice = null; });
    final auth = Supabase.instance.client.auth;
    try {
      if (_register) {
        final res = await auth.signUp(
          email: _email.text.trim(), password: _password.text,
          data: {'display_name': _name.text.trim()},
        );
        if (res.session == null && mounted) {
          setState(() => _notice = context.tr('confirm_email'));
        }
      } else {
        await auth.signInWithPassword(email: _email.text.trim(), password: _password.text);
      }
    } on AuthException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = context.tr('error_network'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _forgot() async {
    final email = _email.text.trim();
    if (!email.contains('@')) {
      setState(() => _error = context.tr('enter_email_first'));
      return;
    }
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(email);
      if (mounted) showMessage(context, context.tr('reset_sent'));
    } catch (e) {
      if (mounted) showMessage(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(context.tr('app_name')), actions: const [LanguageMenu()]),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Form(
              key: _form,
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(_register ? context.tr('create_account') : context.tr('sign_in'),
                    style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 16),
                if (_register) ...[
                  TextFormField(
                    controller: _name, textInputAction: TextInputAction.next,
                    decoration: InputDecoration(labelText: context.tr('your_name'), border: const OutlineInputBorder()),
                    validator: (v) => (v == null || v.trim().isEmpty) ? context.tr('required') : null,
                  ),
                  const SizedBox(height: 12),
                ],
                TextFormField(
                  controller: _email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email],
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(labelText: context.tr('email'), border: const OutlineInputBorder()),
                  validator: (v) => (v == null || !v.contains('@')) ? context.tr('invalid_email') : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _password, obscureText: true, autofillHints: const [AutofillHints.password],
                  decoration: InputDecoration(labelText: context.tr('password'), border: const OutlineInputBorder()),
                  validator: (v) => (v == null || v.length < 8) ? context.tr('password_short') : null,
                  onFieldSubmitted: (_) => _submit(),
                ),
                if (_error != null) Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                ),
                if (_notice != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_notice!)),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _busy ? null : _submit,
                  child: _busy
                      ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(_register ? context.tr('register') : context.tr('sign_in')),
                ),
                TextButton(
                  onPressed: _busy ? null : () => setState(() { _register = !_register; _error = null; _notice = null; }),
                  child: Text(_register ? context.tr('have_account') : context.tr('no_account')),
                ),
                if (!_register) TextButton(onPressed: _forgot, child: Text(context.tr('forgot_password'))),
                const SizedBox(height: 8),
                Text(context.tr('privacy_short'), style: Theme.of(context).textTheme.bodySmall, textAlign: TextAlign.center),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
