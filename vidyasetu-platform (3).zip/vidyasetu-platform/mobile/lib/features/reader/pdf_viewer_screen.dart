import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';

import '../../core/strings.dart';
import '../../data/content_repository.dart';
import '../../widgets/language_menu.dart';

/// Reads a chapter PDF. The file is downloaded with the student's own session (access is checked by the database).
class PdfViewerScreen extends StatefulWidget {
  const PdfViewerScreen({super.key, required this.title, required this.path});
  final String title;
  final String path;

  @override
  State<PdfViewerScreen> createState() => _PdfViewerScreenState();
}

class _PdfViewerScreenState extends State<PdfViewerScreen> {
  PdfControllerPinch? _controller;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _open();
  }

  Future<void> _open() async {
    try {
      final bytes = await contentRepository.download(widget.path);
      if (!mounted) return;
      setState(() => _controller = PdfControllerPinch(document: PdfDocument.openData(bytes)));
    } catch (e) {
      if (mounted) setState(() => _error = e);
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _controller;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title, overflow: TextOverflow.ellipsis),
        actions: [
          if (c != null)
            Center(child: Padding(
              padding: const EdgeInsets.only(right: 8),
              child: PdfPageNumber(controller: c, builder: (_, state, page, pages) => Text('$page / ${pages ?? 0}')),
            )),
          const LanguageMenu(),
        ],
      ),
      body: _error != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(context.tr('pdf_error'))))
          : c == null
              ? const Center(child: CircularProgressIndicator())
              : PdfViewPinch(controller: c),
    );
  }
}
