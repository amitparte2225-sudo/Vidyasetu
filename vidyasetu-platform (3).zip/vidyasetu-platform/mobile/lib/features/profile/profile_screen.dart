import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/app_settings.dart';
import '../../core/strings.dart';
import '../../data/content_repository.dart';
import '../../data/user_repository.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import '../../widgets/future_state_view.dart';
import '../quiz/quiz_screen.dart' show backend;
import '../quiz/result_screen.dart';
import '../../core/localized_text.dart';

class _ProfileData {
  _ProfileData(this.profile, this.levels, this.history);
  final Profile? profile;
  final List<Level> levels;
  final List<Map<String, dynamic>> history;
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  int _k = 0;
  final _name = TextEditingController();
  String? _levelId;
  bool _loaded = false;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<_ProfileData> _load() async {
    final r = await Future.wait([userRepository.profile(), contentRepository.topLevels(), userRepository.quizHistory()]);
    final p = r[0] as Profile?;
    if (!_loaded) {
      _name.text = p?.displayName ?? '';
      _levelId = p?.levelId;
      _loaded = true;
    }
    return _ProfileData(p, r[1] as List<Level>, r[2] as List<Map<String, dynamic>>);
  }

  Future<void> _save() async {
    try {
      await userRepository.updateProfile(displayName: _name.text, levelId: _levelId, clearLevel: _levelId == null);
      if (mounted) showMessage(context, context.tr('saved'));
    } catch (e) {
      if (mounted) showMessage(context, errorText(e));
    }
  }

  Future<void> _deleteHistory() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.tr('delete_ai_history')), content: Text(ctx.tr('delete_ai_history_body')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('delete')))]),
    );
    if (ok != true) return;
    try {
      await userRepository.deleteSolverHistory();
      if (mounted) showMessage(context, context.tr('deleted'));
    } catch (e) {
      if (mounted) showMessage(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    return FutureStateView<_ProfileData>(
      key: ValueKey(_k),
      load: _load,
      emptyMessage: '',
      builder: (context, d) {
        final attempts = d.history.length;
        final avg = attempts == 0 ? 0.0 : d.history.map((h) => (h['percentage'] as num?)?.toDouble() ?? 0).reduce((a, b) => a + b) / attempts;
        final settings = AppScope.of(context);
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text(user?.email ?? '', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 12),
          TextField(controller: _name, decoration: InputDecoration(labelText: context.tr('your_name'), border: const OutlineInputBorder())),
          const SizedBox(height: 12),
          DropdownButtonFormField<String?>(
            value: d.levels.any((l) => l.id == _levelId) ? _levelId : null,
            decoration: InputDecoration(labelText: context.tr('my_course'), border: const OutlineInputBorder()),
            items: [DropdownMenuItem<String?>(value: null, child: Text(context.tr('none'))),
              for (final l in d.levels) DropdownMenuItem<String?>(value: l.id, child: Text(context.loc(l.name)))],
            onChanged: (v) => setState(() => _levelId = v),
          ),
          const SizedBox(height: 12),
          SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'en', label: Text('English')), ButtonSegment(value: 'mr', label: Text('मराठी'))],
            selected: {settings.languageCode},
            onSelectionChanged: (s) async {
              await settings.setLanguage(s.first);
              try { await userRepository.updateProfile(language: s.first); } catch (_) {}
            },
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _save, child: Text(context.tr('save'))),
          SectionTitle(context.tr('progress')),
          Card(child: ListTile(leading: const Icon(Icons.insights), title: Text('$attempts ${context.tr('quizzes_taken')}'), subtitle: Text('${context.tr('average_score')}: ${avg.toStringAsFixed(0)}%'))),
          for (final h in d.history.take(10))
            ListTile(
              dense: true,
              leading: const Icon(Icons.history),
              title: Text(context.loc(LocalizedText.fromRow((h['quizzes'] as Map?)?['title'] ?? '', (h['quizzes'] as Map?)?['title_i18n']))),
              subtitle: Text('${(h['percentage'] as num?)?.toStringAsFixed(0) ?? 0}%  ·  ${(h['submitted_at'] ?? '').toString().split('T').first}'),
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AttemptReviewScreen(attemptId: h['id'], title: context.tr('review')))),
            ),
          SectionTitle(context.tr('ai_usage')),
          const _UsageCard(),
          SectionTitle(context.tr('privacy')),
          Text(context.tr('privacy_long')),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: _deleteHistory, icon: const Icon(Icons.delete_outline), label: Text(context.tr('delete_ai_history'))),
          const SizedBox(height: 16),
          OutlinedButton.icon(onPressed: () => Supabase.instance.client.auth.signOut(), icon: const Icon(Icons.logout), label: Text(context.tr('sign_out'))),
        ]);
      },
    );
  }
}

class _UsageCard extends StatelessWidget {
  const _UsageCard();
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: backend.get('/v1/me/limits'),
        builder: (context, s) {
          if (s.hasError) return Text(context.tr('usage_unavailable'));
          if (!s.hasData) return const LinearProgressIndicator();
          final d = s.data!;
          final lim = Map<String, dynamic>.from(d['limits'] as Map);
          return Card(child: ListTile(
            leading: const Icon(Icons.auto_awesome),
            title: Text('${d['used_today']} / ${lim['daily_solver_requests']} ${context.tr('today')}'),
            subtitle: Text('${d['used_this_month']} / ${lim['monthly_solver_requests']} ${context.tr('this_month')}'
                '${d['ai_configured'] == true ? '' : '\n${context.tr('ai_not_configured')}'}'),
          ));
        },
      );
}
