import 'package:flutter/material.dart';

import '../../core/localized_text.dart';
import '../../core/strings.dart';
import '../../data/user_repository.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import '../../widgets/future_state_view.dart';
import '../catalog/chapter_detail_screen.dart';
import '../solver/answer_screen.dart';

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key});

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 3,
        child: Column(children: [
          TabBar(tabs: [Tab(text: context.tr('tab_chapters')), Tab(text: context.tr('tab_questions')), Tab(text: context.tr('tab_ai'))]),
          const Expanded(child: TabBarView(children: [_SavedChapters(), _SavedQuestions(), _SavedAnswers()])),
        ]),
      );
}

class _SavedChapters extends StatefulWidget {
  const _SavedChapters();
  @override
  State<_SavedChapters> createState() => _SavedChaptersState();
}

class _SavedChaptersState extends State<_SavedChapters> {
  int _k = 0;
  @override
  Widget build(BuildContext context) => FutureStateView<List<Map<String, dynamic>>>(
        key: ValueKey(_k),
        load: userRepository.bookmarkedChapters,
        isEmpty: (l) => l.isEmpty,
        emptyMessage: context.tr('empty_saved'),
        builder: (context, rows) => ListView(children: [
          for (final r in rows)
            ListTile(
              leading: const Icon(Icons.article),
              title: Text('${r['number']}. ${context.loc(LocalizedText.fromRow(r['title'], r['title_i18n']))}'),
              trailing: IconButton(icon: const Icon(Icons.bookmark), tooltip: context.tr('remove'), onPressed: () async {
                await userRepository.setBookmark('chapter', r['id'], false);
                if (mounted) setState(() => _k++);
              }),
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ChapterDetailScreen(chapterId: r['id']))),
            ),
        ]),
      );
}

class _SavedQuestions extends StatefulWidget {
  const _SavedQuestions();
  @override
  State<_SavedQuestions> createState() => _SavedQuestionsState();
}

class _SavedQuestionsState extends State<_SavedQuestions> {
  int _k = 0;
  @override
  Widget build(BuildContext context) => FutureStateView<List<Map<String, dynamic>>>(
        key: ValueKey(_k),
        load: userRepository.bookmarkedQuestions,
        isEmpty: (l) => l.isEmpty,
        emptyMessage: context.tr('empty_saved'),
        builder: (context, rows) => ListView(children: [
          for (final r in rows)
            ListTile(
              leading: const Icon(Icons.help_outline),
              title: Text(context.loc(LocalizedText.fromRow(r['prompt'], r['prompt_i18n'])).replaceAll(r'$', ''), maxLines: 2, overflow: TextOverflow.ellipsis),
              trailing: IconButton(icon: const Icon(Icons.bookmark), tooltip: context.tr('remove'), onPressed: () async {
                await userRepository.setBookmark('question', r['id'], false);
                if (mounted) setState(() => _k++);
              }),
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ChapterDetailScreen(chapterId: r['chapter_id'], initialTab: 2))),
            ),
        ]),
      );
}

class _SavedAnswers extends StatefulWidget {
  const _SavedAnswers();
  @override
  State<_SavedAnswers> createState() => _SavedAnswersState();
}

class _SavedAnswersState extends State<_SavedAnswers> {
  int _k = 0;
  @override
  Widget build(BuildContext context) => FutureStateView<List<SolverRecord>>(
        key: ValueKey(_k),
        load: userRepository.bookmarkedSolutions,
        isEmpty: (l) => l.isEmpty,
        emptyMessage: context.tr('empty_saved'),
        builder: (context, rows) => ListView(children: [
          for (final r in rows)
            ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: Text(r.questionText.replaceAll(r'$', ''), maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: Text(context.tr('ai_generated')),
              trailing: IconButton(icon: const Icon(Icons.bookmark), tooltip: context.tr('remove'), onPressed: () async {
                await userRepository.setBookmark('solver_request', r.id, false);
                if (mounted) setState(() => _k++);
              }),
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AnswerScreen.record(r))),
            ),
        ]),
      );
}
