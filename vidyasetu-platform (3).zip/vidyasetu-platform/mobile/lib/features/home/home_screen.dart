import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../data/content_repository.dart';
import '../../models/models.dart';
import '../../widgets/future_state_view.dart';
import '../../widgets/language_menu.dart';
import '../catalog/level_screen.dart';
import '../profile/profile_screen.dart';
import '../saved/saved_screen.dart';
import '../search/search_screen.dart';
import '../solver/solve_hub.dart';

IconData iconForLevel(Level l) {
  switch (l.kind) {
    case 'degree':
      return Icons.account_balance;
    case 'semester':
      return Icons.calendar_month;
    default:
      return Icons.school;
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    const titles = ['app_name', 'nav_search', 'nav_solve', 'nav_saved', 'nav_profile'];
    final pages = <Widget>[const CoursesTab(), const SearchScreen(), const SolveHub(), const SavedScreen(), const ProfileScreen()];
    return Scaffold(
      appBar: AppBar(title: Text(context.tr(titles[_index])), actions: const [LanguageMenu()]),
      body: pages[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: context.tr('nav_home')),
          NavigationDestination(icon: const Icon(Icons.search), label: context.tr('nav_search')),
          NavigationDestination(icon: const Icon(Icons.auto_awesome_outlined), selectedIcon: const Icon(Icons.auto_awesome), label: context.tr('nav_solve')),
          NavigationDestination(icon: const Icon(Icons.bookmark_border), selectedIcon: const Icon(Icons.bookmark), label: context.tr('nav_saved')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: context.tr('nav_profile')),
        ],
      ),
    );
  }
}

/// Course categories, loaded from the database and grouped by board / university.
class CoursesTab extends StatelessWidget {
  const CoursesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureStateView<List<Level>>(
      load: () => contentRepository.topLevels(),
      isEmpty: (l) => l.isEmpty,
      emptyMessage: context.tr('empty_courses'),
      builder: (context, levels) {
        final groups = <String, List<Level>>{};
        for (final l in levels) {
          groups.putIfAbsent(l.institutionId, () => []).add(l);
        }
        return LayoutBuilder(builder: (context, c) {
          const pad = 16.0, gap = 12.0;
          final cols = c.maxWidth >= 900 ? 4 : (c.maxWidth >= 600 ? 3 : 2);
          final w = (c.maxWidth - pad * 2 - gap * (cols - 1)) / cols;
          return ListView(padding: const EdgeInsets.all(pad), children: [
            Text(context.tr('choose_course'), style: Theme.of(context).textTheme.titleLarge),
            for (final g in groups.values) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(0, 16, 0, 8),
                child: Text(context.loc(g.first.institutionName),
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(color: Theme.of(context).colorScheme.primary)),
              ),
              Wrap(spacing: gap, runSpacing: gap, children: [
                for (final l in g) SizedBox(width: w, child: _LevelCard(level: l)),
              ]),
            ],
          ]);
        });
      },
    );
  }
}

class _LevelCard extends StatelessWidget {
  const _LevelCard({required this.level});
  final Level level;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: EdgeInsets.zero,
      child: InkWell(
        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => LevelScreen(level: level, trail: [context.tr('nav_home')]),
        )),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            DecoratedBox(
              decoration: BoxDecoration(color: scheme.primaryContainer, borderRadius: BorderRadius.circular(12)),
              child: Padding(padding: const EdgeInsets.all(10), child: Icon(iconForLevel(level), color: scheme.onPrimaryContainer)),
            ),
            const SizedBox(height: 12),
            Text(context.loc(level.name), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          ]),
        ),
      ),
    );
  }
}
