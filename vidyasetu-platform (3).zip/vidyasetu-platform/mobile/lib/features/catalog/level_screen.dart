import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../data/content_repository.dart';
import '../../models/models.dart';
import '../../widgets/breadcrumb.dart';
import '../../widgets/future_state_view.dart';
import '../../widgets/language_menu.dart';
import 'chapter_list_screen.dart';

class _LevelData {
  _LevelData(this.children, this.subjects);
  final List<Level> children;
  final List<Subject> subjects;
}

/// A class / degree / semester: shows its semesters (if any) and its subjects.
class LevelScreen extends StatelessWidget {
  const LevelScreen({super.key, required this.level, required this.trail});

  final Level level;
  final List<String> trail;

  @override
  Widget build(BuildContext context) {
    final title = context.loc(level.name);
    return Scaffold(
      appBar: AppBar(title: Text(title), actions: const [LanguageMenu()]),
      body: Column(children: [
        Breadcrumb(items: [...trail, title]),
        Expanded(
          child: FutureStateView<_LevelData>(
            load: () async {
              final r = await Future.wait([contentRepository.childLevels(level.id), contentRepository.subjects(level.id)]);
              return _LevelData(r[0] as List<Level>, r[1] as List<Subject>);
            },
            isEmpty: (d) => d.children.isEmpty && d.subjects.isEmpty,
            emptyMessage: context.tr('empty_subjects'),
            builder: (context, d) => ListView(padding: const EdgeInsets.all(16), children: [
              if (d.children.isNotEmpty) ...[
                Text(context.tr('semesters'), style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                for (final c in d.children)
                  Card(child: ListTile(
                    leading: const Icon(Icons.calendar_month),
                    title: Text(context.loc(c.name)),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                        builder: (_) => LevelScreen(level: c, trail: [...trail, title]))),
                  )),
              ],
              if (d.subjects.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(context.tr('subjects'), style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                for (final s in d.subjects)
                  Card(child: ListTile(
                    leading: const Icon(Icons.menu_book),
                    title: Text(context.loc(s.name)),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                        builder: (_) => ChapterListScreen(subjectId: s.id, title: context.loc(s.name), trail: [...trail, title]))),
                  )),
              ],
            ]),
          ),
        ),
      ]),
    );
  }
}
