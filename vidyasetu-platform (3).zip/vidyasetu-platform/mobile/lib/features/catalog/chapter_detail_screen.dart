
import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../data/content_repository.dart';
import '../../models/models.dart';
import '../../widgets/breadcrumb.dart';
import '../../widgets/common.dart';
import '../../widgets/future_state_view.dart';
import '../../widgets/language_menu.dart';
import '../../widgets/rich_content.dart';
import '../quiz/quiz_screen.dart';
import '../reader/pdf_viewer_screen.dart';
import '../solver/answer_screen.dart';

class ChapterDetailScreen extends StatelessWidget {
  const ChapterDetailScreen({super.key, required this.chapterId, this.initialTab = 0});

  final String chapterId;
  final int initialTab;

  @override
  Widget build(BuildContext context) {
    return FutureStateView<ChapterContext?>(
      load: () => contentRepository.chapter(chapterId),
      isEmpty: (c) => c == null,
      emptyMessage: context.tr('not_found'),
      builder: (context, ctx) => _ChapterBody(ctx: ctx!, initialTab: initialTab),
    );
  }
}

class _ChapterBody extends StatefulWidget {
  const _ChapterBody({required this.ctx, required this.initialTab});
  final ChapterContext ctx;
  final int initialTab;

  @override
  State<_ChapterBody> createState() => _ChapterBodyState();
}

class _ChapterBodyState extends State<_ChapterBody> {
  late final Future<List<Resource>> _resources = contentRepository.resources(widget.ctx.chapter.id);

  @override
  Widget build(BuildContext context) {
    final ch = widget.ctx.chapter;
    return DefaultTabController(
      length: 4,
      initialIndex: widget.initialTab.clamp(0, 3),
      child: Scaffold(
        appBar: AppBar(
          title: Text('${ch.number}. ${context.loc(ch.title)}', overflow: TextOverflow.ellipsis),
          actions: [
            BookmarkButton(kind: 'chapter', targetId: ch.id),
            IconButton(icon: const Icon(Icons.flag_outlined), tooltip: context.tr('report'), onPressed: () => showReportDialog(context, 'chapter', ch.id)),
            const LanguageMenu(),
          ],
          bottom: TabBar(isScrollable: true, tabs: [
            Tab(text: context.tr('tab_notes')), Tab(text: context.tr('tab_files')),
            Tab(text: context.tr('tab_practice')), Tab(text: context.tr('tab_quizzes')),
          ]),
        ),
        body: Column(children: [
          Breadcrumb(items: [context.tr('nav_home'), context.loc(widget.ctx.levelName), context.loc(widget.ctx.subjectName), '${ch.number}']),
          Expanded(
            child: TabBarView(children: [
              _NotesTab(chapter: ch, resources: _resources),
              _FilesTab(resources: _resources),
              _PracticeTab(chapterId: ch.id),
              _QuizzesTab(chapterId: ch.id),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _NotesTab extends StatelessWidget {
  const _NotesTab({required this.chapter, required this.resources});
  final Chapter chapter;
  final Future<List<Resource>> resources;

  @override
  Widget build(BuildContext context) {
    final desc = context.loc(chapter.description);
    return FutureStateView<List<Resource>>(
      load: () => resources,
      builder: (context, all) {
        final items = all.where((r) => r.isText || r.isImage).toList();
        return ListView(padding: const EdgeInsets.all(16), children: [
          if (desc.isNotEmpty) RichContent(desc),
          if (chapter.objectives.isNotEmpty) ...[
            SectionTitle(context.tr('objectives')),
            for (final o in chapter.objectives)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Padding(padding: EdgeInsets.only(top: 2, right: 8), child: Icon(Icons.check_circle_outline, size: 18)),
                  Expanded(child: RichContent(o)),
                ]),
              ),
          ],
          if (items.isEmpty) Padding(padding: const EdgeInsets.only(top: 32), child: Center(child: Text(context.tr('empty_notes')))),
          for (final r in items)
            Card(
              margin: const EdgeInsets.only(top: 12),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(context.loc(r.title), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold))),
                    IconButton(icon: const Icon(Icons.flag_outlined, size: 18), tooltip: context.tr('report'), onPressed: () => showReportDialog(context, 'resource', r.id)),
                  ]),
                  if (r.isText) RichContent(context.loc(r.body)) else _SignedImage(path: r.filePath!),
                ]),
              ),
            ),
        ]);
      },
    );
  }
}

class _SignedImage extends StatefulWidget {
  const _SignedImage({required this.path});
  final String path;
  @override
  State<_SignedImage> createState() => _SignedImageState();
}

class _SignedImageState extends State<_SignedImage> {
  late final Future<String> _url = contentRepository.signedUrl(widget.path);
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: _url,
        builder: (context, s) {
          if (s.hasError) return Text(context.tr('error_generic'));
          if (!s.hasData) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
          return Image.network(s.data!, fit: BoxFit.contain,
              loadingBuilder: (c, child, p) => p == null ? child : const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
              errorBuilder: (c, e, st) => Text(context.tr('error_generic')));
        },
      );
}

class _FilesTab extends StatelessWidget {
  const _FilesTab({required this.resources});
  final Future<List<Resource>> resources;

  @override
  Widget build(BuildContext context) => FutureStateView<List<Resource>>(
        load: () => resources,
        isEmpty: (all) => !all.any((r) => r.isPdf),
        emptyMessage: context.tr('empty_files'),
        builder: (context, all) {
          final pdfs = all.where((r) => r.isPdf).toList();
          return ListView(padding: const EdgeInsets.all(16), children: [
            for (final r in pdfs)
              Card(child: ListTile(
                leading: const Icon(Icons.picture_as_pdf),
                title: Text(context.loc(r.title)),
                subtitle: Text(context.tr('tap_to_read')),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => PdfViewerScreen(title: context.loc(r.title), path: r.filePath!))),
              )),
          ]);
        },
      );
}

class _PracticeTab extends StatelessWidget {
  const _PracticeTab({required this.chapterId});
  final String chapterId;

  @override
  Widget build(BuildContext context) => FutureStateView<List<Question>>(
        load: () => contentRepository.practiceQuestions(chapterId),
        isEmpty: (q) => q.isEmpty,
        emptyMessage: context.tr('empty_practice'),
        builder: (context, qs) => ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: qs.length,
          itemBuilder: (context, i) => _PracticeCard(index: i + 1, question: qs[i]),
        ),
      );
}

class _PracticeCard extends StatefulWidget {
  const _PracticeCard({required this.index, required this.question});
  final int index;
  final Question question;
  @override
  State<_PracticeCard> createState() => _PracticeCardState();
}

class _PracticeCardState extends State<_PracticeCard> {
  bool _show = false;

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final scheme = Theme.of(context).colorScheme;
    final prompt = context.loc(q.prompt);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text('Q${widget.index}  ·  ${q.marks.toStringAsFixed(q.marks % 1 == 0 ? 0 : 1)} ${context.tr('marks')}', style: Theme.of(context).textTheme.labelLarge),
            const Spacer(),
            BookmarkButton(kind: 'question', targetId: q.id),
            IconButton(icon: const Icon(Icons.flag_outlined, size: 18), tooltip: context.tr('report'), onPressed: () => showReportDialog(context, 'question', q.id)),
          ]),
          RichContent(prompt),
          for (final o in q.options)
            Padding(padding: const EdgeInsets.only(top: 6, left: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${o.id.toUpperCase()}.  '), Expanded(child: RichContent(o.text)),
            ])),
          const SizedBox(height: 8),
          if (q.solution != null) ...[
            TextButton.icon(onPressed: () => setState(() => _show = !_show), icon: Icon(_show ? Icons.expand_less : Icons.expand_more), label: Text(context.tr(_show ? 'hide_solution' : 'show_solution'))),
            if (_show) Container(
              width: double.infinity, padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: scheme.secondaryContainer, borderRadius: BorderRadius.circular(8)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(Icons.verified, size: 18, color: scheme.primary), const SizedBox(width: 6),
                  Text(context.tr(q.solutionVerified ? 'verified_solution' : 'unverified_solution'), style: Theme.of(context).textTheme.labelLarge),
                ]),
                const SizedBox(height: 6),
                RichContent(q.solution!),
              ]),
            ),
          ] else
            OutlinedButton.icon(
              icon: const Icon(Icons.auto_awesome),
              label: Text(context.tr('ask_ai')),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => AnswerScreen.solve(question: prompt, level: 'school', subject: null, source: 'text', language: context.languageCode))),
            ),
        ]),
      ),
    );
  }
}

class _QuizzesTab extends StatefulWidget {
  const _QuizzesTab({required this.chapterId});
  final String chapterId;
  @override
  State<_QuizzesTab> createState() => _QuizzesTabState();
}

class _QuizzesTabState extends State<_QuizzesTab> {
  int _reload = 0;

  @override
  Widget build(BuildContext context) => FutureStateView<List<Quiz>>(
        key: ValueKey(_reload),
        load: () => contentRepository.quizzes(widget.chapterId),
        isEmpty: (q) => q.isEmpty,
        emptyMessage: context.tr('empty_quizzes'),
        builder: (context, quizzes) => ListView(padding: const EdgeInsets.all(16), children: [
          for (final q in quizzes)
            Card(child: ListTile(
              leading: const Icon(Icons.quiz),
              title: Text(context.loc(q.title)),
              subtitle: Text([
                if (q.timeLimitSeconds != null) '${(q.timeLimitSeconds! / 60).ceil()} min',
                if (q.negativeMarking > 0) '${context.tr('negative_marking')}: ${(q.negativeMarking * 100).toStringAsFixed(0)}%',
                '${context.tr('pass_mark')}: ${q.passPercentage.toStringAsFixed(0)}%',
              ].join('  ·  ')),
              trailing: FilledButton(
                onPressed: () async {
                  await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => QuizScreen(quiz: q)));
                  if (mounted) setState(() => _reload++);
                },
                child: Text(context.tr('start')),
              ),
            )),
        ]),
      );
}
