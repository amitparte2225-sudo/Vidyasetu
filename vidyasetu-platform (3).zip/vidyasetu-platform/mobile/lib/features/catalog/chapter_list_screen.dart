import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../data/content_repository.dart';
import '../../models/models.dart';
import '../../widgets/breadcrumb.dart';
import '../../widgets/future_state_view.dart';
import '../../widgets/language_menu.dart';
import 'chapter_detail_screen.dart';

class _ChaptersData {
  _ChaptersData(this.chapters, this.progress);
  final List<Chapter> chapters;
  final Map<String, ChapterProgress> progress;
}

class ChapterListScreen extends StatelessWidget {
  const ChapterListScreen({super.key, required this.subjectId, required this.title, required this.trail});

  final String subjectId;
  final String title;
  final List<String> trail;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title), actions: const [LanguageMenu()]),
      body: Column(children: [
        if (trail.isNotEmpty) Breadcrumb(items: [...trail, title]),
        Expanded(
          child: FutureStateView<_ChaptersData>(
            load: () async {
              final chapters = await contentRepository.chapters(subjectId);
              Map<String, ChapterProgress> progress = {};
              try {
                progress = await contentRepository.progress();
              } catch (_) {/* progress is optional */}
              return _ChaptersData(chapters, progress);
            },
            isEmpty: (d) => d.chapters.isEmpty,
            emptyMessage: context.tr('empty_chapters'),
            builder: (context, d) => ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: d.chapters.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final ch = d.chapters[i];
                final p = d.progress[ch.id];
                return Card(
                  margin: EdgeInsets.zero,
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${ch.number}')),
                    title: Text(context.loc(ch.title)),
                    subtitle: p == null ? null : Text('${context.tr('best_score')}: ${p.bestPercentage.toStringAsFixed(0)}%  ·  ${p.attempts} ${context.tr('attempts')}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ChapterDetailScreen(chapterId: ch.id))),
                  ),
                );
              },
            ),
          ),
        ),
      ]),
    );
  }
}
