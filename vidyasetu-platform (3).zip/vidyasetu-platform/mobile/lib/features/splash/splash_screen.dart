import 'dart:async';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/strings.dart';
import '../auth/auth_gate.dart';
import '../onboarding/onboarding_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 1400), _next);
  }

  Future<void> _next() async {
    var seen = false;
    try {
      seen = (await SharedPreferences.getInstance()).getBool('onboarded') ?? false;
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
      builder: (_) => seen ? const AuthGate() : const OnboardingScreen(),
    ));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: scheme.primary,
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.auto_stories, size: 80, color: scheme.onPrimary),
          const SizedBox(height: 16),
          Text(context.tr('app_name'),
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(color: scheme.onPrimary, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(context.tr('tagline'), style: TextStyle(color: scheme.onPrimary)),
        ]),
      ),
    );
  }
}
