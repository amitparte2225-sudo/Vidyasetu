import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../models/models.dart';
import '../../widgets/common.dart';
import '../../widgets/future_state_view.dart';
import '../../widgets/rich_content.dart';
import 'quiz_screen.dart';

String _answerText(ReviewItem r, List<dynamic> values, BuildContext context) {
  if (values.isEmpty) return '—';
  if (r.type == 'mcq_single' || r.type == 'mcq_multi') {
    return values.map((v) {
      final o = r.options.where((o) => o.id == '$v');
      return o.isEmpty ? '$v' : '${o.first.id.toUpperCase()}. ${o.first.text}';
    }).join('\n');
  }
  if (r.type == 'true_false') return values.map((v) => (v == true || '$v' == 'true') ? context.tr('true') : context.tr('false')).join();
  return values.join(' / ');
}

List<dynamic> _asList(dynamic v) => v == null ? const [] : (v is List ? v : [v]);

class ResultBody extends StatelessWidget {
  const ResultBody({super.key, required this.result, this.onRetake});
  final QuizResult result;
  final VoidCallback? onRetake;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final passed = result.passed;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        color: passed == null ? null : (passed ? scheme.primaryContainer : scheme.errorContainer),
        child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          Text('${result.percentage.toStringAsFixed(0)}%', style: Theme.of(context).textTheme.displayMedium?.copyWith(fontWeight: FontWeight.bold)),
          Text('${result.score.toStringAsFixed(1)} / ${result.maxScore.toStringAsFixed(1)} ${context.tr('marks')}'),
          if (passed != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(context.tr(passed ? 'passed' : 'not_passed'), style: Theme.of(context).textTheme.titleMedium)),
          const SizedBox(height: 12),
          Wrap(spacing: 16, children: [
            Text('✔ ${result.correct} ${context.tr('correct')}'),
            Text('✘ ${result.wrong} ${context.tr('wrong')}'),
            Text('– ${result.unanswered} ${context.tr('skipped')}'),
          ]),
          if (result.correct + result.wrong > 0) Padding(padding: const EdgeInsets.only(top: 8),
            child: Text('${context.tr('accuracy')}: ${(100 * result.correct / (result.correct + result.wrong)).toStringAsFixed(0)}%')),
        ])),
      ),
      if (onRetake != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: FilledButton.icon(onPressed: onRetake, icon: const Icon(Icons.replay), label: Text(context.tr('retake')))),
      SectionTitle(context.tr('review')),
      for (var i = 0; i < result.review.length; i++) _ReviewTile(index: i + 1, item: result.review[i]),
    ]);
  }
}

class _ReviewTile extends StatelessWidget {
  const _ReviewTile({required this.index, required this.item});
  final int index;
  final ReviewItem item;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final icon = item.isCorrect == null ? Icons.remove_circle_outline : (item.isCorrect! ? Icons.check_circle : Icons.cancel);
    final color = item.isCorrect == null ? scheme.outline : (item.isCorrect! ? Colors.green : scheme.error);
    return Card(
      child: ExpansionTile(
        leading: Icon(icon, color: color),
        title: Text('Q$index  ·  ${item.awarded >= 0 ? '+' : ''}${item.awarded.toStringAsFixed(2)}'),
        subtitle: Text(item.prompt.replaceAll(RegExp(r'\$'), ''), maxLines: 1, overflow: TextOverflow.ellipsis),
        childrenPadding: const EdgeInsets.all(14),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          RichContent(item.prompt),
          const SizedBox(height: 8),
          Text('${context.tr('your_answer')}:', style: Theme.of(context).textTheme.labelLarge),
          Text(_answerText(item, _asList(item.response), context)),
          const SizedBox(height: 8),
          Text('${context.tr('correct_answer')}:', style: Theme.of(context).textTheme.labelLarge),
          Text(_answerText(item, item.correct, context)),
          if ((item.explanation ?? '').isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('${context.tr('explanation')}:', style: Theme.of(context).textTheme.labelLarge),
            RichContent(item.explanation!),
          ],
        ],
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.result, required this.title, required this.quiz});
  final QuizResult result;
  final String title;
  final Quiz quiz;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: ResultBody(
          result: result,
          onRetake: () => Navigator.of(context).pushReplacement(MaterialPageRoute<void>(builder: (_) => QuizScreen(quiz: quiz))),
        ),
      );
}

/// Review of a past attempt (from the history list).
class AttemptReviewScreen extends StatelessWidget {
  const AttemptReviewScreen({super.key, required this.attemptId, required this.title});
  final String attemptId;
  final String title;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: FutureStateView<QuizResult>(
          load: () async => QuizResult.fromJson(await backend.get('/v1/attempts/$attemptId/review')),
          emptyMessage: '',
          builder: (context, r) => ResultBody(result: r),
        ),
      );
}
