import 'dart:async';

import 'package:flutter/material.dart';

import '../../core/strings.dart';
import '../../models/models.dart';
import '../../services/backend_client.dart';
import '../../widgets/common.dart';
import '../../widgets/rich_content.dart';
import 'result_screen.dart';

final backend = BackendClient();

/// Takes a quiz. Questions come from the server WITHOUT answers; grading happens on the server.
class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key, required this.quiz});
  final Quiz quiz;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  QuizSession? _session;
  String? _error;
  final Map<String, dynamic> _answers = {};
  int _index = 0;
  Timer? _timer;
  Duration? _remaining;
  bool _submitting = false;
  final _text = TextEditingController();

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _text.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    try {
      final json = await backend.post('/v1/quizzes/${widget.quiz.id}/start', {});
      final s = QuizSession.fromJson(json);
      if (!mounted) return;
      setState(() => _session = s);
      _syncTextField();
      if (s.expiresAt != null) {
        _timer = Timer.periodic(const Duration(seconds: 1), (_) {
          final left = s.expiresAt!.difference(DateTime.now().toUtc());
          if (!mounted) return;
          setState(() => _remaining = left);
          if (left <= Duration.zero) {
            _timer?.cancel();
            _submit(auto: true);
          }
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = errorText(e));
    }
  }

  QuizQuestion get _q => _session!.questions[_index];

  void _syncTextField() {
    final v = _answers[_q.id];
    _text.text = (v is String && (_q.type == 'numeric' || _q.type == 'short_answer')) ? v : '';
  }

  void _go(int i) {
    setState(() => _index = i);
    _syncTextField();
  }

  Future<void> _submit({bool auto = false}) async {
    if (_submitting) return;
    final s = _session!;
    if (!auto) {
      final blank = s.questions.where((q) => !_answered(q.id)).length;
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(ctx.tr('submit_quiz')),
          content: Text(blank > 0 ? '${ctx.tr('unanswered')}: $blank' : ctx.tr('all_answered')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(ctx.tr('cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(ctx.tr('submit'))),
          ],
        ),
      );
      if (ok != true) return;
    }
    setState(() => _submitting = true);
    try {
      final json = await backend.post('/v1/attempts/${s.attemptId}/submit', {'responses': _answers});
      final result = QuizResult.fromJson(json);
      _timer?.cancel();
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute<void>(
        builder: (_) => ResultScreen(result: result, title: s.title, quiz: widget.quiz),
      ));
    } catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      showMessage(context, errorText(e));
    }
  }

  bool _answered(String id) {
    final v = _answers[id];
    if (v == null) return false;
    if (v is String) return v.trim().isNotEmpty;
    if (v is List) return v.isNotEmpty;
    return true;
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final title = context.loc(widget.quiz.title);
    if (_error != null) {
      return Scaffold(appBar: AppBar(title: Text(title)), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 12),
        FilledButton(onPressed: () { setState(() => _error = null); _start(); }, child: Text(context.tr('retry'))),
      ]))));
    }
    final s = _session;
    if (s == null) return Scaffold(appBar: AppBar(title: Text(title)), body: const Center(child: CircularProgressIndicator()));
    final q = _q;
    final last = _index == s.questions.length - 1;
    final low = _remaining != null && _remaining! < const Duration(seconds: 60);
    return Scaffold(
      appBar: AppBar(
        title: Text('${_index + 1} / ${s.questions.length}'),
        actions: [
          if (_remaining != null)
            Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: Text(
              _fmt(_remaining! < Duration.zero ? Duration.zero : _remaining!),
              style: TextStyle(fontWeight: FontWeight.bold, color: low ? Theme.of(context).colorScheme.error : null)))),
          TextButton(onPressed: _submitting ? null : _submit, child: Text(context.tr('submit'))),
        ],
        bottom: PreferredSize(preferredSize: const Size.fromHeight(4), child: LinearProgressIndicator(value: (_index + 1) / s.questions.length)),
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text('${q.marks.toStringAsFixed(q.marks % 1 == 0 ? 0 : 1)} ${context.tr('marks')}', style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 8),
        RichContent(q.prompt, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 16),
        _input(q),
      ]),
      bottomNavigationBar: SafeArea(child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          OutlinedButton(onPressed: _index == 0 ? null : () => _go(_index - 1), child: Text(context.tr('previous'))),
          const Spacer(),
          if (_submitting) const CircularProgressIndicator()
          else FilledButton(onPressed: () => last ? _submit() : _go(_index + 1), child: Text(last ? context.tr('finish') : context.tr('next'))),
        ]),
      )),
    );
  }

  Widget _input(QuizQuestion q) {
    switch (q.type) {
      case 'mcq_single':
        return Column(children: [for (final o in q.options) RadioListTile<String>(
          value: o.id, groupValue: _answers[q.id] as String?, title: RichContent(o.text),
          onChanged: (v) => setState(() => _answers[q.id] = v),
        )]);
      case 'mcq_multi':
        final sel = (_answers[q.id] as List?)?.cast<String>() ?? <String>[];
        return Column(children: [for (final o in q.options) CheckboxListTile(
          value: sel.contains(o.id), title: RichContent(o.text),
          onChanged: (on) => setState(() => _answers[q.id] = on == true ? [...sel, o.id] : sel.where((x) => x != o.id).toList()),
        )]);
      case 'true_false':
        return Column(children: [
          RadioListTile<bool>(value: true, groupValue: _answers[q.id] as bool?, title: Text(context.tr('true')), onChanged: (v) => setState(() => _answers[q.id] = v)),
          RadioListTile<bool>(value: false, groupValue: _answers[q.id] as bool?, title: Text(context.tr('false')), onChanged: (v) => setState(() => _answers[q.id] = v)),
        ]);
      case 'numeric':
        return TextField(
          controller: _text, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
          decoration: InputDecoration(labelText: context.tr('your_answer_number'), border: const OutlineInputBorder()),
          onChanged: (v) => _answers[q.id] = v,
        );
      default:
        return TextField(
          controller: _text, maxLength: 300,
          decoration: InputDecoration(labelText: context.tr('your_answer'), border: const OutlineInputBorder()),
          onChanged: (v) => _answers[q.id] = v,
        );
    }
  }
}
