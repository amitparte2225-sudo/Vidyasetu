import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/strings.dart';
import '../../widgets/language_menu.dart';
import '../auth/auth_gate.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;

  static const _pages = [
    (Icons.menu_book, 'onb1_title', 'onb1_body'),
    (Icons.quiz, 'onb2_title', 'onb2_body'),
    (Icons.camera_alt, 'onb3_title', 'onb3_body'),
  ];

  Future<void> _finish() async {
    try {
      await (await SharedPreferences.getInstance()).setBool('onboarded', true);
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute<void>(builder: (_) => const AuthGate()));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final last = _page == _pages.length - 1;
    return Scaffold(
      appBar: AppBar(actions: const [LanguageMenu()]),
      body: Column(children: [
        Expanded(
          child: PageView(
            controller: _controller,
            onPageChanged: (i) => setState(() => _page = i),
            children: [
              for (final p in _pages)
                Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(p.$1, size: 96, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(height: 24),
                    Text(context.tr(p.$2), style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    Text(context.tr(p.$3), textAlign: TextAlign.center),
                  ]),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            TextButton(onPressed: _finish, child: Text(context.tr('skip'))),
            const Spacer(),
            FilledButton(
              onPressed: () => last
                  ? _finish()
                  : _controller.nextPage(duration: const Duration(milliseconds: 250), curve: Curves.easeOut),
              child: Text(last ? context.tr('get_started') : context.tr('next')),
            ),
          ]),
        ),
      ]),
    );
  }
}
