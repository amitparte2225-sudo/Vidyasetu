import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/models.dart';

/// The ONLY way screens read educational content. Everything comes from the database;
/// what an administrator publishes appears here with no app update.
abstract class ContentRepository {
  Future<List<Level>> topLevels();
  Future<List<Level>> childLevels(String parentId);
  Future<Level?> level(String id);
  Future<List<Subject>> subjects(String levelId);
  Future<List<Chapter>> chapters(String subjectId);
  Future<ChapterContext?> chapter(String id);
  Future<List<Resource>> resources(String chapterId);
  Future<List<Question>> practiceQuestions(String chapterId);
  Future<List<Quiz>> quizzes(String chapterId);
  Future<Map<String, ChapterProgress>> progress();
  Future<List<SearchHit>> search(String query);
  Future<Uint8List> download(String path);
  Future<String> signedUrl(String path);
}

typedef Rows = List<Map<String, dynamic>>;

class SupabaseContentRepository implements ContentRepository {
  SupabaseClient get _db => Supabase.instance.client;

  Rows _rows(Object? data) => (data as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  @override
  Future<List<Level>> topLevels() async {
    final data = await _db
        .from('levels')
        .select('*, institutions(name, name_i18n)')
        .isFilter('parent_id', null)
        .order('display_order');
    return _rows(data).map(Level.fromRow).toList();
  }

  @override
  Future<List<Level>> childLevels(String parentId) async {
    final data = await _db
        .from('levels')
        .select('*, institutions(name, name_i18n)')
        .eq('parent_id', parentId)
        .order('display_order');
    return _rows(data).map(Level.fromRow).toList();
  }

  @override
  Future<Level?> level(String id) async {
    final data = await _db.from('levels').select('*, institutions(name, name_i18n)').eq('id', id).maybeSingle();
    return data == null ? null : Level.fromRow(data);
  }

  @override
  Future<List<Subject>> subjects(String levelId) async {
    final data = await _db.from('subjects').select().eq('level_id', levelId).order('display_order');
    return _rows(data).map(Subject.fromRow).toList();
  }

  @override
  Future<List<Chapter>> chapters(String subjectId) async {
    final data = await _db.from('chapters').select().eq('subject_id', subjectId).order('display_order');
    return _rows(data).map(Chapter.fromRow).toList();
  }

  @override
  Future<ChapterContext?> chapter(String id) async {
    final data = await _db
        .from('chapters')
        .select('*, subjects(id, level_id, name, name_i18n, levels(id, name, name_i18n))')
        .eq('id', id)
        .maybeSingle();
    if (data == null) return null;
    final s = Map<String, dynamic>.from(data['subjects'] as Map);
    final l = Map<String, dynamic>.from(s['levels'] as Map);
    return ChapterContext(Chapter.fromRow(data), LocalizedText.fromRow(s['name'], s['name_i18n']),
        LocalizedText.fromRow(l['name'], l['name_i18n']), '${l['id']}', '${s['id']}');
  }

  @override
  Future<List<Resource>> resources(String chapterId) async {
    final data = await _db.from('resources').select().eq('chapter_id', chapterId).order('display_order');
    return _rows(data).map(Resource.fromRow).toList();
  }

  @override
  Future<List<Question>> practiceQuestions(String chapterId) async {
    final data = await _db
        .from('questions')
        .select('*, solutions(body_md, is_verified)')
        .eq('chapter_id', chapterId)
        .order('display_order');
    return _rows(data).map(Question.fromRow).toList();
  }

  @override
  Future<List<Quiz>> quizzes(String chapterId) async {
    final data = await _db.from('quizzes').select().eq('chapter_id', chapterId).order('display_order');
    return _rows(data).map(Quiz.fromRow).toList();
  }

  @override
  Future<Map<String, ChapterProgress>> progress() async {
    final data = await _db.from('my_chapter_progress').select();
    return {
      for (final r in _rows(data))
        '${r['chapter_id']}': ChapterProgress((r['attempts'] as num?)?.toInt() ?? 0, (r['best_percentage'] as num?)?.toDouble() ?? 0)
    };
  }

  @override
  Future<List<SearchHit>> search(String query) async {
    final data = await _db.rpc('search_content', params: {'q': query.trim(), 'max_results': 40});
    return _rows(data).map(SearchHit.fromRow).toList();
  }

  @override
  Future<Uint8List> download(String path) => _db.storage.from('content').download(path);

  @override
  Future<String> signedUrl(String path) => _db.storage.from('content').createSignedUrl(path, 600);
}

/// Swapped in tests.
ContentRepository contentRepository = SupabaseContentRepository();
