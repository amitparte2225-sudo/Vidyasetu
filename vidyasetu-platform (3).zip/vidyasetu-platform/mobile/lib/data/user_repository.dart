import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/models.dart';

/// The signed-in student's own records. Row Level Security guarantees a student can only ever see their own rows.
class UserRepository {
  SupabaseClient get _db => Supabase.instance.client;
  String get userId => _db.auth.currentUser!.id;

  List<Map<String, dynamic>> _rows(Object? data) =>
      (data as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  // ---- profile
  Future<Profile?> profile() async {
    final r = await _db.from('profiles').select().eq('id', userId).maybeSingle();
    return r == null ? null : Profile.fromRow(r);
  }

  Future<void> updateProfile({String? displayName, String? language, String? levelId, bool clearLevel = false}) async {
    final patch = <String, dynamic>{
      if (displayName != null) 'display_name': displayName.trim(),
      if (language != null) 'preferred_language': language,
      if (levelId != null || clearLevel) 'level_id': clearLevel ? null : levelId,
    };
    if (patch.isNotEmpty) await _db.from('profiles').update(patch).eq('id', userId);
  }

  // ---- bookmarks
  Future<Set<String>> bookmarkedIds(String kind) async {
    final r = await _db.from('bookmarks').select('target_id').eq('kind', kind);
    return _rows(r).map((e) => '${e['target_id']}').toSet();
  }

  Future<bool> isBookmarked(String kind, String id) async {
    final r = await _db.from('bookmarks').select('id').eq('kind', kind).eq('target_id', id).maybeSingle();
    return r != null;
  }

  Future<void> setBookmark(String kind, String id, bool on) async {
    if (on) {
      await _db.from('bookmarks').upsert({'user_id': userId, 'kind': kind, 'target_id': id}, onConflict: 'user_id,kind,target_id');
    } else {
      await _db.from('bookmarks').delete().eq('kind', kind).eq('target_id', id);
    }
  }

  Future<List<Map<String, dynamic>>> bookmarkedChapters() async {
    final ids = (await bookmarkedIds('chapter')).toList();
    if (ids.isEmpty) return [];
    return _rows(await _db.from('chapters').select('id, number, title, title_i18n').inFilter('id', ids));
  }

  Future<List<Map<String, dynamic>>> bookmarkedQuestions() async {
    final ids = (await bookmarkedIds('question')).toList();
    if (ids.isEmpty) return [];
    return _rows(await _db.from('questions').select('id, chapter_id, prompt, prompt_i18n').inFilter('id', ids));
  }

  Future<List<SolverRecord>> bookmarkedSolutions() async {
    final ids = (await bookmarkedIds('solver_request')).toList();
    if (ids.isEmpty) return [];
    return _rows(await _db.from('solver_requests').select().inFilter('id', ids).eq('kind', 'solve'))
        .map(SolverRecord.fromRow).toList();
  }

  // ---- AI history
  Future<List<SolverRecord>> solverHistory() async {
    final r = await _db.from('solver_requests').select().eq('kind', 'solve').eq('status', 'ok')
        .order('created_at', ascending: false).limit(50);
    return _rows(r).map(SolverRecord.fromRow).toList();
  }

  Future<void> deleteSolverHistory() async => _db.rpc('delete_my_solver_history');

  // ---- quiz history
  Future<List<Map<String, dynamic>>> quizHistory() async {
    final r = await _db.from('quiz_attempts')
        .select('id, quiz_id, percentage, score, max_score, submitted_at, quizzes(title, title_i18n)')
        .eq('status', 'submitted').order('submitted_at', ascending: false).limit(100);
    return _rows(r);
  }

  // ---- reports
  Future<void> report(String kind, String targetId, String reason) async {
    await _db.from('content_reports').insert({'reporter_id': userId, 'target_kind': kind, 'target_id': targetId, 'reason': reason.trim()});
  }
}

UserRepository userRepository = UserRepository();
