import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';

class ApiException implements Exception {
  ApiException(this.message, {this.status});
  final String message; // always safe to show to the student
  final int? status;
  @override
  String toString() => message;
}

/// Talks to the FastAPI backend. Sends the student's Supabase access token; never any secret.
class BackendClient {
  Uri _uri(String path) => Uri.parse('${AppConfig.backendUrl.replaceAll(RegExp(r'/+$'), '')}$path');

  Future<Map<String, String>> _headers({bool json = true}) async {
    final auth = Supabase.instance.client.auth;
    var session = auth.currentSession;
    if (session != null && session.isExpired) {
      session = (await auth.refreshSession()).session;
    }
    final token = session?.accessToken;
    if (token == null) throw ApiException('Please sign in again.', status: 401);
    return {'Authorization': 'Bearer $token', if (json) 'Content-Type': 'application/json'};
  }

  Map<String, dynamic> _handle(http.Response r) {
    Map<String, dynamic> body = {};
    try {
      final decoded = jsonDecode(utf8.decode(r.bodyBytes));
      if (decoded is Map<String, dynamic>) body = decoded;
    } catch (_) {}
    if (r.statusCode >= 200 && r.statusCode < 300) return body;
    final detail = body['detail'];
    var msg = detail is String ? detail : null;
    msg ??= switch (r.statusCode) {
      401 => 'Your session has expired. Please sign in again.',
      413 => 'The file is too large.',
      422 => 'The request was not valid. Please check your input.',
      429 => 'Too many requests. Please wait a little and try again.',
      503 => 'This service is not available right now.',
      _ => 'Something went wrong on the server (${r.statusCode}).',
    };
    throw ApiException(msg, status: r.statusCode);
  }

  Future<Map<String, dynamic>> _run(Future<http.Response> Function() call) async {
    if (!AppConfig.backendConfigured) {
      throw ApiException('The app was built without a backend address (BACKEND_URL).');
    }
    try {
      return _handle(await call().timeout(const Duration(seconds: 120)));
    } on TimeoutException {
      throw ApiException('The server took too long to answer. Please try again.');
    } on http.ClientException {
      throw ApiException('Could not reach the server. Check your internet connection.');
    }
  }

  Future<Map<String, dynamic>> get(String path) async =>
      _run(() async => http.get(_uri(path), headers: await _headers()));

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body) async =>
      _run(() async => http.post(_uri(path), headers: await _headers(), body: jsonEncode(body)));

  Future<Map<String, dynamic>> postFile(String path, Uint8List bytes, String filename, Map<String, String> fields) async =>
      _run(() async {
        final req = http.MultipartRequest('POST', _uri(path))
          ..headers.addAll(await _headers(json: false))
          ..fields.addAll(fields)
          ..files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
        return http.Response.fromStream(await req.send());
      });
}
