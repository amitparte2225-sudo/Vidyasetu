import 'package:flutter/material.dart';

import 'core/app_settings.dart';
import 'core/app_theme.dart';
import 'features/splash/splash_screen.dart';

class VidyasetuApp extends StatelessWidget {
  const VidyasetuApp({super.key, required this.settings, this.home});

  final AppSettings settings;

  /// Tests pass a screen here to skip the splash/auth flow.
  final Widget? home;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      settings: settings,
      child: MaterialApp(
        title: 'Vidyasetu',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: ThemeMode.system,
        home: home ?? const SplashScreen(),
      ),
    );
  }
}
