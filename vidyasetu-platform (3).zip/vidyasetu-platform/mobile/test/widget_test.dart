import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vidyasetu/app.dart';
import 'package:vidyasetu/core/app_settings.dart';
import 'package:vidyasetu/data/content_repository.dart';
import 'package:vidyasetu/features/home/home_screen.dart';
import 'package:vidyasetu/widgets/rich_content.dart';

import 'support/fake_repository.dart';

void main() {
  tearDown(() => contentRepository = SupabaseContentRepository());

  testWidgets('home courses come from the repository and group by institution', (tester) async {
    contentRepository = FakeContentRepository(levels: [
      FakeContentRepository.level('1', 'Class 9', mr: 'इयत्ता ९वी'),
      FakeContentRepository.level('2', 'Class 10'),
    ]);
    await tester.pumpWidget(VidyasetuApp(settings: AppSettings(), home: const Scaffold(body: CoursesTab())));
    await tester.pumpAndSettle();
    expect(find.text('Class 9'), findsOneWidget);
    expect(find.text('Class 10'), findsOneWidget);
    expect(find.text('Maharashtra State Board'), findsOneWidget);
  });

  testWidgets('Marathi content is shown when Marathi is selected', (tester) async {
    contentRepository = FakeContentRepository(levels: [FakeContentRepository.level('1', 'Class 9', mr: 'इयत्ता ९वी')]);
    await tester.pumpWidget(VidyasetuApp(settings: AppSettings('mr'), home: const Scaffold(body: CoursesTab())));
    await tester.pumpAndSettle();
    expect(find.text('इयत्ता ९वी'), findsOneWidget);
  });

  testWidgets('empty database shows the empty state, not fake data', (tester) async {
    contentRepository = FakeContentRepository();
    await tester.pumpWidget(VidyasetuApp(settings: AppSettings(), home: const Scaffold(body: CoursesTab())));
    await tester.pumpAndSettle();
    expect(find.text('No courses have been published yet.'), findsOneWidget);
  });

  testWidgets('errors show a retry button', (tester) async {
    contentRepository = FakeContentRepository(fail: true);
    await tester.pumpWidget(VidyasetuApp(settings: AppSettings(), home: const Scaffold(body: CoursesTab())));
    await tester.pumpAndSettle();
    expect(find.text('Try again'), findsOneWidget);
  });

  testWidgets('RichContent renders headings, bullets and maths without throwing', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(body: SingleChildScrollView(
      child: RichContent('# Title\nA quadratic is \$ax^2+bx+c=0\$.\n- first\n- **bold** item\n\$\$x=\\frac{-b}{2a}\$\$')))));
    await tester.pumpAndSettle();
    expect(find.text('Title'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
