import 'dart:typed_data';

import 'package:vidyasetu/core/localized_text.dart';
import 'package:vidyasetu/data/content_repository.dart';
import 'package:vidyasetu/models/models.dart';

/// Test double: lets widget tests run without Supabase.
class FakeContentRepository implements ContentRepository {
  FakeContentRepository({this.levels = const [], this.fail = false});
  final List<Level> levels;
  final bool fail;

  static Level level(String id, String name, {String? mr, String institution = 'board'}) => Level(
        id: id, institutionId: institution, parentId: null, kind: 'class',
        name: LocalizedText({'en': name, if (mr != null) 'mr': mr}),
        institutionName: const LocalizedText({'en': 'Maharashtra State Board'}),
      );

  @override
  Future<List<Level>> topLevels() async {
    if (fail) throw Exception('boom');
    return levels;
  }

  @override
  Future<List<Level>> childLevels(String parentId) async => [];
  @override
  Future<Level?> level(String id) async => null;
  @override
  Future<List<Subject>> subjects(String levelId) async => [];
  @override
  Future<List<Chapter>> chapters(String subjectId) async => [];
  @override
  Future<ChapterContext?> chapter(String id) async => null;
  @override
  Future<List<Resource>> resources(String chapterId) async => [];
  @override
  Future<List<Question>> practiceQuestions(String chapterId) async => [];
  @override
  Future<List<Quiz>> quizzes(String chapterId) async => [];
  @override
  Future<Map<String, ChapterProgress>> progress() async => {};
  @override
  Future<List<SearchHit>> search(String query) async => [];
  @override
  Future<Uint8List> download(String path) async => Uint8List(0);
  @override
  Future<String> signedUrl(String path) async => '';
}
