import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

/// Every English UI string must also exist in Marathi (otherwise Marathi users see English).
void main() {
  test('Marathi translations cover every English key', () {
    final src = File('lib/core/strings.dart').readAsStringSync();
    final enStart = src.indexOf("'en': {");
    final mrStart = src.indexOf("'mr': {");
    expect(enStart, greaterThan(0));
    expect(mrStart, greaterThan(enStart));
    final key = RegExp(r"^\s+'([a-z0-9_]+)':", multiLine: true);
    final en = key.allMatches(src.substring(enStart, mrStart)).map((m) => m.group(1)!).toSet();
    final mr = key.allMatches(src.substring(mrStart)).map((m) => m.group(1)!).toSet();
    expect(en.length, greaterThan(100));
    expect(en.difference(mr), isEmpty, reason: 'keys missing in Marathi');
  });
}
