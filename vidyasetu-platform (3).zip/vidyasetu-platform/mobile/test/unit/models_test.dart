import 'package:flutter_test/flutter_test.dart';
import 'package:vidyasetu/core/localized_text.dart';
import 'package:vidyasetu/models/models.dart';

void main() {
  group('LocalizedText', () {
    test('uses the requested language and falls back to English', () {
      final t = LocalizedText.fromRow('Physics', {'mr': 'भौतिकशास्त्र', 'hi': ''});
      expect(t.resolve('mr'), 'भौतिकशास्त्र');
      expect(t.resolve('hi'), 'Physics'); // empty translation ignored
      expect(t.resolve('fr'), 'Physics');
    });
    test('tolerates a missing i18n column', () {
      expect(LocalizedText.fromRow('A', null).resolve('mr'), 'A');
    });
  });

  group('Level / Chapter parsing', () {
    test('level with institution join', () {
      final l = Level.fromRow({
        'id': 'l1', 'institution_id': 'i1', 'parent_id': null, 'kind': 'degree',
        'name': 'B.Sc. Physics', 'name_i18n': {'mr': 'बी.एस्सी.'},
        'institutions': {'name': 'University of Mumbai', 'name_i18n': {}},
      });
      expect(l.name.resolve('mr'), 'बी.एस्सी.');
      expect(l.institutionName.resolve('en'), 'University of Mumbai');
      expect(l.parentId, isNull);
    });
    test('chapter parses objectives and numbers', () {
      final c = Chapter.fromRow({
        'id': 'c', 'subject_id': 's', 'number': 3, 'title': 'T', 'title_i18n': {}, 'description': null,
        'description_i18n': {}, 'objectives': ['a', 'b'],
      });
      expect(c.number, 3);
      expect(c.objectives, ['a', 'b']);
      expect(c.description.resolve('en'), '');
    });
  });

  group('Question', () {
    test('picks up a published solution and its verified flag', () {
      final q = Question.fromRow({
        'id': 'q', 'type': 'short_answer', 'prompt': 'p', 'prompt_i18n': {}, 'options': [], 'marks': 2,
        'solutions': [{'body_md': 'steps', 'is_verified': true}],
      });
      expect(q.solution, 'steps');
      expect(q.solutionVerified, isTrue);
      expect(q.marks, 2.0);
    });
    test('no solution rows -> null', () {
      final q = Question.fromRow({'id': 'q', 'type': 'mcq_single', 'prompt': 'p', 'prompt_i18n': {},
        'options': [{'id': 'a', 'text': 'x'}, {'id': 'b', 'text': 'y'}], 'marks': '1.50', 'solutions': []});
      expect(q.solution, isNull);
      expect(q.options.length, 2);
      expect(q.marks, 1.5); // numeric strings are handled
    });
  });

  group('Quiz result and AI solution parsing', () {
    test('QuizResult', () {
      final r = QuizResult.fromJson({
        'attempt_id': 'a', 'score': 3.5, 'max_score': 6, 'percentage': 58.33, 'passed': true,
        'correct_count': 1, 'wrong_count': 1, 'unanswered_count': 0,
        'review': [{'type': 'mcq_single', 'prompt': 'p', 'options': [], 'marks': 2, 'response': 'b',
          'is_correct': false, 'awarded': -0.5, 'correct': ['a'], 'explanation': 'because'}],
      });
      expect(r.percentage, closeTo(58.33, 0.001));
      expect(r.review.single.correct, ['a']);
      expect(r.review.single.isCorrect, isFalse);
    });

    test('AiSolution with verification', () {
      final s = AiSolution.fromJson({
        'readable': true, 'question_understood': 'q', 'concepts': ['c'],
        'steps': [{'title': 't', 'explanation': 'e', 'calculation': 'x=1'}],
        'intermediate_results': ['x=1'], 'final_answer': '1', 'units': null, 'assumptions': [],
        'explanation': 'ex', 'verification': {'status': 'verified', 'detail': 'ok'},
      });
      expect(s.readable, isTrue);
      expect(s.steps.single.calculation, 'x=1');
      expect(s.verificationStatus, 'verified');
    });

    test('AiSolution unreadable and missing verification', () {
      final s = AiSolution.fromJson({'readable': false, 'unreadable_reason': 'blurry'});
      expect(s.readable, isFalse);
      expect(s.verificationStatus, 'unavailable');
    });

    test('QuizSession parses expiry', () {
      final s = QuizSession.fromJson({
        'attempt_id': 'a', 'title': 'T', 'time_limit_seconds': 600, 'expires_at': '2026-01-01T10:00:00+00:00',
        'negative_marking': 0.25, 'questions': [{'id': 'q', 'type': 'numeric', 'prompt': 'p', 'options': [], 'marks': 1}],
      });
      expect(s.expiresAt!.isUtc, isTrue);
      expect(s.questions.single.type, 'numeric');
    });
  });
}
