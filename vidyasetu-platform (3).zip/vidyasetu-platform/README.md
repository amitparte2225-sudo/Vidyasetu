# Vidyasetu: educational learning platform

Flutter Android app + Next.js admin dashboard + Supabase (Auth, PostgreSQL, Storage, Row Level Security) + FastAPI AI/quiz backend.
"Vidyasetu" is a working name. All educational text in `supabase/seed.sql` is original sample content written for this project.

## Read this first: what has and has not been verified

This project was written in a sandbox with **no Flutter SDK, no Node packages, no PostgreSQL and no internet**. So:

| Part | Verified here | How it is verified for you |
|---|---|---|
| Backend logic (grading, answer parsing, PDF/image validation, OCR, math check, rate limit, quiz flow with a fake database) | **Yes: 46 Python tests run and passed** (4 more API tests skipped because FastAPI was not installed) | `backend-tests` GitHub workflow re-runs them, including the API tests |
| SQL migrations and Row Level Security | **No** (no PostgreSQL available) | `database-tests` workflow applies them to PostgreSQL 16 and runs `supabase/tests/rls_test.sql` (about 40 security assertions) |
| Flutter app (compile, analyze, tests, APK) | **No** | `build-android-apk` workflow. **Your first run is the first real compile; expect to send me the error log if it fails.** |
| Next.js admin (typecheck, build) | **No** | `admin-build` workflow |
| Real AI answers, real OCR on your photos, real Supabase calls | **No** (needs your credentials) | Follow the setup below, then try it |

Nothing here is claimed to work end-to-end until those workflows are green and you have tried it on a phone.

## How it fits together

```
Android app (Flutter) --anon key + user JWT--> Supabase (Auth, Postgres+RLS, Storage)
        |                                              ^
        +--user JWT--> FastAPI backend --service key---+   (quizzes, OCR, PDF text, AI solver)
                              |
                              +--AI key--> AI provider (Anthropic or any OpenAI-compatible)
Admin dashboard (Next.js) --anon key + admin's JWT--> Supabase   (every write is checked by RLS)
```

* **Content is never hard-coded.** Boards, classes, subjects, chapters, notes, PDFs, questions and quizzes live in the database. Publish in the admin dashboard and it appears in the app straight away (no rebuild).
* **Hierarchy:** Board/University > Class/Degree/Semester > Subject > Chapter > Topic > Notes, PDFs, questions, quizzes.
* **Security model:** students can only read *published* content (and only if its whole parent chain is published) and their own records. Answer keys are in a table students cannot read. Quizzes are graded on the server. The service-role key and AI key exist only on the backend.
* **AI answers are always labelled** "AI-generated, not verified". Administrator-written solutions show "Verified". A SymPy check of the final number is shown when the AI supplies one.

### Versions chosen
Flutter stable (installed by CI; not pinned because I could not verify a version, so pin it after your first green run), Dart `>=3.5`, Java 17. Flutter packages: `supabase_flutter ^2.8`, `http ^1.2`, `file_picker ^8.1`, `image_picker ^1.1`, `image ^4.2`, `pdfx ^2.9`, `flutter_math_fork ^0.7`, `shared_preferences ^2.3`. Admin: Next.js 14.2.15, React 18.3, supabase-js 2.45+. Backend: Python 3.12, FastAPI, Pillow, pypdf, pypdfium2, pytesseract, SymPy.

---

## Step 1: Supabase (database, login, file storage)

1. Create a free project at https://supabase.com. Note the **Project URL**, the **anon public key**, and the **service_role key** (Project Settings > API). Treat service_role like a password.
2. Open **SQL Editor** and run these files **in this order** (copy the file contents, press Run):
   1. `supabase/migrations/20260101000001_schema.sql`
   2. `supabase/migrations/20260101000002_rls.sql`
   3. `supabase/migrations/20260101000003_storage.sql`
   4. `supabase/seed.sql` (sample content: Maharashtra Board Classes 7 to 12, B.Sc. Physics/Mathematics, Engineering Mathematics, a Class 10 quadratic-equations chapter with notes and a 5-question quiz)
3. **Authentication > Providers > Email:** for easy testing turn **off** "Confirm email". For real use leave it on.
4. **Create the first administrator:** register an account (admin login page cannot sign up), then open `supabase/make_admin.sql`, put your e-mail in it, and run it in the SQL Editor. There is deliberately no way to become admin from the app or website.

## Step 2: Backend (Windows 10/11, PowerShell)

1. Install **Python 3.12** from python.org (tick "Add python.exe to PATH").
2. Install **Tesseract OCR** (Windows build from the UB Mannheim page: search "tesseract UB Mannheim"). In the installer tick the **Marathi** (and Hindi) language data. Add `C:\Program Files\Tesseract-OCR` to PATH.
3. ```powershell
   cd backend
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   copy .env.example .env
   notepad .env
   ```
   Fill `.env`: the three Supabase values; `AI_PROVIDER` (`anthropic` or `openai`), `AI_API_KEY`, `AI_MODEL` (a **vision-capable** model id from your provider's documentation, for example `claude-sonnet-5-5` on Anthropic; check it is current). `AI_BASE_URL` is only for OpenAI-compatible servers. Without the `AI_*` values the app works except solving (it says so honestly).
4. Run it (loads `.env` yourself, since uvicorn does not):
   ```powershell
   Get-Content .env | ForEach-Object { if ($_ -match '^\s*([A-Z_]+)=(.*?)\s*(#.*)?$') { [Environment]::SetEnvironmentVariable($matches[1], $matches[2]) } }
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```
   Check http://localhost:8000/health. Interactive docs: http://localhost:8000/docs
5. **The phone needs a public HTTPS address** for `BACKEND_URL`. Deploy the included `Dockerfile` (installs Tesseract with Marathi) to any container host (Render, Fly.io, Railway, Google Cloud Run...). Set the same environment variables there. For quick tests on your own Wi-Fi you can use `http://YOUR-PC-IP:8000`, but Android blocks plain `http` in release builds unless you allow it, so deploy for real use.
6. Tests: `python -m unittest discover -s tests -v`

Controls built in: per-user and per-IP rate limits, daily/monthly quotas (editable in the admin "AI limits" page), upload size/page limits, image downscaling before the AI, `AI_MAX_OUTPUT_TOKENS` cost cap, and logs that contain no questions, images or tokens. The in-memory rate limiter is per server instance; the database quotas are global.

## Step 3: Admin dashboard

1. Install **Node.js 20 LTS** (nodejs.org).
2. ```powershell
   cd admin
   copy .env.local.example .env.local
   notepad .env.local      # NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY only
   npm install
   npm run dev
   ```
   Open http://localhost:3000 and sign in with the admin account. For production, deploy `admin/` to Vercel/Netlify with those two variables. **Never put the service_role key here.**
3. Typical workflow: Boards & universities > Classes/degrees/semesters (give a degree child semesters by choosing it as Parent) > Subjects > Chapters > Notes/PDFs > Questions > Quizzes > **Publish**. Use "Preview" on a chapter to see drafts. Editors can publish; only admins manage users and AI limits.

## Step 4: GitHub and the APK

1. Create a **private** repository on github.com. Install **Git for Windows**, then in the project folder:
   ```powershell
   git init
   git add -A
   git status        # make sure no .env file is listed
   git commit -m "Vidyasetu"
   git branch -M main
   git remote add origin https://github.com/YOUR-USER/YOUR-REPO.git
   git push -u origin main
   ```
2. In the repo: **Settings > Secrets and variables > Actions > New repository secret**. Add:
   * `SUPABASE_URL`, `SUPABASE_ANON_KEY` (public by design), and `BACKEND_URL` (your deployed backend, https).
   Without them the APK still builds but opens a screen saying it is not configured (no fake demo data).
3. **Actions** tab > **Build Android APK** > Run workflow (it also runs on every push). It takes roughly 10 to 20 minutes.
4. Open the finished run > **Artifacts** > download `vidyasetu-apk` > unzip. `app-debug.apk` is for testing; `app-release.apk` is also installable (signed with the debug key).
5. On the phone: open the APK, allow "install unknown apps" for your browser/Files app.

Other workflows: `backend-tests`, `admin-build`, `database-tests` run on pushes that touch those folders.

### Running the app locally instead (needs Flutter on a computer)
```powershell
cd mobile
flutter create --platforms=android --org com.example --project-name vidyasetu .
git checkout -- lib test pubspec.yaml analysis_options.yaml
flutter pub get
flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=... --dart-define=BACKEND_URL=...
```
Then add `<uses-permission android:name="android.permission.INTERNET"/>` to `android/app/src/main/AndroidManifest.xml` (CI does this automatically).

### Play Store signing (later)
Generate a keystore once (`keytool -genkey -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`), keep it **outside** the repo (`*.jks`, `key.properties` are git-ignored), follow Flutter's "Build and release an Android app" guide to reference it from `android/key.properties`, change the application id from `com.example.vidyasetu`, and build an app bundle (`flutter build appbundle`). To sign in CI, store the keystore base64 and passwords as GitHub secrets and write `key.properties` in an extra workflow step. Never commit keystores, passwords, API keys or the service-role key.

## Privacy and security summary
* Passwords handled only by Supabase Auth. Roles are not writable by users; sign-up always creates a `student`.
* Row Level Security on every table; the anonymous role has no access; storage buckets are private (signed URLs); uploads are limited by type and size in the bucket, in the admin UI (including file signature checks) and in the backend (re-validated, images re-encoded).
* Student photos are sent straight to the backend, processed in memory and **not stored**. Student PDFs are uploaded to a private per-user folder, and deleted when the student leaves the PDF screen (or taps "Remove my PDF now"). Storage objects can also be purged on a schedule from the Supabase dashboard.
* The AI history stores the confirmed question text and the solution (not the files). Students can delete it from Profile.
* Reports: students can report content or AI answers; staff review them under "Reports".

## Troubleshooting
* **APK build fails:** open the failed step in Actions, copy the last ~40 lines, send them to me. "Static analysis" = a code error; "Generate Android platform files" = Flutter version problem.
* **App says "not configured":** the three GitHub secrets were missing when that APK was built; add them and re-run.
* **Login works but home is empty:** nothing is published yet (admin > publish), or the seed was not run.
* **Quizzes / AI say "Could not reach the server":** `BACKEND_URL` is wrong, not https, or the backend is asleep (free hosts sleep).
* **"The AI solver is not configured":** set `AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL` on the backend.
* **OCR says unavailable:** Tesseract is not installed on the server (use the Dockerfile).
* **Admin shows "No access":** the account is not editor/admin (run `make_admin.sql`).
* **Sign-up e-mail never arrives:** Supabase's built-in mailer is rate-limited; turn off "Confirm email" for testing or configure SMTP.

## Feature checklist (honest status: "written" means code exists but is unverified by me unless it says tested)
| Area | Status |
|---|---|
| Courses, classes, semesters, subjects, chapters, topics from the database; English/Marathi; breadcrumb | Written |
| Student sign-up / sign-in / reset, profile, language, course preference | Written |
| Notes with LaTeX, formulas, images, chapter PDFs (signed URLs, in-app reader) | Written |
| Practice questions with verified solutions; "Ask AI" fallback | Written |
| Quizzes: MCQ, multi-select, true/false, numeric, short answer; timer, negative marking, shuffle, server grading, review, history, retake | Grading and quiz flow **tested** (Python, fake DB); Flutter UI written |
| Progress per chapter, quiz history, profile stats | Written |
| Search (courses, subjects, chapters, notes/formulas, questions) | SQL + app written |
| Bookmarks and saved AI answers | Written |
| Photo solver: camera/gallery, rotate, crop, preview, OCR, confirm/edit, solve | Backend OCR/validation **tested**; Flutter UI written |
| PDF solver: upload, page preview, per-page text/OCR, question picker, confirm, solve | Backend text/OCR **tested** on generated PDFs; Flutter UI written |
| AI solver: provider abstraction (Anthropic, OpenAI-compatible), structured steps, quotas, rate limits, math check, AI label | Parsing/limits/math check **tested**; live provider calls **never run** (no key) |
| Admin: hierarchy CRUD, reorder, publish/unpublish/archive, uploads with validation, questions + answers + solutions, quizzes + question bank, preview, users/roles/ban, reports, AI limits, stats | Written |
| RLS, roles/permissions, storage policies, seed, admin bootstrap | Written; verified only by the CI database test |
| CI: APK, backend tests, admin build, DB tests | Written |

## Known limitations
* Handwriting: Tesseract is weak at it; the app offers a vision-AI reader as a fallback (costs quota). Quality depends on your model.
* Blur detection thresholds were tuned only on synthetic images.
* Marathi UI text and sample Marathi names were written by an AI assistant and need native review.
* OCR of Marathi needs the Marathi Tesseract language data on the server.
* No automated end-to-end test of the Android UI exists; only unit/widget tests.
