"""Independent numeric check of an AI answer with SymPy.

The AI may return {"expression": "...", "expected": "..."} meaning "expression should equal expected".
We evaluate BOTH with a locked-down parser (character allow-list + name allow-list + no builtins),
never with eval() on raw text.
"""
from __future__ import annotations

import re

import sympy
from sympy.parsing.sympy_parser import convert_xor, parse_expr, standard_transformations

_ALLOWED_CHARS = re.compile(r"^[0-9A-Za-z_+\-*/^().,\s]+$")
_NAME = re.compile(r"[A-Za-z_][A-Za-z_0-9]*")
_SAFE_FUNCS = {
    "sqrt": sympy.sqrt, "sin": sympy.sin, "cos": sympy.cos, "tan": sympy.tan,
    "asin": sympy.asin, "acos": sympy.acos, "atan": sympy.atan,
    "log": sympy.log, "ln": sympy.log, "exp": sympy.exp, "abs": sympy.Abs, "Abs": sympy.Abs,
    "pi": sympy.pi, "E": sympy.E,
}
_ALLOWED_NAMES = set(_SAFE_FUNCS)
_GLOBALS = {"__builtins__": {}, "Integer": sympy.Integer, "Float": sympy.Float,
            "Rational": sympy.Rational, "Symbol": sympy.Symbol}
MAX_LEN = 200


class UnsafeExpression(ValueError):
    pass


def parse_safe(text: str):
    text = (text or "").strip()
    if not text or len(text) > MAX_LEN:
        raise UnsafeExpression("empty or too long")
    if not _ALLOWED_CHARS.match(text) or "__" in text or re.search(r"[A-Za-z_]\s*\.", text):
        raise UnsafeExpression("disallowed characters")
    for name in _NAME.findall(text):
        if name not in _ALLOWED_NAMES:
            raise UnsafeExpression(f"name not allowed: {name}")
    try:
        return parse_expr(text, local_dict=dict(_SAFE_FUNCS), global_dict=dict(_GLOBALS),
                          transformations=standard_transformations + (convert_xor,))
    except Exception as exc:  # SyntaxError, TypeError, SympifyError ...
        raise UnsafeExpression(f"cannot parse: {exc.__class__.__name__}") from exc


def verify(expression: str | None, expected: str | None, rel_tol: float = 1e-6) -> dict:
    """Returns {"status": "verified"|"mismatch"|"unavailable", "detail": str}."""
    if not expression or not expected:
        return {"status": "unavailable", "detail": "No machine-checkable expression was provided."}
    try:
        a, b = parse_safe(expression), parse_safe(expected)
        if a.has(sympy.zoo, sympy.nan, sympy.oo, -sympy.oo) or b.has(sympy.zoo, sympy.nan, sympy.oo, -sympy.oo):
            return {"status": "unavailable", "detail": "The expression is undefined or infinite."}
        if a.free_symbols or b.free_symbols:
            return {"status": "unavailable", "detail": "Expression contains unknown symbols."}
        av, bv = complex(a.evalf()), complex(b.evalf())
    except (UnsafeExpression, TypeError, ValueError, ZeroDivisionError, OverflowError):
        return {"status": "unavailable", "detail": "The expression could not be evaluated safely."}
    scale = max(abs(av), abs(bv), 1e-12)
    if abs(av - bv) <= rel_tol * scale + 1e-12:
        return {"status": "verified", "detail": "A computer-algebra check of the final value agrees."}
    return {"status": "mismatch", "detail": "A computer-algebra check disagrees with the stated answer. Treat it with extra caution."}
