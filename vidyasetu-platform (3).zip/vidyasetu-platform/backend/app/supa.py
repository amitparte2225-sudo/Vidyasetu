"""Thin Supabase REST/Storage client. Uses the SERVICE ROLE key, so it exists only on the server."""
from __future__ import annotations

import time
from typing import Any

import httpx

from .config import Settings


class SupabaseError(Exception):
    pass


class Supa:
    def __init__(self, s: Settings):
        self.s = s
        self._client = httpx.AsyncClient(timeout=20)
        self._tokens: dict[str, tuple[float, dict]] = {}

    async def aclose(self):
        await self._client.aclose()

    def _svc(self) -> dict:
        k = self.s.supabase_service_role_key
        return {"apikey": k, "Authorization": f"Bearer {k}"}

    async def user_from_token(self, token: str) -> dict | None:
        """Validates a student's access token with Supabase Auth (works for any signing-key type)."""
        hit = self._tokens.get(token)
        if hit and hit[0] > time.monotonic():
            return hit[1]
        try:
            r = await self._client.get(f"{self.s.supabase_url}/auth/v1/user",
                                       headers={"apikey": self.s.supabase_anon_key,
                                                "Authorization": f"Bearer {token}"})
        except httpx.HTTPError as exc:
            raise SupabaseError("auth service unreachable") from exc
        if r.status_code != 200:
            return None
        user = r.json()
        if not user.get("id"):
            return None
        if len(self._tokens) > 5000:
            self._tokens.clear()
        self._tokens[token] = (time.monotonic() + 60, user)
        return user

    async def _req(self, method: str, path: str, *, params=None, json=None, headers=None) -> httpx.Response:
        try:
            r = await self._client.request(method, f"{self.s.supabase_url}{path}", params=params, json=json,
                                           headers=headers)
        except httpx.HTTPError as exc:
            raise SupabaseError("database unreachable") from exc
        if r.status_code >= 400:
            raise SupabaseError(f"database error {r.status_code}")
        return r

    async def select(self, table: str, params: dict[str, str], user_token: str | None = None) -> list[dict]:
        """With user_token the query runs AS THE STUDENT, so Row Level Security applies."""
        headers = ({"apikey": self.s.supabase_anon_key, "Authorization": f"Bearer {user_token}"}
                   if user_token else self._svc())
        return (await self._req("GET", f"/rest/v1/{table}", params=params, headers=headers)).json()

    async def insert(self, table: str, row: dict | list[dict]) -> list[dict]:
        h = {**self._svc(), "Prefer": "return=representation", "Content-Type": "application/json"}
        return (await self._req("POST", f"/rest/v1/{table}", json=row, headers=h)).json()

    async def update(self, table: str, params: dict[str, str], patch: dict) -> list[dict]:
        h = {**self._svc(), "Prefer": "return=representation", "Content-Type": "application/json"}
        return (await self._req("PATCH", f"/rest/v1/{table}", params=params, json=patch, headers=h)).json()

    async def count(self, table: str, params: dict[str, str]) -> int:
        h = {**self._svc(), "Prefer": "count=exact", "Range": "0-0"}
        r = await self._req("GET", f"/rest/v1/{table}", params={**params, "select": "id"}, headers=h)
        total = r.headers.get("content-range", "*/0").split("/")[-1]
        return int(total) if total.isdigit() else 0

    async def download(self, bucket: str, path: str) -> bytes:
        r = await self._req("GET", f"/storage/v1/object/{bucket}/{path}", headers=self._svc())
        return r.content

    async def remove(self, bucket: str, path: str) -> None:
        await self._req("DELETE", f"/storage/v1/object/{bucket}/{path}", headers=self._svc())
