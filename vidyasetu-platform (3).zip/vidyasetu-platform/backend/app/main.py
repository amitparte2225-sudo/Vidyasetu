"""Vidyasetu API. Run:  uvicorn app.main:app --host 0.0.0.0 --port 8000"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from functools import lru_cache

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from . import mathcheck, ocr, pdf_tools, quiz_service, solution
from .ai.base import ProviderError
from .ai.factory import build_provider
from .config import get_settings
from .ratelimit import RateLimited, RateLimiter
from .schemas import PdfPageRequest, PdfPathRequest, SolveRequest, SubmitRequest
from .supa import Supa, SupabaseError
from .validation import UploadError, check_pdf, image_to_jpeg_bytes, load_image, safe_user_path

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("vidyasetu")  # we log metadata only: never questions, answers, images or tokens

DISCLAIMER = ("AI-generated solution. It can contain mistakes: check it against your textbook or teacher. "
              "It is not verified by an administrator.")
MAX_BODY = 30 * 1024 * 1024
limiter = RateLimiter()
RATE = {"solve": (6, 60), "ocr": (10, 60), "pdf": (30, 60), "quiz": (20, 60), "ip": (240, 60)}


@lru_cache
def get_supa() -> Supa:
    return Supa(get_settings())


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    if not s.supabase_configured:
        log.warning("Supabase is NOT configured: authenticated endpoints will answer 503.")
    if not s.ai_configured:
        log.warning("AI provider is NOT configured: solving will answer 503 until AI_* variables are set.")
    yield
    if get_supa.cache_info().currsize:
        await get_supa().aclose()


app = FastAPI(title="Vidyasetu API", version="1.0.0", lifespan=lifespan)
_origins = get_settings().allowed_origins
if _origins:
    app.add_middleware(CORSMiddleware, allow_origins=list(_origins), allow_methods=["GET", "POST"],
                       allow_headers=["Authorization", "Content-Type"])


@app.middleware("http")
async def guard(request: Request, call_next):
    cl = request.headers.get("content-length")
    if cl and cl.isdigit() and int(cl) > MAX_BODY:
        return JSONResponse({"detail": "Request body too large."}, status_code=413)
    try:
        limiter.check("ip:" + (request.client.host if request.client else "?"), *RATE["ip"])
    except RateLimited as e:
        return JSONResponse({"detail": "Too many requests."}, status_code=429, headers={"Retry-After": str(e.retry_after)})
    started = time.monotonic()
    response = await call_next(request)
    log.info("%s %s -> %s (%.0f ms)", request.method, request.url.path, response.status_code,
             (time.monotonic() - started) * 1000)
    return response


@app.exception_handler(SupabaseError)
async def _supa_err(_, exc: SupabaseError):
    log.warning("supabase: %s", exc)
    return JSONResponse({"detail": "The database is temporarily unavailable. Please try again."}, status_code=503)


@app.exception_handler(UploadError)
async def _upload_err(_, exc: UploadError):
    return JSONResponse({"detail": str(exc)}, status_code=422)


@app.exception_handler(quiz_service.QuizError)
async def _quiz_err(_, exc: quiz_service.QuizError):
    return JSONResponse({"detail": exc.message}, status_code=exc.status)


def rate(user_id: str, bucket: str):
    try:
        limiter.check(f"{bucket}:{user_id}", *RATE[bucket])
    except RateLimited as e:
        raise HTTPException(429, "You are going too fast. Please wait a moment.", headers={"Retry-After": str(e.retry_after)})


async def current_user(request: Request) -> dict:
    s = get_settings()
    if not s.supabase_configured:
        raise HTTPException(503, "The server is not connected to a database yet.")
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer ") or len(auth) < 20:
        raise HTTPException(401, "Please sign in.")
    token = auth[7:].strip()
    user = await get_supa().user_from_token(token)
    if not user:
        raise HTTPException(401, "Your session has expired. Please sign in again.")
    banned = await get_supa().select("profiles", {"id": f"eq.{user['id']}", "select": "is_banned"})
    if banned and banned[0]["is_banned"]:
        raise HTTPException(403, "This account has been suspended.")
    return {"id": user["id"], "token": token}


async def read_limited(file: UploadFile, max_bytes: int) -> bytes:
    data = await file.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise UploadError(f"The file is larger than {max_bytes // (1024 * 1024)} MB.")
    return data


async def get_limits(user_id: str) -> dict:
    rows = await get_supa().select("usage_limits", {"or": f"(user_id.is.null,user_id.eq.{user_id})", "select": "*"})
    mine = [r for r in rows if r["user_id"] == user_id] or [r for r in rows if r["user_id"] is None]
    if not mine:
        return {"daily_solver_requests": 15, "monthly_solver_requests": 200, "max_upload_mb": 15,
                "max_pdf_pages": 100, "max_question_chars": 3000}
    return mine[0]


async def usage_counts(user_id: str) -> tuple[int, int]:
    now = datetime.now(timezone.utc)
    day = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()
    sup = get_supa()
    base = {"user_id": f"eq.{user_id}", "status": "neq.error"}
    return (await sup.count("solver_requests", {**base, "created_at": f"gte.{day}"}),
            await sup.count("solver_requests", {**base, "created_at": f"gte.{month}"}))


async def enforce_quota(user_id: str, limits: dict) -> None:
    day, month = await usage_counts(user_id)
    if day >= limits["daily_solver_requests"]:
        raise HTTPException(429, "You have used today's AI solver limit. Please try again tomorrow.")
    if month >= limits["monthly_solver_requests"]:
        raise HTTPException(429, "You have used this month's AI solver limit.")


def provider_or_503():
    try:
        return build_provider(get_settings())
    except ProviderError as e:
        raise HTTPException(503, str(e))


# ------------------------------------------------------------------ basic
@app.get("/health")
async def health():
    s = get_settings()
    return {"status": "ok", "supabase_configured": s.supabase_configured, "ai_configured": s.ai_configured}


@app.get("/v1/me/limits")
async def my_limits(user=Depends(current_user)):
    limits = await get_limits(user["id"])
    day, month = await usage_counts(user["id"])
    return {"limits": limits, "used_today": day, "used_this_month": month, "ai_configured": get_settings().ai_configured}


# ------------------------------------------------------------------ solving
async def run_solve(user: dict, req: SolveRequest, image_jpeg: bytes | None) -> dict:
    limits = await get_limits(user["id"])
    question = req.question.strip()
    if len(question) > limits["max_question_chars"]:
        raise HTTPException(422, f"The question is too long (limit {limits['max_question_chars']} characters). Select just one question.")
    provider = provider_or_503()
    await enforce_quota(user["id"], limits)
    sup = get_supa()
    row = (await sup.insert("solver_requests", {
        "user_id": user["id"], "kind": "solve", "source": req.source, "level_hint": req.level,
        "subject_hint": req.subject, "question_text": question, "status": "pending"}))[0]
    try:
        res = await provider.complete(system=solution.build_system_prompt(req.level, req.language),
                                      user_text=solution.build_user_prompt(question, req.subject, image_jpeg is not None),
                                      image_jpeg=image_jpeg, max_tokens=get_settings().ai_max_output_tokens)
        sol = solution.normalize(solution.extract_json(res.text))
    except ProviderError as e:
        await sup.update("solver_requests", {"id": f"eq.{row['id']}"}, {"status": "error", "error": "provider"})
        raise HTTPException(502, str(e))
    except (ValueError, json.JSONDecodeError):
        await sup.update("solver_requests", {"id": f"eq.{row['id']}"}, {"status": "error", "error": "unparseable"})
        raise HTTPException(502, "The AI answer could not be understood. Please try again or rephrase the question.")
    vin = sol.pop("verification_input", None)
    sol["verification"] = mathcheck.verify(vin["expression"], vin["expected"]) if vin else mathcheck.verify(None, None)
    await sup.update("solver_requests", {"id": f"eq.{row['id']}"}, {
        "status": "ok", "solution": sol, "provider": provider.name, "model": res.model,
        "tokens_in": res.tokens_in, "tokens_out": res.tokens_out})
    return {"request_id": row["id"], "origin": "ai_generated", "disclaimer": DISCLAIMER, "solution": sol}


@app.post("/v1/solve")
async def solve_text(req: SolveRequest, user=Depends(current_user)):
    rate(user["id"], "solve")
    return await run_solve(user, req, None)


@app.post("/v1/solve/image")
async def solve_image(file: UploadFile = File(...), question: str = Form(...), level: str = Form("school"),
                      subject: str | None = Form(None), language: str = Form("en"), user=Depends(current_user)):
    """Confirmed question text plus the picture (so the AI can also read diagrams)."""
    rate(user["id"], "solve")
    limits = await get_limits(user["id"])
    img = load_image(await read_limited(file, limits["max_upload_mb"] * 1024 * 1024), limits["max_upload_mb"] * 1024 * 1024,
                     get_settings().max_image_side)
    try:
        req = SolveRequest(question=question, level=level, subject=subject, language=language, source="image")
    except ValueError:
        raise HTTPException(422, "Invalid question or options.")
    return await run_solve(user, req, image_to_jpeg_bytes(img))


# ------------------------------------------------------------------ OCR
@app.post("/v1/ocr/image")
async def ocr_image(file: UploadFile = File(...), engine: str = Form("auto"), user=Depends(current_user)):
    """Extract the question text. The student then confirms/edits it before solving."""
    rate(user["id"], "ocr")
    if engine not in ("auto", "tesseract", "vision"):
        raise HTTPException(422, "engine must be auto, tesseract or vision")
    s, limits = get_settings(), await get_limits(user["id"])
    max_bytes = limits["max_upload_mb"] * 1024 * 1024
    img = load_image(await read_limited(file, max_bytes), max_bytes, s.max_image_side)
    local = None
    if engine in ("auto", "tesseract"):
        try:
            local = await asyncio.to_thread(ocr.ocr_image, img, s.ocr_langs)
        except ocr.OcrUnavailable as e:
            log.warning("OCR unavailable: %s", e)
            if engine == "tesseract":
                raise HTTPException(503, "Text recognition is not available on the server.")
    good_enough = local and local.confidence >= 55 and len(local.text) >= 8
    if good_enough or engine == "tesseract":
        if local and local.sharpness < 12 and len(local.text) < 8:
            raise HTTPException(422, "The photo looks blurry or empty. Retake it in good light, holding the camera steady.")
        return {"text": local.text if local else "", "confidence": local.confidence if local else 0,
                "engine": "tesseract", "warnings": [] if good_enough else ["Low confidence: please check the text."]}
    provider = provider_or_503()  # fall back to a vision model (handwriting, poor print)
    await enforce_quota(user["id"], limits)
    sup = get_supa()
    row = (await sup.insert("solver_requests", {"user_id": user["id"], "kind": "ocr", "source": "image",
                                                "question_text": "[ocr]", "status": "pending"}))[0]
    try:
        res = await provider.complete(system=solution.TRANSCRIBE_SYSTEM, user_text="Transcribe the question.",
                                      image_jpeg=image_to_jpeg_bytes(img), max_tokens=700)
    except ProviderError as e:
        await sup.update("solver_requests", {"id": f"eq.{row['id']}"}, {"status": "error", "error": "provider"})
        raise HTTPException(502, str(e))
    await sup.update("solver_requests", {"id": f"eq.{row['id']}"}, {"status": "ok", "provider": provider.name,
                                                                    "model": res.model, "tokens_in": res.tokens_in,
                                                                    "tokens_out": res.tokens_out})
    text = res.text.strip()
    if not text or text.upper().startswith("UNREADABLE"):
        raise HTTPException(422, "The question could not be read from this photo. Try a sharper, closer, well-lit photo.")
    return {"text": text[:limits["max_question_chars"]], "confidence": None, "engine": "vision",
            "warnings": ["Please check the text, especially numbers and symbols."]}


# ------------------------------------------------------------------ PDF (file is first uploaded by the app to storage)
_pdf_cache: dict[str, tuple[float, bytes]] = {}


async def load_pdf(user: dict, path: str) -> tuple[bytes, int, str]:
    path = safe_user_path(user["id"], path)
    limits = await get_limits(user["id"])
    hit = _pdf_cache.get(path)
    if hit and hit[0] > time.monotonic():
        data = hit[1]
    else:
        data = await get_supa().download("user-uploads", path)
        if len(_pdf_cache) >= 6:
            _pdf_cache.clear()
        _pdf_cache[path] = (time.monotonic() + 300, data)
    pages = check_pdf(data, limits["max_upload_mb"] * 1024 * 1024, limits["max_pdf_pages"])
    return data, pages, path


@app.post("/v1/pdf/inspect")
async def pdf_inspect(req: PdfPathRequest, user=Depends(current_user)):
    rate(user["id"], "pdf")
    _, pages, _ = await load_pdf(user, req.path)
    return {"page_count": pages}


@app.post("/v1/pdf/page")
async def pdf_page(req: PdfPageRequest, user=Depends(current_user)):
    """Text of ONE page (text layer, or OCR for scanned pages) split into candidate questions."""
    rate(user["id"], "pdf")
    data, pages, _ = await load_pdf(user, req.path)
    if req.page >= pages:
        raise HTTPException(422, "That page does not exist.")
    try:
        out = await asyncio.wait_for(asyncio.to_thread(pdf_tools.extract_page, data, req.page,
                                                       get_settings().ocr_langs, req.ocr), timeout=90)
    except ocr.OcrUnavailable:
        raise HTTPException(503, "This page is scanned and text recognition is not available on the server.")
    except asyncio.TimeoutError:
        raise HTTPException(504, "This page took too long to process.")
    if not out["text"]:
        raise HTTPException(422, "No text could be found on this page.")
    return {"page": req.page, "method": out["method"], "confidence": out["confidence"], "text": out["text"],
            "questions": pdf_tools.split_questions(out["text"])}


@app.post("/v1/pdf/delete")
async def pdf_delete(req: PdfPathRequest, user=Depends(current_user)):
    path = safe_user_path(user["id"], req.path)
    _pdf_cache.pop(path, None)
    await get_supa().remove("user-uploads", path)
    return {"deleted": True}


# ------------------------------------------------------------------ quizzes
@app.post("/v1/quizzes/{quiz_id}/start")
async def quiz_start(quiz_id: str, user=Depends(current_user)):
    rate(user["id"], "quiz")
    return await quiz_service.start_attempt(get_supa(), user["id"], user["token"], quiz_id)


@app.post("/v1/attempts/{attempt_id}/submit")
async def quiz_submit(attempt_id: str, body: SubmitRequest, user=Depends(current_user)):
    rate(user["id"], "quiz")
    return await quiz_service.submit_attempt(get_supa(), user["id"], attempt_id, body.responses)


@app.get("/v1/attempts/{attempt_id}/review")
async def quiz_review(attempt_id: str, user=Depends(current_user)):
    rate(user["id"], "quiz")
    return await quiz_service.review_attempt(get_supa(), user["id"], attempt_id)
