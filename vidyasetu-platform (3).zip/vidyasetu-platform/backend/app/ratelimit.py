"""Sliding-window rate limiter kept in process memory.
NOTE: with several server instances each has its own counters; the database daily/monthly
quotas (usage_limits) are the authoritative limit across instances."""
from __future__ import annotations

import time
from collections import defaultdict, deque


class RateLimited(Exception):
    def __init__(self, retry_after: int):
        super().__init__("rate limited")
        self.retry_after = retry_after


class RateLimiter:
    def __init__(self, clock=time.monotonic):
        self._hits: dict[str, deque] = defaultdict(deque)
        self._clock = clock

    def check(self, key: str, limit: int, window_seconds: float) -> None:
        now = self._clock()
        q = self._hits[key]
        while q and now - q[0] >= window_seconds:
            q.popleft()
        if len(q) >= limit:
            raise RateLimited(max(1, int(window_seconds - (now - q[0])) + 1))
        q.append(now)
        if len(self._hits) > 50_000:  # memory guard
            for k in [k for k, v in self._hits.items() if not v][:10_000]:
                self._hits.pop(k, None)
