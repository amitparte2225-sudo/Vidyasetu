"""Local OCR with Tesseract. Needs the 'tesseract-ocr' system package (+ language packs, e.g. 'mar')."""
from __future__ import annotations

import re
from dataclasses import dataclass

from PIL import Image, ImageFilter, ImageOps, ImageStat

try:
    import pytesseract
    from pytesseract import Output, TesseractError, TesseractNotFoundError
except ImportError:  # pragma: no cover
    pytesseract = None


class OcrUnavailable(RuntimeError):
    pass


@dataclass
class OcrResult:
    text: str
    confidence: float      # 0-100, mean word confidence
    sharpness: float       # edge variance; very low = blurry photo


def sharpness_score(img: Image.Image) -> float:
    lap = ImageFilter.Kernel((3, 3), (0, 1, 0, 1, -4, 1, 0, 1, 0), scale=1, offset=128)
    g = img.convert("L").filter(lap)
    g = g.crop((2, 2, max(g.width - 2, 3), max(g.height - 2, 3)))  # PIL leaves border pixels unfiltered
    return float(ImageStat.Stat(g).var[0])


def clean_text(text: str) -> str:
    text = text.replace("\x0c", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def ocr_image(img: Image.Image, langs: str = "eng") -> OcrResult:
    if pytesseract is None:
        raise OcrUnavailable("pytesseract is not installed")
    gray = ImageOps.autocontrast(img.convert("L"))
    if min(gray.size) < 700:  # small photos OCR better when enlarged
        scale = 700 / min(gray.size)
        gray = gray.resize((int(gray.width * scale), int(gray.height * scale)))
    try:
        data = pytesseract.image_to_data(gray, lang=langs, config="--psm 6", output_type=Output.DICT)
    except TesseractNotFoundError as exc:
        raise OcrUnavailable("Tesseract is not installed on the server") from exc
    except TesseractError as exc:
        raise OcrUnavailable(f"Tesseract failed ({str(exc)[:80]})") from exc
    words, confs, last_line, lines, cur = [], [], None, [], []
    for txt, conf, blk, par, line in zip(data["text"], data["conf"], data["block_num"],
                                         data["par_num"], data["line_num"]):
        if not str(txt).strip():
            continue
        key = (blk, par, line)
        if last_line is not None and key != last_line:
            lines.append(" ".join(cur)); cur = []
        cur.append(str(txt)); last_line = key
        try:
            c = float(conf)
        except (TypeError, ValueError):
            c = -1
        if c >= 0:
            confs.append(c)
        words.append(txt)
    if cur:
        lines.append(" ".join(cur))
    mean_conf = sum(confs) / len(confs) if confs else 0.0
    return OcrResult(clean_text("\n".join(lines)), round(mean_conf, 1), round(sharpness_score(img), 1))
