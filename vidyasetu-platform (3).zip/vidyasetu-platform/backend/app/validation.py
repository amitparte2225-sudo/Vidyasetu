"""Validation of untrusted uploads. Never trust the file name or the client's content type."""
from __future__ import annotations

import io

from PIL import Image, ImageOps, UnidentifiedImageError
from pypdf import PdfReader
from pypdf.errors import PyPdfError

Image.MAX_IMAGE_PIXELS = 40_000_000  # decompression-bomb guard (Pillow raises above 2x this)
ALLOWED_IMAGE_FORMATS = {"JPEG", "PNG", "WEBP"}


class UploadError(ValueError):
    """Message is safe to show to the student."""


def load_image(data: bytes, max_bytes: int, max_side: int = 1600) -> Image.Image:
    if not data:
        raise UploadError("The image is empty.")
    if len(data) > max_bytes:
        raise UploadError(f"The image is larger than {max_bytes // (1024 * 1024)} MB.")
    try:
        probe = Image.open(io.BytesIO(data))
        fmt = probe.format
        probe.verify()
        img = Image.open(io.BytesIO(data))
        img.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, SyntaxError):
        raise UploadError("This file is not a readable JPEG, PNG or WebP image.")
    if fmt not in ALLOWED_IMAGE_FORMATS:
        raise UploadError("Only JPEG, PNG and WebP images are accepted.")
    img = ImageOps.exif_transpose(img).convert("RGB")
    if min(img.size) < 40:
        raise UploadError("The image is too small to read.")
    if max(img.size) > max_side:
        img.thumbnail((max_side, max_side))  # cost control: never send huge images to the AI
    return img


def image_to_jpeg_bytes(img: Image.Image, quality: int = 88) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=quality)
    return buf.getvalue()


def check_pdf(data: bytes, max_bytes: int, max_pages: int) -> int:
    """Returns the page count or raises UploadError."""
    if len(data) > max_bytes:
        raise UploadError(f"The PDF is larger than {max_bytes // (1024 * 1024)} MB.")
    if not data.startswith(b"%PDF"):
        raise UploadError("This file is not a PDF.")
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            raise UploadError("Password-protected PDFs are not supported.")
        pages = len(reader.pages)
    except UploadError:
        raise
    except (PyPdfError, ValueError, OSError, KeyError, RecursionError):
        raise UploadError("This PDF could not be read. It may be damaged.")
    if pages < 1:
        raise UploadError("The PDF has no pages.")
    if pages > max_pages:
        raise UploadError(f"The PDF has {pages} pages; the limit is {max_pages}.")
    return pages


def safe_user_path(user_id: str, path: str) -> str:
    """A student may only touch objects in their own folder: '<user_id>/<file>'."""
    parts = path.split("/")
    if (len(parts) != 2 or parts[0] != user_id or not parts[1] or ".." in path
            or path.startswith("/") or "\\" in path or len(path) > 200):
        raise UploadError("Invalid file path.")
    return path
