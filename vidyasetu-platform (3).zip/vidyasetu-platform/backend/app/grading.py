"""Server-side quiz grading. Pure functions, no I/O, fully unit-tested."""
from __future__ import annotations

import math
import re
from typing import Any

MCQ_SINGLE, MCQ_MULTI, TRUE_FALSE, NUMERIC, SHORT = (
    "mcq_single", "mcq_multi", "true_false", "numeric", "short_answer")
QUESTION_TYPES = {MCQ_SINGLE, MCQ_MULTI, TRUE_FALSE, NUMERIC, SHORT}


def _norm_text(v: Any) -> str:
    s = re.sub(r"\s+", " ", str(v)).strip().casefold()
    return s.rstrip(".!?, ")


def _to_float(v: Any) -> float | None:
    if isinstance(v, bool):
        return None
    try:
        f = float(str(v).strip().replace(",", ""))
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _to_bool(v: Any) -> bool | None:
    if isinstance(v, bool):
        return v
    if isinstance(v, str) and v.strip().lower() in ("true", "false"):
        return v.strip().lower() == "true"
    return None


def is_unanswered(response: Any) -> bool:
    if response is None:
        return True
    if isinstance(response, str) and not response.strip():
        return True
    if isinstance(response, (list, tuple, set)) and len(response) == 0:
        return True
    return False


def is_correct(qtype: str, response: Any, correct: list, tolerance: float = 0.0) -> bool:
    """Whether a non-empty response is right. Multiple-select needs the exact set (no partial credit)."""
    if qtype not in QUESTION_TYPES:
        raise ValueError(f"unknown question type {qtype!r}")
    if qtype == MCQ_SINGLE:
        if isinstance(response, (list, tuple)):
            if len(response) != 1:
                return False
            response = response[0]
        return str(response) in {str(c) for c in correct}
    if qtype == MCQ_MULTI:
        if not isinstance(response, (list, tuple, set)):
            return False
        return {str(r) for r in response} == {str(c) for c in correct}
    if qtype == TRUE_FALSE:
        r, c = _to_bool(response), _to_bool(correct[0])
        return r is not None and c is not None and r == c
    if qtype == NUMERIC:
        r, c = _to_float(response), _to_float(correct[0])
        if r is None or c is None:
            return False
        if tolerance > 0:
            return abs(r - c) <= tolerance
        return math.isclose(r, c, rel_tol=1e-9, abs_tol=1e-12)
    accepted = {_norm_text(c) for c in correct}
    return _norm_text(response) in accepted


def grade_question(qtype: str, response: Any, correct: list, tolerance: float,
                   marks: float, negative_fraction: float) -> tuple[bool | None, float]:
    """Returns (is_correct, awarded). is_correct is None when unanswered (no penalty)."""
    if is_unanswered(response):
        return None, 0.0
    if is_correct(qtype, response, correct, tolerance):
        return True, round(float(marks), 2)
    return False, round(-float(marks) * float(negative_fraction), 2)


def grade_attempt(questions: list[dict], responses: dict[str, Any], negative_fraction: float) -> dict:
    """questions: [{id, type, marks, correct, tolerance}]  responses: {question_id: value}."""
    results, total, maximum = [], 0.0, 0.0
    correct_n = wrong_n = blank_n = 0
    for q in questions:
        marks = float(q["marks"])
        maximum += marks
        ok, awarded = grade_question(q["type"], responses.get(q["id"]), q["correct"],
                                     float(q.get("tolerance") or 0), marks, negative_fraction)
        if ok is None:
            blank_n += 1
        elif ok:
            correct_n += 1
        else:
            wrong_n += 1
        total += awarded
        results.append({"question_id": q["id"], "is_correct": ok, "awarded": awarded})
    score = round(max(total, 0.0), 2)  # a quiz never shows a negative total
    pct = round(100.0 * score / maximum, 2) if maximum > 0 else 0.0
    return {"results": results, "score": score, "max_score": round(maximum, 2), "percentage": pct,
            "correct_count": correct_n, "wrong_count": wrong_n, "unanswered_count": blank_n}
