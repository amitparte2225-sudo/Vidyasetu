"""Quiz start / submit / review. Answers never leave the server until an attempt is submitted."""
from __future__ import annotations

import random
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from .grading import QUESTION_TYPES, grade_attempt

GRACE_SECONDS = 30


class QuizError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status, self.message = status, message


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse(ts: str) -> datetime:
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def _in(ids: list[str]) -> str:
    for i in ids:
        uuid.UUID(i)  # raises ValueError on anything that is not a UUID (prevents filter injection)
    return "in.(" + ",".join(ids) + ")"


def clean_response(v: Any) -> Any:
    """Accept only simple JSON values of bounded size."""
    if v is None or isinstance(v, (bool, int, float)):
        return v
    if isinstance(v, str):
        return v[:500]
    if isinstance(v, list) and len(v) <= 20 and all(isinstance(x, (str, int, float, bool)) for x in v):
        return [x[:100] if isinstance(x, str) else x for x in v]
    raise QuizError(422, "Invalid answer format.")


async def _material(supa, quiz_id: str, qids: list[str] | None = None, with_answers: bool = False) -> list[dict]:
    links = await supa.select("quiz_questions", {"quiz_id": f"eq.{quiz_id}", "select": "question_id,display_order,marks_override",
                                                 "order": "display_order"})
    if qids is not None:
        links = [l for l in links if l["question_id"] in set(qids)]
    ids = [l["question_id"] for l in links]
    if not ids:
        return []
    qs = {q["id"]: q for q in await supa.select(
        "questions", {"id": _in(ids), "status": "eq.published", "select": "id,type,prompt,options,marks"})}
    answers = {}
    if with_answers:
        answers = {a["question_id"]: a for a in await supa.select(
            "question_answers", {"question_id": _in(ids), "select": "question_id,correct,numeric_tolerance,explanation"})}
    out = []
    for l in links:
        q = qs.get(l["question_id"])
        if not q or q["type"] not in QUESTION_TYPES:
            continue
        item = {"id": q["id"], "type": q["type"], "prompt": q["prompt"], "options": q["options"],
                "marks": float(l["marks_override"] if l["marks_override"] is not None else q["marks"])}
        if with_answers:
            a = answers.get(q["id"])
            if not a:
                continue  # a question without an answer key can never be graded; skip it
            item.update(correct=a["correct"], tolerance=float(a["numeric_tolerance"] or 0),
                        explanation=a["explanation"])
        out.append(item)
    return out


async def start_attempt(supa, user_id: str, user_token: str, quiz_id: str) -> dict:
    try:
        uuid.UUID(quiz_id)
    except ValueError:
        raise QuizError(404, "Quiz not found.")
    # Run AS THE STUDENT: row-level security decides whether this quiz is visible/published.
    quiz = await supa.select("quizzes", {"id": f"eq.{quiz_id}", "select": "id,title,time_limit_seconds,negative_marking,shuffle_questions,pass_percentage"},
                             user_token=user_token)
    if not quiz:
        raise QuizError(404, "Quiz not found.")
    quiz = quiz[0]
    questions = await _material(supa, quiz_id, with_answers=True)
    if not questions:
        raise QuizError(409, "This quiz has no gradable questions yet.")
    if quiz["shuffle_questions"]:
        random.shuffle(questions)
    await supa.update("quiz_attempts", {"user_id": f"eq.{user_id}", "quiz_id": f"eq.{quiz_id}", "status": "eq.in_progress"},
                      {"status": "expired"})
    limit = quiz["time_limit_seconds"]
    expires = (_now() + timedelta(seconds=limit)).isoformat() if limit else None
    row = (await supa.insert("quiz_attempts", {"user_id": user_id, "quiz_id": quiz_id, "expires_at": expires,
                                               "question_order": [q["id"] for q in questions]}))[0]
    public = [{"id": q["id"], "type": q["type"], "prompt": q["prompt"], "options": q["options"], "marks": q["marks"]}
              for q in questions]
    return {"attempt_id": row["id"], "title": quiz["title"], "time_limit_seconds": limit, "expires_at": expires,
            "negative_marking": float(quiz["negative_marking"]), "questions": public}


def _review(material: list[dict], graded: list[dict], responses: dict) -> list[dict]:
    by_q = {r["question_id"]: r for r in graded}
    return [{"question_id": m["id"], "type": m["type"], "prompt": m["prompt"], "options": m["options"],
             "marks": m["marks"], "response": responses.get(m["id"]), "is_correct": by_q[m["id"]]["is_correct"],
             "awarded": by_q[m["id"]]["awarded"], "correct": m["correct"], "explanation": m["explanation"]}
            for m in material]


async def submit_attempt(supa, user_id: str, attempt_id: str, raw_responses: dict) -> dict:
    try:
        uuid.UUID(attempt_id)
    except ValueError:
        raise QuizError(404, "Attempt not found.")
    rows = await supa.select("quiz_attempts", {"id": f"eq.{attempt_id}", "user_id": f"eq.{user_id}", "select": "*"})
    if not rows:
        raise QuizError(404, "Attempt not found.")
    att = rows[0]
    if att["status"] != "in_progress":
        raise QuizError(409, "This attempt was already submitted or has expired.")
    if att["expires_at"] and _now() > _parse(att["expires_at"]) + timedelta(seconds=GRACE_SECONDS):
        await supa.update("quiz_attempts", {"id": f"eq.{attempt_id}"}, {"status": "expired"})
        raise QuizError(409, "Time is up. This attempt has expired.")
    order = att["question_order"] or []
    responses = {k: clean_response(v) for k, v in raw_responses.items() if k in set(order)}
    material = await _material(supa, att["quiz_id"], qids=order, with_answers=True)
    material.sort(key=lambda m: order.index(m["id"]))
    quiz = (await supa.select("quizzes", {"id": f"eq.{att['quiz_id']}", "select": "negative_marking,pass_percentage"}))[0]
    result = grade_attempt(material, responses, float(quiz["negative_marking"]))
    await supa.insert("quiz_responses", [
        {"attempt_id": attempt_id, "question_id": r["question_id"], "response": responses.get(r["question_id"]),
         "is_correct": r["is_correct"], "awarded": r["awarded"]} for r in result["results"]])
    await supa.update("quiz_attempts", {"id": f"eq.{attempt_id}"}, {
        "status": "submitted", "submitted_at": _now().isoformat(), "score": result["score"],
        "max_score": result["max_score"], "percentage": result["percentage"], "correct_count": result["correct_count"],
        "wrong_count": result["wrong_count"], "unanswered_count": result["unanswered_count"]})
    return {"attempt_id": attempt_id, "score": result["score"], "max_score": result["max_score"],
            "percentage": result["percentage"], "passed": result["percentage"] >= float(quiz["pass_percentage"]),
            "correct_count": result["correct_count"], "wrong_count": result["wrong_count"],
            "unanswered_count": result["unanswered_count"],
            "review": _review(material, result["results"], responses)}


async def review_attempt(supa, user_id: str, attempt_id: str) -> dict:
    try:
        uuid.UUID(attempt_id)
    except ValueError:
        raise QuizError(404, "Attempt not found.")
    rows = await supa.select("quiz_attempts", {"id": f"eq.{attempt_id}", "user_id": f"eq.{user_id}", "select": "*"})
    if not rows or rows[0]["status"] != "submitted":
        raise QuizError(404, "Attempt not found.")
    att = rows[0]
    order = att["question_order"] or []
    material = await _material(supa, att["quiz_id"], qids=order, with_answers=True)
    material.sort(key=lambda m: order.index(m["id"]))
    saved = {r["question_id"]: r for r in await supa.select(
        "quiz_responses", {"attempt_id": f"eq.{attempt_id}", "select": "question_id,response,is_correct,awarded"})}
    graded = [{"question_id": m["id"], "is_correct": saved.get(m["id"], {}).get("is_correct"),
               "awarded": float(saved.get(m["id"], {}).get("awarded") or 0)} for m in material]
    responses = {k: v["response"] for k, v in saved.items()}
    return {"attempt_id": attempt_id, "score": float(att["score"] or 0), "max_score": float(att["max_score"] or 0),
            "percentage": float(att["percentage"] or 0), "correct_count": att["correct_count"],
            "wrong_count": att["wrong_count"], "unanswered_count": att["unanswered_count"],
            "review": _review(material, graded, responses)}
