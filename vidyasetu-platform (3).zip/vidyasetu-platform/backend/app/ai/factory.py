from __future__ import annotations

from ..config import Settings
from .base import AIProvider, ProviderError
from .http_providers import AnthropicProvider, OpenAICompatibleProvider


def build_provider(s: Settings) -> AIProvider:
    if not s.ai_configured:
        raise ProviderError("The AI solver is not configured on the server yet.")
    if s.ai_provider == "anthropic":
        return AnthropicProvider(s.ai_api_key, s.ai_model, s.ai_base_url, s.ai_timeout_seconds)
    if s.ai_provider in ("openai", "openai_compatible"):
        return OpenAICompatibleProvider(s.ai_api_key, s.ai_model, s.ai_base_url, s.ai_timeout_seconds)
    raise ProviderError(f"Unknown AI_PROVIDER {s.ai_provider!r}. Use 'anthropic' or 'openai'.")
