from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


class ProviderError(Exception):
    """message is safe to show to students; details stay in server logs."""


@dataclass
class AIResult:
    text: str
    tokens_in: int | None
    tokens_out: int | None
    model: str


class AIProvider(ABC):
    """Implement this to add a new AI vendor. Nothing else in the app changes."""
    name: str = "base"

    @abstractmethod
    async def complete(self, *, system: str, user_text: str, image_jpeg: bytes | None,
                       max_tokens: int) -> AIResult: ...
