from __future__ import annotations

import asyncio
import base64
import logging

import httpx

from .base import AIProvider, AIResult, ProviderError

log = logging.getLogger("vidyasetu.ai")


async def _post_with_retry(client: httpx.AsyncClient, url: str, headers: dict, body: dict) -> dict:
    last = "unknown"
    for attempt in range(2):
        try:
            r = await client.post(url, headers=headers, json=body)
        except httpx.TimeoutException:
            last = "timeout"
        except httpx.HTTPError as exc:
            last = exc.__class__.__name__
        else:
            if r.status_code == 200:
                return r.json()
            last = f"http {r.status_code}"
            if r.status_code in (400, 401, 403, 404):
                break  # retrying will not help
            if r.status_code == 429 or r.status_code >= 500:
                await asyncio.sleep(1.5 * (attempt + 1))
                continue
            break
        await asyncio.sleep(1.0)
    log.warning("AI provider call failed: %s", last)  # never log prompts or keys
    if last == "http 401" or last == "http 403":
        raise ProviderError("The AI service rejected the server's credentials. Please tell the administrator.")
    if last == "http 429":
        raise ProviderError("The AI service is busy. Please try again in a minute.")
    raise ProviderError("The AI service did not respond. Please try again.")


class AnthropicProvider(AIProvider):
    name = "anthropic"

    def __init__(self, api_key: str, model: str, base_url: str = "", timeout: int = 60):
        self.api_key, self.model = api_key, model
        self.url = (base_url or "https://api.anthropic.com") + "/v1/messages"
        self.timeout = timeout

    async def complete(self, *, system, user_text, image_jpeg, max_tokens) -> AIResult:
        content: list[dict] = []
        if image_jpeg:
            content.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                                        "data": base64.b64encode(image_jpeg).decode()}})
        content.append({"type": "text", "text": user_text})
        body = {"model": self.model, "max_tokens": max_tokens, "system": system,
                "messages": [{"role": "user", "content": content}]}
        headers = {"x-api-key": self.api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            data = await _post_with_retry(c, self.url, headers, body)
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        usage = data.get("usage") or {}
        return AIResult(text, usage.get("input_tokens"), usage.get("output_tokens"), self.model)


class OpenAICompatibleProvider(AIProvider):
    """Works with OpenAI and any server exposing /chat/completions with image support."""
    name = "openai"

    def __init__(self, api_key: str, model: str, base_url: str = "", timeout: int = 60):
        self.api_key, self.model = api_key, model
        self.url = (base_url or "https://api.openai.com/v1") + "/chat/completions"
        self.timeout = timeout

    async def complete(self, *, system, user_text, image_jpeg, max_tokens) -> AIResult:
        parts: list[dict] = [{"type": "text", "text": user_text}]
        if image_jpeg:
            b64 = base64.b64encode(image_jpeg).decode()
            parts.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
        body = {"model": self.model, "max_tokens": max_tokens,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": parts}]}
        headers = {"Authorization": f"Bearer {self.api_key}", "content-type": "application/json"}
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            data = await _post_with_retry(c, self.url, headers, body)
        try:
            text = data["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, TypeError):
            raise ProviderError("The AI service returned an unexpected response.")
        usage = data.get("usage") or {}
        return AIResult(text, usage.get("prompt_tokens"), usage.get("completion_tokens"), self.model)
