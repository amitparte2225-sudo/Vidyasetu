"""Settings come ONLY from environment variables. Nothing secret is stored in code."""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    supabase_url: str
    supabase_anon_key: str
    supabase_service_role_key: str
    ai_provider: str          # "anthropic" or "openai" (any OpenAI-compatible endpoint)
    ai_api_key: str
    ai_model: str
    ai_base_url: str
    ai_max_output_tokens: int
    ai_timeout_seconds: int
    ocr_langs: str
    max_image_side: int
    allowed_origins: tuple[str, ...]

    @property
    def supabase_configured(self) -> bool:
        return bool(self.supabase_url and self.supabase_anon_key and self.supabase_service_role_key)

    @property
    def ai_configured(self) -> bool:
        return bool(self.ai_provider and self.ai_api_key and self.ai_model)

    @staticmethod
    def from_env() -> "Settings":
        e = os.environ.get
        origins = tuple(o.strip() for o in e("ALLOWED_ORIGINS", "").split(",") if o.strip())
        return Settings(
            supabase_url=e("SUPABASE_URL", "").rstrip("/"),
            supabase_anon_key=e("SUPABASE_ANON_KEY", ""),
            supabase_service_role_key=e("SUPABASE_SERVICE_ROLE_KEY", ""),
            ai_provider=e("AI_PROVIDER", "").lower(),
            ai_api_key=e("AI_API_KEY", ""),
            ai_model=e("AI_MODEL", ""),
            ai_base_url=e("AI_BASE_URL", "").rstrip("/"),
            ai_max_output_tokens=_int("AI_MAX_OUTPUT_TOKENS", 1800),
            ai_timeout_seconds=_int("AI_TIMEOUT_SECONDS", 60),
            ocr_langs=e("OCR_LANGS", "eng"),
            max_image_side=_int("MAX_IMAGE_SIDE", 1600),
            allowed_origins=origins,
        )


@lru_cache
def get_settings() -> Settings:
    return Settings.from_env()
