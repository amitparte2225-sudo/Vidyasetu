from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

Level = Literal["school", "higher_secondary", "bsc", "engineering"]
Language = Literal["en", "mr"]
Source = Literal["text", "image", "pdf"]


class SolveRequest(BaseModel):
    question: str = Field(min_length=3, max_length=20000)
    level: Level = "school"
    subject: str | None = Field(default=None, max_length=40)
    language: Language = "en"
    source: Source = "text"


class PdfPathRequest(BaseModel):
    path: str = Field(min_length=3, max_length=200)


class PdfPageRequest(PdfPathRequest):
    page: int = Field(ge=0, le=2000)
    ocr: bool = True


class SubmitRequest(BaseModel):
    responses: dict[str, Any] = Field(default_factory=dict, max_length=200)
