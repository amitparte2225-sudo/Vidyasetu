"""PDF text extraction (text layer first, OCR only for scanned pages), one page at a time."""
from __future__ import annotations

import io
import re

import pypdfium2 as pdfium
from pypdf import PdfReader

from . import ocr
from .validation import UploadError

MIN_TEXT_CHARS = 25  # fewer characters than this => treat the page as scanned


def page_text_layer(data: bytes, page_index: int) -> str:
    reader = PdfReader(io.BytesIO(data))
    if not 0 <= page_index < len(reader.pages):
        raise UploadError("That page does not exist.")
    try:
        return ocr.clean_text(reader.pages[page_index].extract_text() or "")
    except Exception:  # damaged page content stream
        return ""


def render_page(data: bytes, page_index: int, scale: float = 2.0):
    pdf = pdfium.PdfDocument(data)
    try:
        if not 0 <= page_index < len(pdf):
            raise UploadError("That page does not exist.")
        return pdf[page_index].render(scale=scale).to_pil().convert("RGB")
    finally:
        pdf.close()


def extract_page(data: bytes, page_index: int, langs: str = "eng", allow_ocr: bool = True) -> dict:
    """Returns {text, method: 'text_layer'|'ocr'|'none', confidence}."""
    text = page_text_layer(data, page_index)
    if len(text) >= MIN_TEXT_CHARS:
        return {"text": text, "method": "text_layer", "confidence": None}
    if not allow_ocr:
        return {"text": text, "method": "none", "confidence": None}
    res = ocr.ocr_image(render_page(data, page_index), langs)
    return {"text": res.text, "method": "ocr", "confidence": res.confidence}


_Q_START = re.compile(r"^\s*(?:Q(?:uestion)?\.?\s*)?(\d{1,3})\s*[.):]\s+\S", re.IGNORECASE)


def split_questions(text: str) -> list[str]:
    """Heuristic: split a page into numbered questions ("1.", "Q2)", "Question 3:").
    Falls back to the whole text when no numbering is found. The student always confirms/edits."""
    chunks: list[list[str]] = []
    for line in text.splitlines():
        if _Q_START.match(line) or not chunks:
            chunks.append([line])
        else:
            chunks[-1].append(line)
    parts = [ "\n".join(c).strip() for c in chunks]
    parts = [p for p in parts if len(p) >= 8]
    numbered = sum(1 for p in parts if _Q_START.match(p))
    if numbered >= 2:
        return [p for p in parts if _Q_START.match(p)]  # drop headings before question 1
    return [text.strip()] if text.strip() else []
