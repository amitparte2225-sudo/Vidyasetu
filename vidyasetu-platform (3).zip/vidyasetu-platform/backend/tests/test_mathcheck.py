import unittest

from app.mathcheck import UnsafeExpression, parse_safe, verify


class VerifyTests(unittest.TestCase):
    def test_correct_value_verified(self):
        self.assertEqual(verify("(-3 + sqrt(9 + 16))/2", "1")["status"], "verified")
        self.assertEqual(verify("2^10", "1024")["status"], "verified")
        self.assertEqual(verify("sin(pi/2)", "1")["status"], "verified")

    def test_wrong_value_mismatch(self):
        self.assertEqual(verify("2+2", "5")["status"], "mismatch")

    def test_missing_or_symbolic_is_unavailable(self):
        self.assertEqual(verify(None, "1")["status"], "unavailable")
        self.assertEqual(verify("x+1", "2")["status"], "unavailable")
        self.assertEqual(verify("1/0", "1")["status"], "unavailable")

    def test_code_injection_is_rejected(self):
        evil = ["__import__('os').system('echo hi')", "().__class__", "open('/etc/passwd')",
                "exec('1')", "a.b", "os.getcwd()", "x; y", "lambda: 1", "[i for i in range(3)]"]
        for e in evil:
            with self.assertRaises(UnsafeExpression, msg=e):
                parse_safe(e)
            self.assertEqual(verify(e, "1")["status"], "unavailable")

    def test_overlong_rejected(self):
        with self.assertRaises(UnsafeExpression):
            parse_safe("1+" * 200 + "1")


if __name__ == "__main__":
    unittest.main()
