import io
import unittest

from PIL import Image, ImageDraw, ImageFilter, ImageFont
from pypdf import PdfWriter

from app import ocr, pdf_tools
from app.ratelimit import RateLimited, RateLimiter
from app.validation import UploadError, check_pdf, load_image, safe_user_path


def text_image(lines, size=(900, 300)):
    img = Image.new("RGB", size, "white")
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 34)
    except OSError:
        font = ImageFont.load_default()
    for i, line in enumerate(lines):
        d.text((30, 30 + i * 60), line, fill="black", font=font)
    return img


def png_bytes(img, fmt="PNG"):
    b = io.BytesIO()
    img.save(b, format=fmt)
    return b.getvalue()


def blank_pdf(pages):
    w = PdfWriter()
    for _ in range(pages):
        w.add_blank_page(width=200, height=200)
    b = io.BytesIO()
    w.write(b)
    return b.getvalue()


class ImageValidationTests(unittest.TestCase):
    def test_valid_png_loaded(self):
        img = load_image(png_bytes(text_image(["hi"])), 5_000_000)
        self.assertEqual(img.mode, "RGB")

    def test_big_image_is_downscaled(self):
        big = Image.new("RGB", (3000, 2000), "white")
        self.assertLessEqual(max(load_image(png_bytes(big), 50_000_000, 1600).size), 1600)

    def test_rejects_garbage_empty_toolarge_and_gif(self):
        with self.assertRaises(UploadError): load_image(b"not an image", 1000)
        with self.assertRaises(UploadError): load_image(b"", 1000)
        with self.assertRaises(UploadError): load_image(png_bytes(text_image(["x"])), 10)
        with self.assertRaises(UploadError): load_image(png_bytes(text_image(["x"]), "GIF"), 5_000_000)

    def test_rejects_tiny_image(self):
        with self.assertRaises(UploadError): load_image(png_bytes(Image.new("RGB", (10, 10))), 5_000_000)


class PdfValidationTests(unittest.TestCase):
    def test_page_count_and_limits(self):
        self.assertEqual(check_pdf(blank_pdf(3), 1_000_000, 10), 3)
        with self.assertRaises(UploadError): check_pdf(blank_pdf(3), 1_000_000, 2)
        with self.assertRaises(UploadError): check_pdf(blank_pdf(1), 10, 5)
        with self.assertRaises(UploadError): check_pdf(b"hello world", 1000, 5)
        with self.assertRaises(UploadError): check_pdf(b"%PDF-1.4 garbage", 1000, 5)

    def test_user_paths(self):
        self.assertEqual(safe_user_path("u1", "u1/a.pdf"), "u1/a.pdf")
        for bad in ["u2/a.pdf", "u1/../u2/a.pdf", "/u1/a.pdf", "u1/a/b.pdf", "u1/", "u1\\a.pdf"]:
            with self.assertRaises(UploadError, msg=bad): safe_user_path("u1", bad)


@unittest.skipUnless(__import__("shutil").which("tesseract"), "tesseract not installed")
class OcrTests(unittest.TestCase):
    def test_reads_printed_text(self):
        res = ocr.ocr_image(text_image(["Solve x squared minus 5x plus 6 equals 0"]), "eng")
        low = res.text.lower()
        self.assertIn("solve", low)
        self.assertIn("equals", low)
        self.assertGreater(res.confidence, 50)

    def test_blur_lowers_sharpness(self):
        sharp = text_image(["Find the area of a circle of radius 7 cm"])
        blurred = sharp.filter(ImageFilter.GaussianBlur(9))
        self.assertGreater(ocr.sharpness_score(sharp), 3 * ocr.sharpness_score(blurred))

    def test_scanned_pdf_uses_ocr(self):
        b = io.BytesIO()
        text_image(["Calculate the discriminant of the equation"], (1200, 300)).save(b, format="PDF")
        out = pdf_tools.extract_page(b.getvalue(), 0, "eng")
        self.assertEqual(out["method"], "ocr")
        self.assertIn("discriminant", out["text"].lower())


class PdfSplitTests(unittest.TestCase):
    def test_splits_numbered_questions(self):
        text = "Exercise 2\n1. Solve x + 2 = 5.\n2) Find the area of a square of side 4.\nQ3: Define velocity."
        parts = pdf_tools.split_questions(text)
        self.assertEqual(len(parts), 3)
        self.assertIn("Solve", parts[0])
        self.assertIn("area", parts[1])

    def test_no_numbering_returns_whole_text(self):
        self.assertEqual(pdf_tools.split_questions("Just a paragraph about motion."), ["Just a paragraph about motion."])
        self.assertEqual(pdf_tools.split_questions("   "), [])

    def test_page_out_of_range(self):
        with self.assertRaises(UploadError): pdf_tools.page_text_layer(blank_pdf(1), 5)


class RateLimiterTests(unittest.TestCase):
    def test_blocks_after_limit_and_recovers(self):
        t = [0.0]
        rl = RateLimiter(clock=lambda: t[0])
        for _ in range(3): rl.check("k", 3, 10)
        with self.assertRaises(RateLimited): rl.check("k", 3, 10)
        rl.check("other", 3, 10)
        t[0] = 11
        rl.check("k", 3, 10)


if __name__ == "__main__":
    unittest.main()
