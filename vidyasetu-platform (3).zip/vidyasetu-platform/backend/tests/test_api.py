"""HTTP-level validation tests. Skipped automatically when FastAPI is not installed."""
import importlib.util
import unittest

HAVE = all(importlib.util.find_spec(m) for m in ("fastapi", "pydantic", "httpx", "multipart"))


@unittest.skipUnless(HAVE, "fastapi/httpx not installed")
class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from app.main import app
        cls.client = TestClient(app)

    def test_health_is_public(self):
        r = self.client.get("/health")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["status"], "ok")

    def test_protected_endpoints_need_a_token(self):
        for method, path in [("post", "/v1/solve"), ("post", "/v1/pdf/inspect"), ("get", "/v1/me/limits"),
                             ("post", "/v1/quizzes/x/start"), ("get", "/v1/attempts/x/review")]:
            r = getattr(self.client, method)(path, json={}) if method == "post" else self.client.get(path)
            self.assertIn(r.status_code, (401, 422, 503), path)  # 503 when Supabase is not configured in the test env

    def test_solve_validation(self):
        r = self.client.post("/v1/solve", json={"question": "x"}, headers={"Authorization": "Bearer " + "a" * 30})
        self.assertIn(r.status_code, (401, 422, 503))

    def test_oversized_body_rejected(self):
        r = self.client.post("/v1/solve", content=b"x", headers={"Content-Length": str(40 * 1024 * 1024)})
        self.assertEqual(r.status_code, 413)


if __name__ == "__main__":
    unittest.main()
