import unittest

from app.grading import grade_attempt, grade_question, is_correct


class GradeQuestionTests(unittest.TestCase):
    def test_mcq_single(self):
        self.assertEqual(grade_question("mcq_single", "a", ["a"], 0, 2, 0.25), (True, 2.0))
        self.assertEqual(grade_question("mcq_single", "b", ["a"], 0, 2, 0.25), (False, -0.5))

    def test_mcq_multi_needs_exact_set_no_partial_credit(self):
        self.assertTrue(is_correct("mcq_multi", ["c", "b"], ["b", "c"]))
        self.assertFalse(is_correct("mcq_multi", ["b"], ["b", "c"]))
        self.assertFalse(is_correct("mcq_multi", ["b", "c", "d"], ["b", "c"]))
        self.assertFalse(is_correct("mcq_multi", "b", ["b", "c"]))

    def test_true_false_accepts_bool_and_string(self):
        self.assertTrue(is_correct("true_false", True, [True]))
        self.assertTrue(is_correct("true_false", "False", [False]))
        self.assertFalse(is_correct("true_false", "maybe", [True]))

    def test_numeric_tolerance(self):
        self.assertTrue(is_correct("numeric", "3.0005", [3], 0.001))
        self.assertFalse(is_correct("numeric", 3.01, [3], 0.001))
        self.assertTrue(is_correct("numeric", "1,000", [1000], 0))
        self.assertFalse(is_correct("numeric", "abc", [3], 0.1))
        self.assertFalse(is_correct("numeric", "nan", [3], 0.1))
        self.assertFalse(is_correct("numeric", True, [1], 0.1))

    def test_short_answer_normalisation(self):
        self.assertTrue(is_correct("short_answer", "  The   Discriminant. ", ["the discriminant"]))
        self.assertTrue(is_correct("short_answer", "D", ["discriminant", "d"]))
        self.assertFalse(is_correct("short_answer", "root", ["discriminant"]))

    def test_unanswered_has_no_penalty(self):
        for blank in (None, "", "  ", []):
            self.assertEqual(grade_question("mcq_single", blank, ["a"], 0, 2, 1.0), (None, 0.0))

    def test_unknown_type_raises(self):
        with self.assertRaises(ValueError):
            is_correct("essay", "x", ["x"])


class GradeAttemptTests(unittest.TestCase):
    QS = [
        {"id": "q1", "type": "mcq_single", "marks": 2, "correct": ["a"]},
        {"id": "q2", "type": "numeric", "marks": 2, "correct": [3], "tolerance": 0.001},
        {"id": "q3", "type": "true_false", "marks": 1, "correct": [True]},
    ]

    def test_totals_percentage_and_counts(self):
        r = grade_attempt(self.QS, {"q1": "a", "q2": "4"}, 0.5)
        self.assertEqual(r["score"], 1.0)           # +2 -1 +0
        self.assertEqual(r["max_score"], 5.0)
        self.assertEqual(r["percentage"], 20.0)
        self.assertEqual((r["correct_count"], r["wrong_count"], r["unanswered_count"]), (1, 1, 1))

    def test_score_never_below_zero(self):
        r = grade_attempt(self.QS, {"q1": "b", "q2": "9", "q3": False}, 1.0)
        self.assertEqual(r["score"], 0.0)
        self.assertEqual(r["percentage"], 0.0)

    def test_perfect_score(self):
        r = grade_attempt(self.QS, {"q1": "a", "q2": 3, "q3": True}, 0.25)
        self.assertEqual(r["percentage"], 100.0)

    def test_extra_responses_for_unknown_questions_are_ignored(self):
        r = grade_attempt(self.QS, {"zzz": "a"}, 0)
        self.assertEqual(r["unanswered_count"], 3)

    def test_empty_quiz(self):
        self.assertEqual(grade_attempt([], {}, 0)["percentage"], 0.0)


if __name__ == "__main__":
    unittest.main()
