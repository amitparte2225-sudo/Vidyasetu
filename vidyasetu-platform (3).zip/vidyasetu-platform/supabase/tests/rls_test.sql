-- Security tests for the Row Level Security policies. Run after migrations + seed.sql (see README / CI).
-- Any failed ASSERT aborts psql with a non-zero exit code.
insert into auth.users (id, email) values
  ('a0000000-0000-4000-8000-000000000001', 'student1@test'),
  ('a0000000-0000-4000-8000-000000000002', 'editor@test'),
  ('a0000000-0000-4000-8000-000000000003', 'admin@test'),
  ('a0000000-0000-4000-8000-000000000004', 'student2@test');
update public.user_roles set role = 'editor' where user_id = 'a0000000-0000-4000-8000-000000000002';
update public.user_roles set role = 'admin'  where user_id = 'a0000000-0000-4000-8000-000000000003';

-- a draft chapter (and a hidden-parent subtree) that students must never see
insert into public.chapters (id, subject_id, number, title, status)
values ('40000000-0000-4000-8000-0000000000ff', '30000000-0000-4000-8000-000000001001', 99, 'SECRET DRAFT', 'draft');

insert into storage.objects (bucket_id, name) values
  ('user-uploads', 'a0000000-0000-4000-8000-000000000001/mine.pdf'),
  ('user-uploads', 'a0000000-0000-4000-8000-000000000004/theirs.pdf');
insert into public.bookmarks (user_id, kind, target_id)
values ('a0000000-0000-4000-8000-000000000004', 'chapter', '40000000-0000-4000-8000-000000100102');

-- ---------------------------------------------------------------- student 1
do $$
declare n int; rc int;
begin
  perform set_config('request.jwt.claim.sub', 'a0000000-0000-4000-8000-000000000001', true);
  set local role authenticated;

  select count(*) into n from public.chapters;
  assert n = 7, 'student must see exactly the 7 published chapters, saw ' || n;
  select count(*) into n from public.chapters where title = 'SECRET DRAFT';
  assert n = 0, 'student must not see draft chapters';

  select count(*) into n from public.question_answers;
  assert n = 0, 'student must never read answer keys';
  select count(*) into n from public.questions where usage = 'quiz';
  assert n = 0, 'student must not read quiz questions directly';
  select count(*) into n from public.quiz_questions;
  assert n = 0, 'student must not read quiz_questions';
  select count(*) into n from public.solutions;
  assert n = 1, 'student sees the published practice solution only, saw ' || n;

  select count(*) into n from public.search_content('Quadratic');
  assert n > 0, 'search should find published content';
  select count(*) into n from public.search_content('SECRET');
  assert n = 0, 'search must not leak drafts';

  begin
    insert into public.chapters (subject_id, number, title) values ('30000000-0000-4000-8000-000000001001', 50, 'hack');
    assert false, 'student inserted a chapter';
  exception when insufficient_privilege then null; end;

  begin
    insert into public.user_roles (user_id, role) values ('a0000000-0000-4000-8000-000000000001', 'admin');
    assert false, 'student granted themselves a role';
  exception when insufficient_privilege or unique_violation then null; end;

  update public.user_roles set role = 'admin' where user_id = 'a0000000-0000-4000-8000-000000000001';
  get diagnostics rc = row_count;
  assert rc = 0, 'student must not be able to update roles';

  begin
    update public.profiles set is_banned = true where id = 'a0000000-0000-4000-8000-000000000001';
    assert false, 'student changed is_banned';
  exception when raise_exception then null; end;

  update public.profiles set display_name = 'Me' where id = 'a0000000-0000-4000-8000-000000000001';
  get diagnostics rc = row_count;
  assert rc = 1, 'student can edit their own profile';
  update public.profiles set display_name = 'Hacked' where id = 'a0000000-0000-4000-8000-000000000004';
  get diagnostics rc = row_count;
  assert rc = 0, 'student must not edit another profile';

  select count(*) into n from public.bookmarks;
  assert n = 0, 'student must not see another student bookmarks';
  begin
    insert into public.bookmarks (user_id, kind, target_id) values ('a0000000-0000-4000-8000-000000000004', 'chapter', gen_random_uuid());
    assert false, 'student wrote a bookmark for someone else';
  exception when insufficient_privilege then null; end;

  begin
    insert into public.quiz_attempts (user_id, quiz_id) values ('a0000000-0000-4000-8000-000000000001', '80000000-0000-4000-8000-000000000001');
    assert false, 'student created an attempt directly';
  exception when insufficient_privilege then null; end;
  begin
    insert into public.solver_requests (user_id, source, question_text) values ('a0000000-0000-4000-8000-000000000001', 'text', 'x');
    assert false, 'student wrote solver_requests directly';
  exception when insufficient_privilege then null; end;

  begin
    perform public.admin_stats();
    assert false, 'student called admin_stats';
  exception when raise_exception then null; end;

  select count(*) into n from storage.objects;
  assert n = 1, 'student sees only their own upload folder, saw ' || n;

  select count(*) into n from public.profiles;
  assert n = 1, 'student sees only their own profile';
  select count(*) into n from public.usage_limits;
  assert n = 1, 'student sees the default limit row only';
  reset role;
end $$;

-- ---------------------------------------------------------------- hidden parents hide children
update public.subjects set status = 'draft' where id = '30000000-0000-4000-8000-000000001001';
do $$
declare n int;
begin
  perform set_config('request.jwt.claim.sub', 'a0000000-0000-4000-8000-000000000001', true);
  set local role authenticated;
  select count(*) into n from public.chapters where subject_id = '30000000-0000-4000-8000-000000001001';
  assert n = 0, 'chapters of an unpublished subject must be hidden';
  select count(*) into n from public.quizzes;
  assert n = 0, 'quizzes of an unpublished chapter chain must be hidden';
  reset role;
end $$;
update public.subjects set status = 'published' where id = '30000000-0000-4000-8000-000000001001';

-- ---------------------------------------------------------------- editor
do $$
declare n int;
begin
  perform set_config('request.jwt.claim.sub', 'a0000000-0000-4000-8000-000000000002', true);
  set local role authenticated;
  select count(*) into n from public.chapters where title = 'SECRET DRAFT';
  assert n = 1, 'editor sees drafts';
  insert into public.chapters (subject_id, number, title) values ('30000000-0000-4000-8000-000000001001', 60, 'Editor chapter');
  select count(*) into n from public.question_answers;
  assert n > 0, 'editor can read answer keys';
  begin
    insert into public.user_roles (user_id, role) values ('a0000000-0000-4000-8000-000000000002', 'admin');
    assert false, 'editor changed roles';
  exception when insufficient_privilege or unique_violation then null; end;
  begin
    update public.usage_limits set daily_solver_requests = 9999;
    get diagnostics n = row_count;
    assert n = 0, 'editor must not change AI limits';
  end;
  reset role;
end $$;

-- ---------------------------------------------------------------- admin
do $$
declare n int; stats jsonb;
begin
  perform set_config('request.jwt.claim.sub', 'a0000000-0000-4000-8000-000000000003', true);
  set local role authenticated;
  assert public.has_permission('users.manage'), 'admin can manage users';
  stats := public.admin_stats();
  assert (stats ->> 'users')::int = 4, 'admin_stats counts users';
  select count(*) into n from public.admin_list_users();
  assert n = 4, 'admin lists users';
  update public.usage_limits set daily_solver_requests = 20 where user_id is null;
  get diagnostics n = row_count;
  assert n = 1, 'admin can change AI limits';
  reset role;
end $$;

-- ---------------------------------------------------------------- banned users lose privileges
update public.profiles set is_banned = true where id = 'a0000000-0000-4000-8000-000000000002';
do $$
begin
  perform set_config('request.jwt.claim.sub', 'a0000000-0000-4000-8000-000000000002', true);
  set local role authenticated;
  assert not public.has_permission('content.write'), 'a banned editor loses permissions';
  reset role;
end $$;

select 'ALL RLS TESTS PASSED' as result;
