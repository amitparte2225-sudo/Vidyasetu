-- Storage buckets and access rules. Both buckets are PRIVATE.
-- content      : chapter PDFs/images/diagrams uploaded by staff, read by students via signed URLs
-- user-uploads : a student's own PDFs (folder name must equal the user id)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('content', 'content', false, 26214400,
    array['application/pdf', 'image/png', 'image/jpeg', 'image/webp']),
  ('user-uploads', 'user-uploads', false, 20971520,
    array['application/pdf', 'image/png', 'image/jpeg', 'image/webp'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

create policy "content staff write" on storage.objects for insert to authenticated
  with check (bucket_id = 'content' and public.has_permission('content.write'));
create policy "content staff update" on storage.objects for update to authenticated
  using (bucket_id = 'content' and public.has_permission('content.write'));
create policy "content staff delete" on storage.objects for delete to authenticated
  using (bucket_id = 'content' and public.has_permission('content.write'));
create policy "content read published or staff" on storage.objects for select to authenticated
  using (bucket_id = 'content' and (
    public.has_permission('content.write')
    or exists (select 1 from public.resources r
               where r.file_path = storage.objects.name and r.status = 'published'
                 and public.chapter_is_visible(r.chapter_id))));

create policy "user uploads insert own" on storage.objects for insert to authenticated
  with check (bucket_id = 'user-uploads' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "user uploads read own" on storage.objects for select to authenticated
  using (bucket_id = 'user-uploads' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "user uploads delete own" on storage.objects for delete to authenticated
  using (bucket_id = 'user-uploads' and (storage.foldername(name))[1] = auth.uid()::text);
