-- Row Level Security, permission helpers, triggers and search.

-- ---------- permission helpers ----------
create function public.has_permission(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from public.user_roles ur
    join public.role_permissions rp on rp.role = ur.role
    left join public.profiles pr on pr.id = ur.user_id
    where ur.user_id = auth.uid()
      and rp.permission = p
      and coalesce(pr.is_banned, false) = false
  );
$$;

create function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select public.has_permission('content.write');
$$;

-- ---------- visibility helpers (a row is visible only if its whole parent chain is published) ----------
create function public.level_is_visible(lid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.levels l
    join public.institutions i on i.id = l.institution_id
    where l.id = lid and l.status = 'published' and i.status = 'published'
      and (l.parent_id is null or exists (
        select 1 from public.levels p where p.id = l.parent_id and p.status = 'published'))
  );
$$;

create function public.subject_is_visible(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.subjects s
    where s.id = sid and s.status = 'published' and public.level_is_visible(s.level_id)
  );
$$;

create function public.chapter_is_visible(cid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.chapters c
    where c.id = cid and c.status = 'published' and public.subject_is_visible(c.subject_id)
  );
$$;

-- ---------- triggers ----------
-- Only users with content.publish may publish/archive. Server-side jobs (no auth.uid()) are allowed.
create function public.enforce_publish_permission() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and (
       (tg_op = 'INSERT' and new.status <> 'draft')
    or (tg_op = 'UPDATE' and new.status is distinct from old.status)) then
    if not public.has_permission('content.publish') then
      raise exception 'content.publish permission required to change status';
    end if;
  end if;
  return new;
end $$;

do $$
declare t text;
begin
  foreach t in array array['institutions','levels','subjects','chapters','topics','resources',
    'questions','solutions','quizzes']
  loop
    execute format('create trigger enforce_publish_%1$s before insert or update on public.%1$I for each row execute function public.enforce_publish_permission()', t);
  end loop;
end $$;

-- A user can edit their own profile but never ban/unban themselves.
create function public.protect_profile_fields() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and new.is_banned is distinct from old.is_banned
     and not public.has_permission('users.manage') then
    raise exception 'only user managers can change is_banned';
  end if;
  return new;
end $$;
create trigger protect_profile_fields before update on public.profiles
  for each row execute function public.protect_profile_fields();

-- New sign-ups get a profile and the student role. The role can NOT be chosen by the client.
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, left(coalesce(new.raw_user_meta_data ->> 'display_name', ''), 100))
  on conflict do nothing;
  insert into public.user_roles (user_id, role) values (new.id, 'student') on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- enable RLS everywhere ----------
alter table public.roles enable row level security;
alter table public.permissions enable row level security;
alter table public.role_permissions enable row level security;
alter table public.user_roles enable row level security;
alter table public.institutions enable row level security;
alter table public.levels enable row level security;
alter table public.subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.topics enable row level security;
alter table public.resources enable row level security;
alter table public.questions enable row level security;
alter table public.question_answers enable row level security;
alter table public.solutions enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.profiles enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.quiz_responses enable row level security;
alter table public.bookmarks enable row level security;
alter table public.solver_requests enable row level security;
alter table public.usage_limits enable row level security;
alter table public.content_reports enable row level security;

-- ---------- staff can do everything on content tables ----------
do $$
declare t text;
begin
  foreach t in array array['institutions','levels','subjects','chapters','topics','resources',
    'questions','question_answers','solutions','quizzes','quiz_questions']
  loop
    execute format('create policy "%1$s staff all" on public.%1$I for all to authenticated
      using (public.has_permission(''content.write'')) with check (public.has_permission(''content.write''))', t);
  end loop;
end $$;

-- ---------- students: published content only ----------
create policy "institutions read published" on public.institutions for select to authenticated
  using (status = 'published');
create policy "levels read published" on public.levels for select to authenticated
  using (public.level_is_visible(id));
create policy "subjects read published" on public.subjects for select to authenticated
  using (public.subject_is_visible(id));
create policy "chapters read published" on public.chapters for select to authenticated
  using (public.chapter_is_visible(id));
create policy "topics read published" on public.topics for select to authenticated
  using (status = 'published' and public.chapter_is_visible(chapter_id));
create policy "resources read published" on public.resources for select to authenticated
  using (status = 'published' and public.chapter_is_visible(chapter_id));
-- Practice questions only. Quiz questions are delivered by the backend without answers.
create policy "questions read published practice" on public.questions for select to authenticated
  using (status = 'published' and usage = 'practice' and public.chapter_is_visible(chapter_id));
create policy "solutions read published" on public.solutions for select to authenticated
  using (status = 'published' and exists (
    select 1 from public.questions q
    where q.id = question_id and q.status = 'published' and q.usage = 'practice'
      and public.chapter_is_visible(q.chapter_id)));
create policy "quizzes read published" on public.quizzes for select to authenticated
  using (status = 'published' and public.chapter_is_visible(chapter_id));
-- question_answers and quiz_questions: NO student policy => students can never read them.

-- ---------- roles / users ----------
create policy "roles readable" on public.roles for select to authenticated using (true);
create policy "permissions readable" on public.permissions for select to authenticated using (true);
create policy "role_permissions readable" on public.role_permissions for select to authenticated using (true);
create policy "user_roles read own or manager" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_permission('users.manage'));
create policy "user_roles manager write" on public.user_roles for all to authenticated
  using (public.has_permission('users.manage')) with check (public.has_permission('users.manage'));

create policy "profiles read own or manager" on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_permission('users.manage'));
create policy "profiles update own" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles manager update" on public.profiles for update to authenticated
  using (public.has_permission('users.manage')) with check (public.has_permission('users.manage'));
-- No insert policy: profiles are created by the sign-up trigger only.

-- ---------- private student records ----------
create policy "attempts read own" on public.quiz_attempts for select to authenticated
  using (user_id = auth.uid() or public.is_staff());
create policy "responses read own" on public.quiz_responses for select to authenticated
  using (exists (select 1 from public.quiz_attempts a
    where a.id = attempt_id and (a.user_id = auth.uid() or public.is_staff())));
-- No insert/update policies for students: attempts are created and graded by the backend.

create policy "bookmarks own" on public.bookmarks for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "solver read own" on public.solver_requests for select to authenticated
  using (user_id = auth.uid());
create policy "solver delete own" on public.solver_requests for delete to authenticated
  using (user_id = auth.uid());
-- Inserts/updates come from the backend (service role bypasses RLS).

create policy "limits read applicable" on public.usage_limits for select to authenticated
  using (user_id is null or user_id = auth.uid() or public.has_permission('ai.configure'));
create policy "limits configure" on public.usage_limits for all to authenticated
  using (public.has_permission('ai.configure')) with check (public.has_permission('ai.configure'));

create policy "reports insert own" on public.content_reports for insert to authenticated
  with check (reporter_id = auth.uid());
create policy "reports read own or manager" on public.content_reports for select to authenticated
  using (reporter_id = auth.uid() or public.has_permission('reports.manage'));
create policy "reports manager update" on public.content_reports for update to authenticated
  using (public.has_permission('reports.manage')) with check (public.has_permission('reports.manage'));

-- ---------- lock down anonymous access completely ----------
revoke all on all tables in schema public from anon;
revoke all on all functions in schema public from anon;

-- ---------- progress view (security_invoker => RLS of the caller applies) ----------
create view public.my_chapter_progress with (security_invoker = true) as
select q.chapter_id,
       count(*) filter (where a.status = 'submitted') as attempts,
       max(a.percentage) as best_percentage,
       max(a.submitted_at) as last_attempt_at
from public.quiz_attempts a
join public.quizzes q on q.id = a.quiz_id
where a.user_id = auth.uid()
group by q.chapter_id;

-- ---------- search (security invoker: students only find published content) ----------
create function public.search_content(q text, max_results int default 40)
returns table (kind text, id uuid, title text, subtitle text, level_id uuid, subject_id uuid, chapter_id uuid)
language sql stable security invoker set search_path = public as $$
  with p as (
    select '%' || replace(replace(replace(trim(q), '\', '\\'), '%', '\%'), '_', '\_') || '%' as pat
  )
  select * from (
    select 'level'::text, l.id, l.name, null::text, l.id, null::uuid, null::uuid
      from levels l, p where length(trim(q)) >= 2 and (l.name ilike p.pat or l.name_i18n::text ilike p.pat)
    union all
    select 'subject', s.id, s.name, null, s.level_id, s.id, null
      from subjects s, p where length(trim(q)) >= 2 and (s.name ilike p.pat or s.name_i18n::text ilike p.pat)
    union all
    select 'chapter', c.id, c.title, 'Chapter ' || c.number, null, c.subject_id, c.id
      from chapters c, p where length(trim(q)) >= 2 and (c.title ilike p.pat or c.title_i18n::text ilike p.pat)
    union all
    select 'resource', r.id, r.title, r.kind::text, null, null, r.chapter_id
      from resources r, p where length(trim(q)) >= 2 and r.kind in ('note','formula','solved_example')
        and (r.title ilike p.pat or r.body_md ilike p.pat)
    union all
    select 'question', qu.id, left(qu.prompt, 160), qu.type::text, null, null, qu.chapter_id
      from questions qu, p where length(trim(q)) >= 2 and qu.usage = 'practice'
        and (qu.prompt ilike p.pat or qu.prompt_i18n::text ilike p.pat)
  ) r (kind, id, title, subtitle, level_id, subject_id, chapter_id)
  limit least(greatest(max_results, 1), 100);
$$;

-- ---------- admin statistics (staff only) ----------
create function public.admin_stats() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'not allowed'; end if;
  return jsonb_build_object(
    'users', (select count(*) from public.profiles),
    'published_chapters', (select count(*) from public.chapters where status = 'published'),
    'draft_chapters', (select count(*) from public.chapters where status = 'draft'),
    'published_quizzes', (select count(*) from public.quizzes where status = 'published'),
    'quiz_attempts_7d', (select count(*) from public.quiz_attempts where started_at > now() - interval '7 days'),
    'solver_requests_7d', (select count(*) from public.solver_requests where created_at > now() - interval '7 days'),
    'solver_errors_7d', (select count(*) from public.solver_requests where status = 'error' and created_at > now() - interval '7 days'),
    'open_reports', (select count(*) from public.content_reports where status = 'open')
  );
end $$;

-- Admin user list (email lives in auth.users, so a definer function is needed).
create function public.admin_list_users() returns table (id uuid, email text, display_name text, role text, is_banned boolean, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_permission('users.manage') then raise exception 'not allowed'; end if;
  return query
    select u.id, u.email::text, p.display_name, coalesce(ur.role, 'student'), coalesce(p.is_banned, false), u.created_at
    from auth.users u
    left join public.profiles p on p.id = u.id
    left join public.user_roles ur on ur.user_id = u.id
    order by u.created_at desc limit 500;
end $$;

-- Student self-service: delete all my AI history.
create function public.delete_my_solver_history() returns void
language sql security invoker set search_path = public as $$
  delete from public.solver_requests where user_id = auth.uid();
$$;

grant execute on function public.search_content(text, int) to authenticated;
grant execute on function public.admin_stats() to authenticated;
grant execute on function public.admin_list_users() to authenticated;
grant execute on function public.delete_my_solver_history() to authenticated;
