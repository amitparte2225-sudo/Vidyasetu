-- Vidyasetu schema. Apply in order: 0001 schema, 0002 rls, 0003 storage, then seed.sql.
create extension if not exists pg_trgm with schema extensions;

-- ---------- enums ----------
create type public.content_status as enum ('draft', 'published', 'archived');
create type public.institution_kind as enum ('board', 'university');
create type public.level_kind as enum ('class', 'degree', 'year', 'semester');
create type public.resource_kind as enum ('note', 'formula', 'solved_example', 'pdf', 'image', 'diagram');
create type public.question_type as enum ('mcq_single', 'mcq_multi', 'true_false', 'numeric', 'short_answer');
create type public.question_usage as enum ('practice', 'quiz');
create type public.difficulty as enum ('easy', 'medium', 'hard');
create type public.attempt_status as enum ('in_progress', 'submitted', 'expired');
create type public.solver_source as enum ('text', 'image', 'pdf');
create type public.report_status as enum ('open', 'resolved', 'dismissed');

-- ---------- generic helpers ----------
create function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- roles and permissions ----------
create table public.roles (name text primary key, description text);
create table public.permissions (key text primary key, description text);
create table public.role_permissions (
  role text not null references public.roles(name) on delete cascade,
  permission text not null references public.permissions(key) on delete cascade,
  primary key (role, permission)
);
create table public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null references public.roles(name) default 'student',
  updated_at timestamptz not null default now()
);

insert into public.roles (name, description) values
  ('student', 'Ordinary learner. No administrative rights.'),
  ('editor', 'Can create and publish content and handle reports.'),
  ('admin', 'Full access including users and AI limits.');
insert into public.permissions (key, description) values
  ('content.write', 'Create and edit educational content'),
  ('content.publish', 'Publish, unpublish and archive content'),
  ('reports.manage', 'Review reported content'),
  ('users.manage', 'Manage users and roles'),
  ('ai.configure', 'Change AI usage limits');
insert into public.role_permissions (role, permission) values
  ('editor', 'content.write'), ('editor', 'content.publish'), ('editor', 'reports.manage'),
  ('admin', 'content.write'), ('admin', 'content.publish'), ('admin', 'reports.manage'),
  ('admin', 'users.manage'), ('admin', 'ai.configure');

-- ---------- content hierarchy ----------
-- institutions (board / university) -> levels (class / degree / semester) -> subjects
--   -> chapters -> topics -> resources, questions, quizzes
-- *_i18n columns hold translations, e.g. {"mr": "..."}; the plain column is English.
create table public.institutions (
  id uuid primary key default gen_random_uuid(),
  kind public.institution_kind not null,
  name text not null check (length(name) between 1 and 200),
  name_i18n jsonb not null default '{}',
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.levels (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  parent_id uuid references public.levels(id) on delete cascade,
  kind public.level_kind not null,
  name text not null check (length(name) between 1 and 200),
  name_i18n jsonb not null default '{}',
  description text,
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (parent_id is null or parent_id <> id)
);
create index levels_institution_idx on public.levels (institution_id);
create index levels_parent_idx on public.levels (parent_id);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  level_id uuid not null references public.levels(id) on delete cascade,
  name text not null check (length(name) between 1 and 200),
  name_i18n jsonb not null default '{}',
  description text,
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index subjects_level_idx on public.subjects (level_id);

create table public.chapters (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  number int not null check (number >= 0),
  title text not null check (length(title) between 1 and 300),
  title_i18n jsonb not null default '{}',
  description text,
  description_i18n jsonb not null default '{}',
  objectives jsonb not null default '[]' check (jsonb_typeof(objectives) = 'array'),
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index chapters_subject_idx on public.chapters (subject_id);
create index chapters_title_trgm on public.chapters using gin (title extensions.gin_trgm_ops);

create table public.topics (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  title text not null check (length(title) between 1 and 300),
  title_i18n jsonb not null default '{}',
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index topics_chapter_idx on public.topics (chapter_id);

create table public.resources (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  topic_id uuid references public.topics(id) on delete set null,
  kind public.resource_kind not null,
  title text not null check (length(title) between 1 and 300),
  title_i18n jsonb not null default '{}',
  body_md text,                       -- notes / formulas: Markdown with $LaTeX$
  body_i18n jsonb not null default '{}',
  file_path text,                     -- path inside the private "content" bucket
  mime_type text,
  size_bytes bigint check (size_bytes is null or size_bytes between 1 and 26214400),
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    (kind in ('note', 'formula', 'solved_example') and body_md is not null)
    or (kind in ('pdf', 'image', 'diagram') and file_path is not null)
  ),
  check (file_path is null or file_path !~ '(^/|\.\.)')
);
create index resources_chapter_idx on public.resources (chapter_id);
create index resources_body_trgm on public.resources using gin (body_md extensions.gin_trgm_ops);

create table public.questions (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  topic_id uuid references public.topics(id) on delete set null,
  type public.question_type not null,
  usage public.question_usage not null default 'practice',
  prompt text not null check (length(prompt) between 1 and 4000),
  prompt_i18n jsonb not null default '{}',
  options jsonb not null default '[]',   -- [{"id":"a","text":"..."}] for MCQ types
  marks numeric(6,2) not null default 1 check (marks > 0),
  difficulty public.difficulty not null default 'medium',
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (jsonb_typeof(options) = 'array'),
  check (type not in ('mcq_single', 'mcq_multi') or jsonb_array_length(options) >= 2)
);
create index questions_chapter_idx on public.questions (chapter_id);
create index questions_prompt_trgm on public.questions using gin (prompt extensions.gin_trgm_ops);

-- Correct answers live in their own table that students can never read.
-- correct: mcq_single ["a"] | mcq_multi ["a","c"] | true_false [true] | numeric [12.5] | short_answer ["answer 1","answer 2"]
create table public.question_answers (
  question_id uuid primary key references public.questions(id) on delete cascade,
  correct jsonb not null check (jsonb_typeof(correct) = 'array' and jsonb_array_length(correct) >= 1),
  numeric_tolerance numeric not null default 0 check (numeric_tolerance >= 0),
  explanation text,
  explanation_i18n jsonb not null default '{}',
  updated_at timestamptz not null default now()
);

-- Worked solutions for practice questions. Administrator-written => verified.
create table public.solutions (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  body_md text not null,
  body_i18n jsonb not null default '{}',
  is_verified boolean not null default true,
  status public.content_status not null default 'draft',
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index solutions_question_idx on public.solutions (question_id);

create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  title text not null check (length(title) between 1 and 300),
  title_i18n jsonb not null default '{}',
  description text,
  time_limit_seconds int check (time_limit_seconds is null or time_limit_seconds between 30 and 14400),
  negative_marking numeric(4,3) not null default 0 check (negative_marking between 0 and 1), -- fraction of a question's marks lost when wrong
  shuffle_questions boolean not null default true,
  pass_percentage numeric(5,2) not null default 40 check (pass_percentage between 0 and 100),
  status public.content_status not null default 'draft',
  display_order int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index quizzes_chapter_idx on public.quizzes (chapter_id);

create table public.quiz_questions (
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  display_order int not null default 0,
  marks_override numeric(6,2) check (marks_override is null or marks_override > 0),
  primary key (quiz_id, question_id)
);
create index quiz_questions_question_idx on public.quiz_questions (question_id);

-- ---------- profiles ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (display_name is null or length(display_name) <= 100),
  preferred_language text not null default 'en' check (preferred_language ~ '^[a-z]{2,3}$'),
  level_id uuid references public.levels(id) on delete set null,
  is_banned boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- student activity ----------
create table public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  status public.attempt_status not null default 'in_progress',
  started_at timestamptz not null default now(),
  expires_at timestamptz,
  submitted_at timestamptz,
  question_order jsonb not null default '[]',
  score numeric(8,2),
  max_score numeric(8,2),
  percentage numeric(5,2),
  correct_count int,
  wrong_count int,
  unanswered_count int
);
create index quiz_attempts_user_idx on public.quiz_attempts (user_id, started_at desc);
create index quiz_attempts_quiz_idx on public.quiz_attempts (quiz_id);

create table public.quiz_responses (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.quiz_attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  response jsonb,
  is_correct boolean,
  awarded numeric(8,2) not null default 0,
  unique (attempt_id, question_id)
);

create table public.bookmarks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind text not null check (kind in ('chapter', 'question', 'resource', 'solver_request')),
  target_id uuid not null,
  created_at timestamptz not null default now(),
  unique (user_id, kind, target_id)
);

-- Written by the backend only (service role). Stores text + solution, never the uploaded file.
create table public.solver_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null default 'solve' check (kind in ('solve', 'ocr')), -- 'ocr' rows only count towards the quota
  source public.solver_source not null,
  level_hint text,
  subject_hint text,
  question_text text not null,
  solution jsonb,
  provider text,
  model text,
  status text not null default 'pending' check (status in ('pending', 'ok', 'error')),
  error text,
  tokens_in int,
  tokens_out int,
  created_at timestamptz not null default now()
);
create index solver_requests_user_idx on public.solver_requests (user_id, created_at desc);

-- user_id NULL = the default row. A row with a user_id overrides it for that user.
create table public.usage_limits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete cascade,
  daily_solver_requests int not null default 15 check (daily_solver_requests >= 0),
  monthly_solver_requests int not null default 200 check (monthly_solver_requests >= 0),
  max_upload_mb int not null default 15 check (max_upload_mb between 1 and 50),
  max_pdf_pages int not null default 100 check (max_pdf_pages between 1 and 1000),
  max_question_chars int not null default 3000 check (max_question_chars between 100 and 20000),
  updated_at timestamptz not null default now()
);
create unique index usage_limits_single_default on public.usage_limits ((true)) where user_id is null;
insert into public.usage_limits (user_id) values (null);

create table public.content_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  target_kind text not null check (target_kind in ('chapter', 'resource', 'question', 'solution', 'solver_request')),
  target_id uuid not null,
  reason text not null check (length(reason) between 3 and 1000),
  status public.report_status not null default 'open',
  resolved_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index content_reports_status_idx on public.content_reports (status, created_at desc);

-- ---------- updated_at triggers ----------
do $$
declare t text;
begin
  foreach t in array array['institutions','levels','subjects','chapters','topics','resources','questions',
    'question_answers','solutions','quizzes','profiles','user_roles','usage_limits']
  loop
    execute format('create trigger touch_%1$s before update on public.%1$I for each row execute function public.touch_updated_at()', t);
  end loop;
end $$;
