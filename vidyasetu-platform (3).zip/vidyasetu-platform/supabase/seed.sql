-- Sample content (original text written for this project). Safe to edit or delete from the admin dashboard.
-- Run AFTER the three migrations. Runs as the database owner, so the publish trigger allows it.
insert into public.institutions (id, kind, name, name_i18n, status, display_order) values
  ('10000000-0000-4000-8000-000000000001', 'board', 'Maharashtra State Board', '{"mr":"महाराष्ट्र राज्य मंडळ"}', 'published', 1),
  ('10000000-0000-4000-8000-000000000002', 'university', 'University of Mumbai', '{"mr":"मुंबई विद्यापीठ"}', 'published', 2);

insert into public.levels (id, institution_id, parent_id, kind, name, name_i18n, status, display_order) values
  ('20000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000001', null, 'class', 'Class 7', '{"mr":"इयत्ता ७वी"}', 'published', 7),
  ('20000000-0000-4000-8000-000000000008', '10000000-0000-4000-8000-000000000001', null, 'class', 'Class 8', '{"mr":"इयत्ता ८वी"}', 'published', 8),
  ('20000000-0000-4000-8000-000000000009', '10000000-0000-4000-8000-000000000001', null, 'class', 'Class 9', '{"mr":"इयत्ता ९वी"}', 'published', 9),
  ('20000000-0000-4000-8000-000000000010', '10000000-0000-4000-8000-000000000001', null, 'class', 'Class 10', '{"mr":"इयत्ता १०वी"}', 'published', 10),
  ('20000000-0000-4000-8000-000000000011', '10000000-0000-4000-8000-000000000001', null, 'class', 'Class 11', '{"mr":"इयत्ता ११वी"}', 'published', 11),
  ('20000000-0000-4000-8000-000000000012', '10000000-0000-4000-8000-000000000001', null, 'class', 'Class 12', '{"mr":"इयत्ता १२वी"}', 'published', 12),
  ('20000000-0000-4000-8000-000000000101', '10000000-0000-4000-8000-000000000002', null, 'degree', 'B.Sc. Physics', '{"mr":"बी.एस्सी. भौतिकशास्त्र"}', 'published', 101),
  ('20000000-0000-4000-8000-000000000102', '10000000-0000-4000-8000-000000000002', null, 'degree', 'B.Sc. Mathematics', '{"mr":"बी.एस्सी. गणित"}', 'published', 102),
  ('20000000-0000-4000-8000-000000000103', '10000000-0000-4000-8000-000000000002', null, 'degree', 'Engineering Mathematics', '{"mr":"अभियांत्रिकी गणित"}', 'published', 103),
  ('20000000-0000-4000-8000-000000001011', '10000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000101', 'semester', 'Semester 1', '{"mr":"सत्र १"}', 'published', 1),
  ('20000000-0000-4000-8000-000000001021', '10000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000102', 'semester', 'Semester 1', '{"mr":"सत्र १"}', 'published', 1),
  ('20000000-0000-4000-8000-000000001031', '10000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000103', 'semester', 'Semester 1', '{"mr":"सत्र १"}', 'published', 1),
  ('20000000-0000-4000-8000-000000001032', '10000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000103', 'semester', 'Semester 2', '{"mr":"सत्र २"}', 'published', 2);

insert into public.subjects (id, level_id, name, name_i18n, status, display_order) values
  ('30000000-0000-4000-8000-000000000701', '20000000-0000-4000-8000-000000000007', 'Mathematics', '{"mr":"गणित"}', 'published', 1),
  ('30000000-0000-4000-8000-000000000702', '20000000-0000-4000-8000-000000000007', 'Science', '{"mr":"विज्ञान"}', 'published', 2),
  ('30000000-0000-4000-8000-000000000801', '20000000-0000-4000-8000-000000000008', 'Mathematics', '{"mr":"गणित"}', 'published', 1),
  ('30000000-0000-4000-8000-000000000802', '20000000-0000-4000-8000-000000000008', 'Science', '{"mr":"विज्ञान"}', 'published', 2),
  ('30000000-0000-4000-8000-000000000901', '20000000-0000-4000-8000-000000000009', 'Mathematics', '{"mr":"गणित"}', 'published', 1),
  ('30000000-0000-4000-8000-000000000902', '20000000-0000-4000-8000-000000000009', 'Science', '{"mr":"विज्ञान"}', 'published', 2),
  ('30000000-0000-4000-8000-000000001001', '20000000-0000-4000-8000-000000000010', 'Mathematics Part 1', '{"mr":"गणित भाग १"}', 'published', 1),
  ('30000000-0000-4000-8000-000000001002', '20000000-0000-4000-8000-000000000010', 'Mathematics Part 2', '{"mr":"गणित भाग २"}', 'published', 2),
  ('30000000-0000-4000-8000-000000001003', '20000000-0000-4000-8000-000000000010', 'Science', '{"mr":"विज्ञान"}', 'published', 3),
  ('30000000-0000-4000-8000-000000001101', '20000000-0000-4000-8000-000000000011', 'Physics', '{"mr":"भौतिकशास्त्र"}', 'published', 1),
  ('30000000-0000-4000-8000-000000001102', '20000000-0000-4000-8000-000000000011', 'Mathematics', '{"mr":"गणित"}', 'published', 2),
  ('30000000-0000-4000-8000-000000001201', '20000000-0000-4000-8000-000000000012', 'Physics', '{"mr":"भौतिकशास्त्र"}', 'published', 1),
  ('30000000-0000-4000-8000-000000001202', '20000000-0000-4000-8000-000000000012', 'Mathematics', '{"mr":"गणित"}', 'published', 2),
  ('30000000-0000-4000-8000-000000010101', '20000000-0000-4000-8000-000000001011', 'Mechanics', '{"mr":"यामिकी"}', 'published', 1),
  ('30000000-0000-4000-8000-000000010201', '20000000-0000-4000-8000-000000001021', 'Calculus', '{"mr":"कलन"}', 'published', 1),
  ('30000000-0000-4000-8000-000000010301', '20000000-0000-4000-8000-000000001031', 'Engineering Mathematics I', '{}', 'published', 1),
  ('30000000-0000-4000-8000-000000010302', '20000000-0000-4000-8000-000000001032', 'Engineering Mathematics II', '{}', 'published', 1);

insert into public.chapters (id, subject_id, number, title, description, objectives, status, display_order) values
  ('40000000-0000-4000-8000-000000100101', '30000000-0000-4000-8000-000000001001', 1, 'Linear Equations in Two Variables', 'Solve pairs of linear equations by substitution and elimination.', '["Solve a pair of linear equations","Apply them to word problems"]', 'published', 1),
  ('40000000-0000-4000-8000-000000100102', '30000000-0000-4000-8000-000000001001', 2, 'Quadratic Equations', 'Standard form, factorisation, the quadratic formula and the discriminant.', '["Write a quadratic in standard form","Solve using factorisation and the formula","Use the discriminant to describe roots"]', 'published', 2),
  ('40000000-0000-4000-8000-000000100103', '30000000-0000-4000-8000-000000001001', 3, 'Arithmetic Progression', 'Terms and sums of arithmetic progressions.', '["Find the nth term","Find the sum of n terms"]', 'published', 3),
  ('40000000-0000-4000-8000-000000110101', '30000000-0000-4000-8000-000000001101', 1, 'Units and Measurements', 'SI units, dimensions and significant figures.', '["Use SI units","Apply dimensional analysis"]', 'published', 1),
  ('40000000-0000-4000-8000-000000110102', '30000000-0000-4000-8000-000000001101', 2, 'Motion in a Plane', 'Projectile motion and vectors in two dimensions.', '["Resolve vectors","Solve projectile problems"]', 'published', 2),
  ('40000000-0000-4000-8000-000001010101', '30000000-0000-4000-8000-000000010101', 1, 'Newtonian Dynamics', 'Newton''s laws applied to particles and systems.', '["Draw free-body diagrams","Apply F = ma"]', 'published', 1),
  ('40000000-0000-4000-8000-000001030101', '30000000-0000-4000-8000-000000010301', 1, 'Matrices', 'Rank, inverse and systems of linear equations.', '["Compute rank","Solve linear systems"]', 'published', 1);

insert into public.topics (id, chapter_id, title, status, display_order) values
  ('50000000-0000-4000-8000-000000000001', '40000000-0000-4000-8000-000000100102', 'The quadratic formula', 'published', 1),
  ('50000000-0000-4000-8000-000000000002', '40000000-0000-4000-8000-000000100102', 'Nature of roots', 'published', 2);

insert into public.resources (id, chapter_id, topic_id, kind, title, body_md, status, display_order) values
  ('60000000-0000-4000-8000-000000000001', '40000000-0000-4000-8000-000000100102', null, 'note', 'Introduction',
   E'# Quadratic equations\nA quadratic equation in $x$ has the form $ax^2 + bx + c = 0$ with $a \\neq 0$.\n\n- Roots are the values of $x$ that satisfy it.\n- It has at most two real roots.', 'published', 1),
  ('60000000-0000-4000-8000-000000000002', '40000000-0000-4000-8000-000000100102', '50000000-0000-4000-8000-000000000001', 'formula', 'Quadratic formula',
   E'$$x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}$$\nThe expression $D = b^2 - 4ac$ is the **discriminant**.', 'published', 2),
  ('60000000-0000-4000-8000-000000000003', '40000000-0000-4000-8000-000000100102', '50000000-0000-4000-8000-000000000002', 'solved_example', 'Example: nature of roots',
   E'Find the nature of the roots of $x^2 - 4x + 4 = 0$.\n\n$D = (-4)^2 - 4(1)(4) = 0$, so the roots are real and equal: $x = 2$.', 'published', 3),
  ('60000000-0000-4000-8000-000000000004', '40000000-0000-4000-8000-000001010101', null, 'formula', 'Newton''s second law',
   E'$$\\vec{F}_{net} = m\\vec{a}$$\nForce in newtons ($\\mathrm{N}$), mass in kilograms, acceleration in $\\mathrm{m\\,s^{-2}}$.', 'published', 1);

-- Quiz questions (type, options, answers) for "Quadratic Equations"
insert into public.questions (id, chapter_id, type, usage, prompt, options, marks, difficulty, status, display_order) values
  ('70000000-0000-4000-8000-000000000001', '40000000-0000-4000-8000-000000100102', 'mcq_single', 'quiz', 'Which is the discriminant of $2x^2 + 3x - 5 = 0$?', '[{"id":"a","text":"$49$"},{"id":"b","text":"$-31$"},{"id":"c","text":"$9$"},{"id":"d","text":"$29$"}]', 2, 'easy', 'published', 1),
  ('70000000-0000-4000-8000-000000000002', '40000000-0000-4000-8000-000000100102', 'mcq_multi', 'quiz', 'Select ALL roots of $x^2 - 5x + 6 = 0$.', '[{"id":"a","text":"$1$"},{"id":"b","text":"$2$"},{"id":"c","text":"$3$"},{"id":"d","text":"$6$"}]', 2, 'easy', 'published', 2),
  ('70000000-0000-4000-8000-000000000003', '40000000-0000-4000-8000-000000100102', 'true_false', 'quiz', 'A quadratic equation can have at most two real roots.', '[]', 1, 'easy', 'published', 3),
  ('70000000-0000-4000-8000-000000000004', '40000000-0000-4000-8000-000000100102', 'numeric', 'quiz', 'Find the positive root of $x^2 - 2x - 3 = 0$.', '[]', 2, 'medium', 'published', 4),
  ('70000000-0000-4000-8000-000000000005', '40000000-0000-4000-8000-000000100102', 'short_answer', 'quiz', 'What is the name of the expression $b^2 - 4ac$?', '[]', 1, 'easy', 'published', 5);

insert into public.question_answers (question_id, correct, numeric_tolerance, explanation) values
  ('70000000-0000-4000-8000-000000000001', '["a"]', 0, 'D = b^2 - 4ac = 9 - 4(2)(-5) = 9 + 40 = 49.'),
  ('70000000-0000-4000-8000-000000000002', '["b","c"]', 0, 'Factorise: (x - 2)(x - 3) = 0, so x = 2 or x = 3.'),
  ('70000000-0000-4000-8000-000000000003', '[true]', 0, 'A polynomial of degree 2 has at most 2 roots.'),
  ('70000000-0000-4000-8000-000000000004', '[3]', 0.001, '(x - 3)(x + 1) = 0, so x = 3 or x = -1. The positive root is 3.'),
  ('70000000-0000-4000-8000-000000000005', '["discriminant"]', 0, 'It is called the discriminant.');

-- Practice question with a verified worked solution
insert into public.questions (id, chapter_id, type, usage, prompt, marks, difficulty, status, display_order) values
  ('70000000-0000-4000-8000-000000000101', '40000000-0000-4000-8000-000000100102', 'short_answer', 'practice', 'Solve $x^2 - 7x + 12 = 0$.', 3, 'easy', 'published', 10);
insert into public.question_answers (question_id, correct) values ('70000000-0000-4000-8000-000000000101', '["3 and 4"]');
insert into public.solutions (question_id, body_md, is_verified, status) values
  ('70000000-0000-4000-8000-000000000101', E'Find two numbers with product $12$ and sum $7$: $3$ and $4$.\n\n$(x-3)(x-4)=0 \\Rightarrow x = 3$ or $x = 4$.', true, 'published');

insert into public.quizzes (id, chapter_id, title, description, time_limit_seconds, negative_marking, shuffle_questions, pass_percentage, status, display_order) values
  ('80000000-0000-4000-8000-000000000001', '40000000-0000-4000-8000-000000100102', 'Quadratic Equations - Quick Check', 'Five questions covering every question type.', 600, 0.25, true, 40, 'published', 1);
insert into public.quiz_questions (quiz_id, question_id, display_order) values
  ('80000000-0000-4000-8000-000000000001', '70000000-0000-4000-8000-000000000001', 1),
  ('80000000-0000-4000-8000-000000000001', '70000000-0000-4000-8000-000000000002', 2),
  ('80000000-0000-4000-8000-000000000001', '70000000-0000-4000-8000-000000000003', 3),
  ('80000000-0000-4000-8000-000000000001', '70000000-0000-4000-8000-000000000004', 4),
  ('80000000-0000-4000-8000-000000000001', '70000000-0000-4000-8000-000000000005', 5);
