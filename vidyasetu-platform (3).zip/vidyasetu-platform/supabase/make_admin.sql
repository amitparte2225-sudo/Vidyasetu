-- INITIAL ADMINISTRATOR SETUP
-- 1. Create the account normally (Supabase Dashboard > Authentication > Users > Add user,
--    or register in the app/admin login page).
-- 2. Replace the e-mail below with that account's e-mail and run this in the SQL Editor.
--    The SQL Editor runs as the database owner, so this is the one safe place to grant admin.
--    There is intentionally no way to do this from the app or the website.
insert into public.user_roles (user_id, role)
select id, 'admin' from auth.users where email = 'REPLACE_WITH_YOUR_EMAIL@example.com'
on conflict (user_id) do update set role = 'admin';

-- Check the result (should return one row with role = admin):
select u.email, ur.role from auth.users u join public.user_roles ur on ur.user_id = u.id where ur.role = 'admin';
